import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';

// Security Event Audit Store (In-Memory Ring Buffer for SIEM / Cyber Modal)
export interface SecurityAuditEvent {
  id: string;
  timestamp: string;
  type: string;
  data: Record<string, any>;
  severity: 'INFO' | 'WARN' | 'CRITICAL';
}

const auditEventStore: SecurityAuditEvent[] = [];
const MAX_AUDIT_EVENTS = 100;

export function securityEvent(
  type: string,
  data: Record<string, any> = {},
  severity: 'INFO' | 'WARN' | 'CRITICAL' = 'WARN'
) {
  const event: SecurityAuditEvent = {
    id: `sec-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    timestamp: new Date().toISOString(),
    type,
    data,
    severity,
  };

  auditEventStore.unshift(event);
  if (auditEventStore.length > MAX_AUDIT_EVENTS) {
    auditEventStore.pop();
  }

  console.warn('[SECURITY GATEWAY]', JSON.stringify(event));
}

export function getSecurityAuditEvents(): SecurityAuditEvent[] {
  return [...auditEventStore];
}

// 1. API Rate Limiter
export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  limit: 200, // Limit each IP to 200 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  validate: {
    xForwardedForHeader: false,
    forwardedHeader: false,
    trustProxy: false,
  },
  message: {
    error: 'Too many requests from this IP, please try again after a minute.',
    status: 429,
  },
  handler: (req: Request, res: Response, next: NextFunction, options: any) => {
    securityEvent(
      'RATE_LIMIT_EXCEEDED',
      {
        ip: req.ip,
        path: req.originalUrl,
        method: req.method,
      },
      'WARN'
    );
    res.status(options.statusCode).send(options.message);
  },
});

// 2. Authentication Anomaly Detection Engine
const loginAttempts = new Map<string, { count: number; firstAttempt: number }>();

export function recordLoginFailure(identifier: string): number {
  const now = Date.now();
  const current = loginAttempts.get(identifier) || { count: 0, firstAttempt: now };

  // Reset window after 15 minutes
  if (now - current.firstAttempt > 15 * 60 * 1000) {
    current.count = 1;
    current.firstAttempt = now;
  } else {
    current.count++;
  }

  loginAttempts.set(identifier, current);

  if (current.count >= 5) {
    securityEvent(
      'AUTHENTICATION_ANOMALY',
      {
        identifier,
        failures: current.count,
        timeWindowMs: now - current.firstAttempt,
      },
      'CRITICAL'
    );
  }

  return current.count;
}

export function clearLoginFailures(identifier: string) {
  loginAttempts.delete(identifier);
}

// 3. Security Headers Middleware (OWASP recommended baseline)
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  // HSTS (Strict-Transport-Security)
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');

  // Prevent MIME confusion
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // Referrer Policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Permissions-Policy: Allow camera and microphone for legitimate optical gestures and vocal assistant
  res.setHeader(
    'Permissions-Policy',
    'camera=(self), microphone=(self), geolocation=(self)'
  );

  // Content-Security-Policy-Report-Only (Non-blocking staged deployment per OWASP)
  res.setHeader(
    'Content-Security-Policy-Report-Only',
    [
      "default-src 'self' * blob: data:",
      "img-src 'self' https: data: blob:",
      "style-src 'self' 'unsafe-inline' https: fonts.googleapis.com",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https:",
      "connect-src 'self' * https: wss:",
      "font-src 'self' https: fonts.gstatic.com data:",
      "media-src 'self' blob: data: https:",
      "object-src 'none'",
      "base-uri 'self'",
    ].join('; ')
  );

  next();
}

// 4. CORS Middleware with Credentials & Safe Origin Whitelist
export function dynamicCorsMiddleware(req: Request, res: Response, next: NextFunction) {
  const origin = req.headers.origin;

  if (origin) {
    // In dev / cloud container sandbox, reflect origin safely with credential support
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader(
      'Access-Control-Allow-Methods',
      'GET, POST, PUT, DELETE, PATCH, OPTIONS'
    );
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Origin, X-Requested-With, Content-Type, Accept, Authorization'
    );
  }

  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }

  next();
}

// 5. HTTP Error & Audit Event Telemetry
export function auditTelemetryMiddleware(req: Request, res: Response, next: NextFunction) {
  const started = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - started;

    // Ignore benign static asset 404s (such as browser favicon or dev maps)
    const isBenignStatic =
      res.statusCode === 404 &&
      (req.originalUrl.includes('favicon') ||
        req.originalUrl.endsWith('.map') ||
        req.originalUrl.startsWith('/@fs/'));

    if (res.statusCode >= 400 && !isBenignStatic) {
      securityEvent(
        'HTTP_ERROR',
        {
          method: req.method,
          path: req.originalUrl,
          status: res.statusCode,
          durationMs: duration,
          userAgent: req.headers['user-agent'] || 'Unknown',
        },
        res.statusCode >= 500 ? 'CRITICAL' : 'WARN'
      );
    }
  });

  next();
}
