import { Request, Response } from "express";
import { chatWithGemini, isGeminiConfigured, geminiCapabilities } from "./providers/geminiProvider";
import { chatWithClaude, isClaudeConfigured, claudeCapabilities } from "./providers/claudeProvider";
import type { ChatMessage } from "./providers/claudeProvider";

export type ProviderName = "gemini" | "claude";
export type ProviderPreference = ProviderName | "auto" | "both";

/**
 * GET /api/ai/capabilities
 * Reports real, current provider availability — never fabricated.
 */
export const handleAiCapabilities = (_req: Request, res: Response) => {
  const geminiUp = isGeminiConfigured();
  const claudeUp = isClaudeConfigured();
  res.json({
    gemini: { available: geminiUp, capabilities: geminiUp ? geminiCapabilities : null },
    claude: { available: claudeUp, capabilities: claudeUp ? claudeCapabilities : null },
    bothAvailable: geminiUp && claudeUp,
    noneAvailable: !geminiUp && !claudeUp,
  });
};

/**
 * Picks a provider for a task when the caller doesn't force one.
 * Simple, explainable heuristic — not a black box. Callers can always override
 * with `provider: "gemini" | "claude" | "both"` in the request body.
 */
const chooseProvider = (task: { needsSearch?: boolean; needsImageGen?: boolean; needsAudio?: boolean; needsVideo?: boolean }): ProviderName => {
  if (task.needsSearch || task.needsImageGen || task.needsAudio || task.needsVideo) return "gemini";
  return isClaudeConfigured() ? "claude" : "gemini";
};

/**
 * POST /api/ai/orchestrate
 * body: { messages: ChatMessage[], systemInstruction?: string, provider?: ProviderPreference,
 *         task?: { needsSearch?, needsImageGen?, needsAudio?, needsVideo? } }
 */
export const handleAiOrchestrate = async (req: Request, res: Response) => {
  const { messages, systemInstruction, provider, task } = req.body as {
    messages: ChatMessage[];
    systemInstruction?: string;
    provider?: ProviderPreference;
    task?: { needsSearch?: boolean; needsImageGen?: boolean; needsAudio?: boolean; needsVideo?: boolean };
  };

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "messages array is required" });
  }

  const geminiUp = isGeminiConfigured();
  const claudeUp = isClaudeConfigured();

  if (!geminiUp && !claudeUp) {
    return res.status(503).json({
      error: "EXTERNAL_CREDENTIAL_REQUIRED",
      detail: "Neither GEMINI_API_KEY nor ANTHROPIC_API_KEY is configured on the server.",
    });
  }

  const requested: ProviderPreference = provider || "auto";

  try {
    // Dual-provider synthesis — only when explicitly requested, since it doubles latency/cost.
    if (requested === "both") {
      if (!geminiUp || !claudeUp) {
        return res.status(503).json({
          error: "EXTERNAL_CREDENTIAL_REQUIRED",
          detail: `Dual-provider mode requires both providers configured. Gemini: ${geminiUp}, Claude: ${claudeUp}.`,
        });
      }
      const [geminiResult, claudeResult] = await Promise.allSettled([
        chatWithGemini(messages, systemInstruction),
        chatWithClaude(messages, systemInstruction),
      ]);

      const geminiText = geminiResult.status === "fulfilled" ? geminiResult.value.text : null;
      const claudeText = claudeResult.status === "fulfilled" ? claudeResult.value.text : null;

      return res.json({
        mode: "dual",
        gemini: geminiText,
        claude: claudeText,
        // Synthesis stays a simple concatenation with attribution rather than a fabricated
        // "merged" answer — real synthesis would itself need a model call, which callers
        // can request explicitly via a follow-up prompt if they want it.
        providersUsed: [
          geminiResult.status === "fulfilled" ? "gemini" : null,
          claudeResult.status === "fulfilled" ? "claude" : null,
        ].filter(Boolean),
      });
    }

    let chosen: ProviderName = requested === "auto" ? chooseProvider(task || {}) : requested;

    // Explicit fallback chain, recorded for diagnostics.
    const attempted: { provider: ProviderName; error?: string }[] = [];

    const tryProvider = async (name: ProviderName) => {
      if (name === "gemini") return chatWithGemini(messages, systemInstruction);
      return chatWithClaude(messages, systemInstruction);
    };

    if ((chosen === "gemini" && !geminiUp) || (chosen === "claude" && !claudeUp)) {
      const fallback: ProviderName = chosen === "gemini" ? "claude" : "gemini";
      attempted.push({ provider: chosen, error: "not configured" });
      chosen = fallback;
    }

    if ((chosen === "gemini" && !geminiUp) || (chosen === "claude" && !claudeUp)) {
      return res.status(503).json({ error: "EXTERNAL_CREDENTIAL_REQUIRED", attempted });
    }

    try {
      const result = await tryProvider(chosen);
      return res.json({ ...result, fallbackChain: attempted });
    } catch (err: any) {
      // One retry against the other provider if it's configured — never fabricate a response.
      attempted.push({ provider: chosen, error: err?.message || "unknown error" });
      const other: ProviderName = chosen === "gemini" ? "claude" : "gemini";
      const otherUp = other === "gemini" ? geminiUp : claudeUp;
      if (!otherUp) {
        return res.status(502).json({ error: "PROVIDER_REQUEST_FAILED", attempted });
      }
      const result = await tryProvider(other);
      return res.json({ ...result, fallbackChain: attempted });
    }
  } catch (err: any) {
    return res.status(500).json({ error: "ORCHESTRATION_FAILED", detail: err?.message || String(err) });
  }
};
