import { Request, Response } from "express";
import { buildInvoiceHtml, InvoiceRequest } from "./invoiceService";

export const handleInvoiceGenerate = (req: Request, res: Response) => {
  const body = req.body as InvoiceRequest;
  if (!body.clientName || !Array.isArray(body.items) || body.items.length === 0) {
    return res.status(400).json({ error: "clientName and at least one item are required" });
  }
  for (const item of body.items) {
    if (!item.description || typeof item.quantity !== "number" || typeof item.unitPrice !== "number") {
      return res.status(400).json({ error: "each item needs description, quantity, unitPrice" });
    }
  }
  const { html } = buildInvoiceHtml(body);
  res.setHeader("Content-Type", "text/html");
  res.send(html);
};
