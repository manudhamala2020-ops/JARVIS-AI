/**
 * Low-overhead acoustic double-clap detector.
 *
 * Designed for browser/Codespaces use: it listens only while explicitly enabled,
 * suspends while the page is hidden, and uses a small analyser buffer to keep
 * latency low without running an expensive FFT loop.
 */
export class ClapDetector {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private mediaStream: MediaStream | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private isRunning = false;
  private frameId: number | null = null;
  private lastClapTime = 0;
  private clapCount = 0;
  private cooldownUntil = 0;
  private onDoubleClapCallback: (() => void) | null = null;
  private readonly buffer = new Float32Array(256);
  private readonly CLAP_THRESHOLD = 0.28;
  private readonly CREST_THRESHOLD = 2.15;
  private readonly MIN_CLAP_INTERVAL_MS = 140;
  private readonly MAX_CLAP_INTERVAL_MS = 900;
  private readonly TRIGGER_COOLDOWN_MS = 1200;

  public setOnDoubleClap(callback: () => void) {
    this.onDoubleClapCallback = callback;
  }

  public async start(): Promise<boolean> {
    if (this.isRunning) return true;
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) return false;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: false },
      });
      const AudioCtx = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) {
        stream.getTracks().forEach((track) => track.stop());
        return false;
      }

      this.mediaStream = stream;
      this.audioContext = new AudioCtx();
      if (this.audioContext.state === 'suspended') await this.audioContext.resume().catch(() => undefined);
      this.source = this.audioContext.createMediaStreamSource(stream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.05;
      this.source.connect(this.analyser);
      this.isRunning = true;
      this.monitorAudio();
      return true;
    } catch (error) {
      console.warn('Double-clap microphone unavailable:', error);
      this.stop();
      return false;
    }
  }

  private monitorAudio = () => {
    if (!this.isRunning || !this.analyser) return;
    if (document.visibilityState === 'hidden') {
      this.frameId = requestAnimationFrame(this.monitorAudio);
      return;
    }

    this.analyser.getFloatTimeDomainData(this.buffer);
    let maxAmp = 0;
    let sumSquares = 0;
    for (const sample of this.buffer) {
      const abs = Math.abs(sample);
      if (abs > maxAmp) maxAmp = abs;
      sumSquares += sample * sample;
    }

    const rms = Math.sqrt(sumSquares / this.buffer.length);
    const crestFactor = rms > 0.0001 ? maxAmp / rms : 0;
    const now = performance.now();

    if (now >= this.cooldownUntil && maxAmp > this.CLAP_THRESHOLD && crestFactor > this.CREST_THRESHOLD) {
      const elapsed = now - this.lastClapTime;
      if (elapsed >= this.MIN_CLAP_INTERVAL_MS) {
        if (this.clapCount === 1 && elapsed <= this.MAX_CLAP_INTERVAL_MS) {
          this.clapCount = 0;
          this.lastClapTime = 0;
          this.cooldownUntil = now + this.TRIGGER_COOLDOWN_MS;
          this.onDoubleClapCallback?.();
        } else {
          this.clapCount = 1;
          this.lastClapTime = now;
        }
      }
    }

    if (this.clapCount === 1 && now - this.lastClapTime > this.MAX_CLAP_INTERVAL_MS) {
      this.clapCount = 0;
    }
    this.frameId = requestAnimationFrame(this.monitorAudio);
  };

  public stop() {
    this.isRunning = false;
    this.clapCount = 0;
    this.lastClapTime = 0;
    if (this.frameId !== null) cancelAnimationFrame(this.frameId);
    this.frameId = null;
    this.source?.disconnect();
    this.source = null;
    this.analyser = null;
    if (this.audioContext && this.audioContext.state !== 'closed') void this.audioContext.close().catch(() => undefined);
    this.audioContext = null;
    this.mediaStream?.getTracks().forEach((track) => track.stop());
    this.mediaStream = null;
  }

  public triggerSimulatedDoubleClap() {
    this.onDoubleClapCallback?.();
  }

  public isDetectorRunning(): boolean {
    return this.isRunning;
  }
}

export const clapDetectorService = new ClapDetector();
