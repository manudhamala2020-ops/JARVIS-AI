# JARVIS AI — Run locally

This is a web/full-stack development project, not an APK.

## Requirements
- Node.js 20+
- A terminal

## Install
```bash
npm install
```

## Configure Gemini
Copy `.env.example` to `.env` and set:
```text
GEMINI_API_KEY=your_key_here
JARVIS_AUTH_SECRET=use-a-long-random-secret
```

## Run
```bash
npm run dev
```
Then open `http://localhost:3000`.

## Production build
```bash
npm run build
npm start
```

## Architecture
The existing JARVIS UI is preserved. The server provides Gemini reasoning, search/Maps/image/audio/video routes, smart-device simulation, memory, security middleware, and capability discovery. Real Android, desktop, physical-IoT and messaging control are deliberately reported as unavailable until a real permissioned integration is connected.
