/**
 * File Access Service
 * ---------------------------------------------------------------------------
 * Wraps the browser's File System Access API. Every grant here is the result
 * of the user explicitly picking a file or folder in a native OS dialog —
 * there is no way for this service to read anything the user did not select,
 * and that's a browser-enforced guarantee, not just a policy this code
 * promises to follow.
 *
 * Falls back to <input type="file"> (read-only, no persisted handle) in
 * browsers that don't support the File System Access API (e.g. Firefox,
 * Safari as of this writing) — reported honestly via isSupported().
 */

export interface AuthorizedFile {
  handle: FileSystemFileHandle;
  name: string;
}

export interface AuthorizedFolder {
  handle: FileSystemDirectoryHandle;
  name: string;
}

class FileAccessService {
  private authorizedFiles: Map<string, AuthorizedFile> = new Map();
  private authorizedFolders: Map<string, AuthorizedFolder> = new Map();

  public isSupported(): boolean {
    return typeof window !== "undefined" && "showOpenFilePicker" in window;
  }

  /**
   * Must be called from a direct user gesture (click/tap handler) — browsers
   * reject the picker otherwise. Returns null if the user cancels; never
   * throws for a cancel.
   */
  public async requestFileAccess(options?: { multiple?: boolean; types?: FilePickerAcceptType[] }): Promise<AuthorizedFile[]> {
    if (!this.isSupported()) {
      throw new Error("File System Access API not supported in this browser. Use the <input type=\"file\"> fallback instead.");
    }
    try {
      const handles = await (window as any).showOpenFilePicker({
        multiple: options?.multiple ?? false,
        types: options?.types,
      });
      const results: AuthorizedFile[] = [];
      for (const handle of handles as FileSystemFileHandle[]) {
        const entry = { handle, name: handle.name };
        this.authorizedFiles.set(handle.name, entry);
        results.push(entry);
      }
      return results;
    } catch (err: any) {
      if (err?.name === "AbortError") return []; // user cancelled — not an error
      throw err;
    }
  }

  /** Same user-gesture requirement as requestFileAccess. */
  public async requestFolderAccess(): Promise<AuthorizedFolder | null> {
    if (!this.isSupported()) {
      throw new Error("File System Access API not supported in this browser.");
    }
    try {
      const handle = await (window as any).showDirectoryPicker();
      const entry = { handle, name: handle.name };
      this.authorizedFolders.set(handle.name, entry);
      return entry;
    } catch (err: any) {
      if (err?.name === "AbortError") return null;
      throw err;
    }
  }

  /** Re-checks the live OS-level permission for a previously granted handle — grants can be revoked outside the app. */
  public async verifyPermission(handle: FileSystemFileHandle | FileSystemDirectoryHandle, mode: "read" | "readwrite" = "read"): Promise<boolean> {
    const opts = { mode };
    if ((await (handle as any).queryPermission(opts)) === "granted") return true;
    return (await (handle as any).requestPermission(opts)) === "granted";
  }

  public async readFileText(name: string): Promise<string> {
    const entry = this.authorizedFiles.get(name);
    if (!entry) throw new Error(`"${name}" was never authorized via requestFileAccess().`);
    if (!(await this.verifyPermission(entry.handle))) throw new Error(`Permission for "${name}" was revoked.`);
    const file = await entry.handle.getFile();
    return file.text();
  }

  public revoke(name: string) {
    this.authorizedFiles.delete(name);
    this.authorizedFolders.delete(name);
  }

  public listAuthorized(): { files: string[]; folders: string[] } {
    return {
      files: Array.from(this.authorizedFiles.keys()),
      folders: Array.from(this.authorizedFolders.keys()),
    };
  }
}

export const fileAccessService = new FileAccessService();
