import React, { useState, useRef } from 'react';
import { X, Eye, Camera, Scan, Sparkles, CheckCircle2, ShieldAlert } from 'lucide-react';
import { VisionDetection } from '../types';

interface VisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  isCameraActive: boolean;
  onRunOpticalScan: (imageBase64?: string) => Promise<VisionDetection>;
}

export const VisionModal: React.FC<VisionModalProps> = ({
  isOpen,
  onClose,
  isCameraActive,
  onRunOpticalScan,
}) => {
  const [scanning, setScanning] = useState(false);
  const [detectionResult, setDetectionResult] = useState<VisionDetection | null>(
    null
  );

  if (!isOpen) return null;

  const handleScan = async () => {
    setScanning(true);
    try {
      // Try to capture snapshot from webcam if available
      const videoEl = document.getElementById('webcam') as HTMLVideoElement;
      let base64 = '';
      if (videoEl && videoEl.videoWidth) {
        const canvas = document.createElement('canvas');
        canvas.width = videoEl.videoWidth || 640;
        canvas.height = videoEl.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
          base64 = canvas.toDataURL('image/jpeg', 0.8);
        }
      }

      const result = await onRunOpticalScan(base64);
      setDetectionResult(result);
    } catch (e) {
      console.warn('Optical scan error:', e);
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn font-rajdhani">
      <div className="relative w-full max-w-3xl max-h-[85vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
                JARVIS OPTICAL COMPUTER VISION & OBJECT SCAN
              </h2>
              <p className="text-xs text-cyan-500 font-mono-tech">
                MediaPipe Hand Telemetry • Facial ID • Gemini Scene Understanding
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-lg border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tactical HUD Scanner Viewport */}
        <div className="relative w-full h-52 sm:h-64 bg-black/80 border border-cyan-500/40 rounded-xl overflow-hidden flex items-center justify-center">
          {/* Holographic grid lines & HUD corners */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#00f0ff0d_1px,transparent_1px),linear-gradient(to_bottom,#00f0ff0d_1px,transparent_1px)] bg-[size:24px_24px]" />
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#00f0ff]" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#00f0ff]" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#00f0ff]" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#00f0ff]" />

          {/* Radar circle & Reticle */}
          <div className="relative w-36 h-36 border border-cyan-500/30 rounded-full flex items-center justify-center">
            <div className="absolute inset-0 border-t-2 border-cyan-400 rounded-full animate-radar-spin opacity-70" />
            <div className="w-20 h-20 border border-dashed border-cyan-400/50 rounded-full flex items-center justify-center">
              <Scan className="w-8 h-8 text-cyan-300 animate-pulse" />
            </div>
          </div>

          {/* Scanner Line */}
          {scanning && (
            <div className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#00f0ff] to-transparent shadow-[0_0_15px_#00f0ff] animate-scanline" />
          )}

          {/* Status Overlay */}
          <div className="absolute bottom-2 left-3 text-[10px] font-mono-tech text-cyan-400">
            SENSOR STATUS: {isCameraActive ? 'OPTICAL CAMERA ACTIVE (480p)' : 'STANDBY / PERMISSION PENDING'}
          </div>
        </div>

        {/* Scan Actions */}
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={handleScan}
            disabled={scanning}
            className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-xl flex items-center justify-center gap-2 shadow-[0_0_15px_#00f0ff] transition-all disabled:opacity-50"
          >
            <Scan className="w-4 h-4" />
            <span>{scanning ? 'ANALYZING OPTICAL STREAM...' : 'RUN LIVE OPTICAL ANALYSIS'}</span>
          </button>
        </div>

        {/* Detection Results */}
        {detectionResult && (
          <div className="p-3.5 bg-black/60 border border-cyan-500/40 rounded-xl space-y-2 font-mono-tech text-xs animate-fadeIn">
            <div className="flex items-center justify-between text-cyan-300 font-bold font-orbitron">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#00f0ff]" />
                <span>SCENE TELEMETRY ANALYSIS</span>
              </span>
              <span className="text-emerald-400 text-[11px]">
                Confidence: {(detectionResult.confidence * 100).toFixed(0)}%
              </span>
            </div>

            <p className="text-cyan-200/90 text-xs leading-relaxed bg-cyan-950/30 p-2.5 rounded-lg border border-cyan-500/20">
              {detectionResult.sceneDescription}
            </p>

            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-cyan-500 text-[11px] font-bold">Detected Signatures:</span>
              {detectionResult.objects.map((obj, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 bg-cyan-950/80 border border-cyan-500/40 rounded text-[10px] text-cyan-300 font-bold"
                >
                  {obj.label} ({(obj.confidence * 100).toFixed(0)}%)
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
