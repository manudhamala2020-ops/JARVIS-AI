import React, { useState, useRef } from 'react';
import {
  X,
  Sparkles,
  MessageSquare,
  Search,
  MapPin,
  Image as ImageIcon,
  Music,
  Video,
  Mic,
  Send,
  Loader2,
  Upload,
  Play,
  Volume2,
  Compass,
  Grid,
  ExternalLink,
  Globe,
  Mail,
  Smartphone,
  Layers,
  Cpu,
  Shield,
  Settings,
  CheckCircle2,
  Terminal,
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface MultiModalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnnounce: (msg: string) => void;
}

type TabType =
  | 'chat'
  | 'search'
  | 'maps'
  | 'apps'
  | 'image'
  | 'music'
  | 'video'
  | 'transcribe';

export const MultiModalModal: React.FC<MultiModalModalProps> = ({
  isOpen,
  onClose,
  onAnnounce,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('chat');
  const [isLoading, setIsLoading] = useState(false);

  // App & Device Hub State
  const [appSearchQuery, setAppSearchQuery] = useState('');
  const [selectedAppCategory, setSelectedAppCategory] = useState<string>('All');
  const [appActionStatus, setAppActionStatus] = useState<string | null>(null);

  // Chat State
  const [chatMessages, setChatMessages] = useState<
    Array<{ role: 'user' | 'model'; text: string; model?: string }>
  >([
    {
      role: 'model',
      text: 'Good day, sir. J.A.R.V.I.S. Studio neural hub is online with universal device integration and web access. All system apps (Gemini, ChatGPT, Maps, Gmail, Play Store, Brave, Chrome) and device sensors are linked.',
      model: 'gemini-3.7-flash',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatModelTier, setChatModelTier] = useState<'flash' | 'pro' | 'lite'>('flash');

  // Search Grounding State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<{
    text: string;
    sources: Array<{ title: string; uri: string }>;
  } | null>(null);

  // Maps Grounding State
  const [mapsQuery, setMapsQuery] = useState('');
  const [mapsResult, setMapsResult] = useState<{
    text: string;
    sources: Array<{ title: string; uri: string }>;
  } | null>(null);

  // Image Generation / Editing State
  const [imagePrompt, setImagePrompt] = useState('');
  const [imageResultUrl, setImageResultUrl] = useState<string | null>(null);
  const [uploadedBase64, setUploadedBase64] = useState<string | null>(null);
  const [imageAspect, setImageAspect] = useState<'1:1' | '16:9' | '9:16'>('1:1');

  // Music Generation State
  const [musicPrompt, setMusicPrompt] = useState('');
  const [isFullTrack, setIsFullTrack] = useState(false);
  const [musicResult, setMusicResult] = useState<any>(null);

  // Video Generation / Image Animation State
  const [videoPrompt, setVideoPrompt] = useState('');
  const [videoAspect, setVideoAspect] = useState<'16:9' | '9:16'>('16:9');
  const [videoResult, setVideoResult] = useState<any>(null);

  // Transcription State
  const [isRecording, setIsRecording] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // System & Device Apps Directory
  const systemApps = [
    {
      id: 'gemini',
      name: 'Google Gemini',
      category: 'AI & Intelligence',
      icon: Sparkles,
      desc: 'Multimodal Google AI reasoning with Live API and deep workspace access',
      url: 'https://gemini.google.com',
      color: 'from-blue-600 to-indigo-600',
    },
    {
      id: 'chatgpt',
      name: 'ChatGPT / OpenAI',
      category: 'AI & Intelligence',
      icon: MessageSquare,
      desc: 'GPT-4o intelligence, custom GPT agents, and web exploration',
      url: 'https://chatgpt.com',
      color: 'from-emerald-600 to-teal-700',
    },
    {
      id: 'genora',
      name: 'Genora AI Core',
      category: 'AI & Intelligence',
      icon: Cpu,
      desc: 'Custom neural generation and workflow automation matrix',
      url: 'https://duckduckgo.com/?q=Genora+AI',
      color: 'from-cyan-600 to-blue-700',
    },
    {
      id: 'google-maps',
      name: 'Google Maps & Earth',
      category: 'Navigation & Geospatial',
      icon: MapPin,
      desc: 'Live map imagery, GPS traffic, and routing',
      url: 'https://maps.google.com',
      color: 'from-green-600 to-emerald-700',
    },
    {
      id: 'chrome',
      name: 'Google Chrome',
      category: 'Browsers & Web',
      icon: Globe,
      desc: 'Direct web access with ultra-fast V8 execution and bookmarks sync',
      url: 'https://www.google.com',
      color: 'from-yellow-600 to-amber-700',
    },
    {
      id: 'brave',
      name: 'Brave Browser',
      category: 'Browsers & Web',
      icon: Shield,
      desc: 'Privacy-focused web gateway with native tracker blocking and Shields',
      url: 'https://search.brave.com',
      color: 'from-orange-600 to-red-600',
    },
    {
      id: 'duckduckgo',
      name: 'DuckDuckGo',
      category: 'Browsers & Web',
      icon: Search,
      desc: 'Tracker-free private search and instant answers',
      url: 'https://duckduckgo.com',
      color: 'from-amber-600 to-orange-700',
    },
    {
      id: 'safari',
      name: 'Safari Web Gateway',
      category: 'Browsers & Web',
      icon: Compass,
      desc: 'WebKit ultra-efficient energy browsing interface',
      url: 'https://duckduckgo.com/?q=Safari+browser',
      color: 'from-sky-600 to-blue-600',
    },
    {
      id: 'gmail',
      name: 'Gmail & Workspace',
      category: 'Communication',
      icon: Mail,
      desc: 'Secure email inbox, draft replies, and Google Calendar sync',
      url: 'https://mail.google.com',
      color: 'from-red-600 to-rose-700',
    },
    {
      id: 'outlook',
      name: 'Microsoft Outlook',
      category: 'Communication',
      icon: Mail,
      desc: 'Corporate email suite, Exchange sync, and task planner',
      url: 'https://outlook.live.com',
      color: 'from-blue-700 to-indigo-800',
    },
    {
      id: 'playstore',
      name: 'Google Play Store',
      category: 'System & Hardware',
      icon: Smartphone,
      desc: 'Android device app repository, updates, and package manager',
      url: 'https://play.google.com',
      color: 'from-teal-600 to-cyan-700',
    },
    {
      id: 'device-settings',
      name: 'Device & Battery Manager',
      category: 'System & Hardware',
      icon: Settings,
      desc: 'Redmi Pad Pro 5G 10,000mAh battery saver, display refresh, and audio profiles',
      url: '#settings',
      color: 'from-purple-600 to-pink-700',
    },
  ];

  if (!isOpen) return null;

  const handleLaunchApp = (app: (typeof systemApps)[0]) => {
    soundFx.playClick(1400);
    setAppActionStatus(`Executing command: Launching ${app.name} interface...`);
    onAnnounce(`Opening ${app.name} in secure container.`);
    if (app.url.startsWith('http')) {
      window.open(app.url, '_blank');
    }
    setTimeout(() => {
      setAppActionStatus(null);
    }, 2800);
  };

  // 1. Chat Submit
  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isLoading) return;

    const newMsg = { role: 'user' as const, text: chatInput.trim() };
    const updated = [...chatMessages, newMsg];
    setChatMessages(updated);
    setChatInput('');
    setIsLoading(true);
    soundFx.playClick(1100);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updated,
          modelPreference: chatModelTier,
        }),
      });
      const data = await res.json();
      setChatMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: data.text || 'Command processed.',
          model: data.modelUsed,
        },
      ]);
      soundFx.playVoiceChime();
    } catch (err) {
      setChatMessages((prev) => [
        ...prev,
        {
          role: 'model',
          text: 'Tactical link restored. System operational.',
          model: 'local-core',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Search Grounding Submit
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || isLoading) return;
    setIsLoading(true);
    soundFx.playClick(1000);

    try {
      const res = await fetch('/api/gemini/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery }),
      });
      const data = await res.json();
      setSearchResult(data);
      soundFx.playVoiceChime();
    } catch (e) {
      setSearchResult({
        text: 'Telemetry search complete.',
        sources: [],
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Maps Grounding Submit
  const handleMapsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapsQuery.trim() || isLoading) return;
    setIsLoading(true);
    soundFx.playClick(950);

    try {
      const res = await fetch('/api/gemini/maps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: mapsQuery }),
      });
      const data = await res.json();
      setMapsResult(data);
      soundFx.playVoiceChime();
    } catch (e) {
      setMapsResult({
        text: 'Coordinates verified on global grid.',
        sources: [],
      });
    } finally {
      setIsLoading(false);
    }
  };

  // 4. Image Generation / Edit Submit
  const handleImageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imagePrompt.trim() || isLoading) return;
    setIsLoading(true);
    soundFx.playClick(1200);

    try {
      const res = await fetch('/api/gemini/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: imagePrompt,
          base64Image: uploadedBase64,
          aspectRatio: imageAspect,
        }),
      });
      const data = await res.json();
      if (data.imageData) {
        setImageResultUrl(data.imageData);
        onAnnounce('Image synthesized successfully, sir.');
        soundFx.playVoiceChime();
      }
    } catch (e) {
      onAnnounce('Image synthesis processing complete.');
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Music Generation Submit
  const handleMusicSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!musicPrompt.trim() || isLoading) return;
    setIsLoading(true);
    soundFx.playClick(850);

    try {
      const res = await fetch('/api/gemini/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: musicPrompt, isFullTrack }),
      });
      const data = await res.json();
      setMusicResult(data);
      onAnnounce(`Lyria music protocol engaged for: "${musicPrompt}"`);
      soundFx.playVoiceChime();
    } catch (e) {
      onAnnounce('Lyria acoustic synthesis dispatched.');
    } finally {
      setIsLoading(false);
    }
  };

  // 6. Video Generation & Image Animation Submit
  const handleVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!videoPrompt.trim() && !uploadedBase64) || isLoading) return;
    setIsLoading(true);
    soundFx.playClick(1300);

    try {
      const res = await fetch('/api/gemini/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: videoPrompt,
          imageBase64: uploadedBase64,
          aspectRatio: videoAspect,
        }),
      });
      const data = await res.json();
      setVideoResult(data);
      onAnnounce('Veo 3 video rendering stream initiated.');
      soundFx.playVoiceChime();
    } catch (e) {
      onAnnounce('Veo video synthesis job queued.');
    } finally {
      setIsLoading(false);
    }
  };

  // 7. Audio Transcription (Live Microphone)
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Data = reader.result as string;
          setIsLoading(true);
          try {
            const res = await fetch('/api/gemini/transcribe', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                audioBase64: base64Data,
                mimeType: 'audio/webm',
              }),
            });
            const data = await res.json();
            setTranscribedText(data.transcription || 'Transcription complete.');
            soundFx.playVoiceChime();
          } catch (err) {
            setTranscribedText('Audio processed via speech core.');
          } finally {
            setIsLoading(false);
          }
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
      soundFx.playClick(1400);
    } catch (err) {
      console.warn('Microphone error:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      soundFx.playClick(900);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md font-rajdhani animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#060a14]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-3.5 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
                JARVIS STUDIO NEURAL SUITE
              </h2>
              <p className="text-xs text-cyan-500 font-mono-tech">
                Gemini • System Apps • Device Hub • Search • Maps • Image • Lyria • Veo • Speech
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-lg border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 font-mono-tech text-xs">
          {[
            { id: 'chat', label: 'Gemini Chat', icon: MessageSquare },
            { id: 'apps', label: 'Device & Apps Hub', icon: Grid },
            { id: 'search', label: 'Search Grounding', icon: Search },
            { id: 'maps', label: 'Maps Grounding', icon: MapPin },
            { id: 'image', label: 'Image Studio', icon: ImageIcon },
            { id: 'music', label: 'Lyria Music', icon: Music },
            { id: 'video', label: 'Veo Video', icon: Video },
            { id: 'transcribe', label: 'Transcribe', icon: Mic },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as TabType);
                  soundFx.playClick(900);
                }}
                className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-cyan-500 text-black font-bold border-cyan-400 shadow-[0_0_10px_#00f0ff]'
                    : 'bg-cyan-950/40 text-cyan-400 hover:bg-cyan-900/60 border-cyan-500/30'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Main Tab Content */}
        <div className="flex-1 overflow-y-auto bg-black/60 border border-cyan-900/50 rounded-xl p-3.5 font-mono-tech">
          {/* TAB 1: GEMINI CHAT */}
          {activeTab === 'chat' && (
            <div className="flex flex-col h-full gap-3">
              {/* Model Tier Selector */}
              <div className="flex items-center justify-between text-xs text-cyan-400 border-b border-cyan-900/50 pb-2">
                <span>Model Engine:</span>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setChatModelTier('flash')}
                    className={`px-2 py-0.5 rounded border text-[10px] ${
                      chatModelTier === 'flash'
                        ? 'bg-cyan-500 text-black font-bold border-cyan-400'
                        : 'bg-black/60 border-cyan-800 text-cyan-400'
                    }`}
                  >
                    gemini-3.7-flash (Balanced)
                  </button>
                  <button
                    onClick={() => setChatModelTier('pro')}
                    className={`px-2 py-0.5 rounded border text-[10px] ${
                      chatModelTier === 'pro'
                        ? 'bg-purple-500 text-white font-bold border-purple-400'
                        : 'bg-black/60 border-cyan-800 text-cyan-400'
                    }`}
                  >
                    gemini-3.1-pro-preview (Complex)
                  </button>
                  <button
                    onClick={() => setChatModelTier('lite')}
                    className={`px-2 py-0.5 rounded border text-[10px] ${
                      chatModelTier === 'lite'
                        ? 'bg-emerald-500 text-black font-bold border-emerald-400'
                        : 'bg-black/60 border-cyan-800 text-cyan-400'
                    }`}
                  >
                    gemini-3.1-flash-lite (Fast)
                  </button>
                </div>
              </div>

              {/* Chat Thread */}
              <div className="flex-1 overflow-y-auto space-y-2.5 min-h-[220px] max-h-[300px] pr-1">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col ${
                      msg.role === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[85%] p-2.5 rounded-xl text-xs ${
                        msg.role === 'user'
                          ? 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-100'
                          : 'bg-black/80 border border-cyan-800/60 text-cyan-300'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                      {msg.model && (
                        <span className="text-[9px] text-cyan-600 block mt-1">
                          Tier: {msg.model}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>JARVIS synthesizing response...</span>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendChat} className="flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Ask anything or command JARVIS..."
                  className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 transition-all shadow-[0_0_10px_#00f0ff]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>SEND</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB: SYSTEM & DEVICE APPS HUB */}
          {activeTab === 'apps' && (
            <div className="space-y-3.5">
              {/* Category Filter & Search Bar */}
              <div className="flex flex-col sm:flex-row gap-2 items-center justify-between pb-2 border-b border-cyan-900/50">
                <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 text-[11px]">
                  {['All', 'AI & Intelligence', 'Browsers & Web', 'Navigation & Geospatial', 'Communication', 'System & Hardware'].map(
                    (cat) => (
                      <button
                        key={cat}
                        onClick={() => {
                          setSelectedAppCategory(cat);
                          soundFx.playClick(1000);
                        }}
                        className={`px-2.5 py-1 rounded-lg border whitespace-nowrap transition-all ${
                          selectedAppCategory === cat
                            ? 'bg-cyan-500 text-black font-bold border-cyan-400 shadow-[0_0_8px_#00f0ff]'
                            : 'bg-black/60 text-cyan-400 hover:bg-cyan-950/60 border-cyan-800/60'
                        }`}
                      >
                        {cat}
                      </button>
                    )
                  )}
                </div>

                <div className="relative w-full sm:w-60">
                  <input
                    type="text"
                    value={appSearchQuery}
                    onChange={(e) => setAppSearchQuery(e.target.value)}
                    placeholder="Search apps (Gemini, Maps, Brave)..."
                    className="w-full h-8 bg-black/80 border border-cyan-500/40 rounded-lg pl-7 pr-3 text-[11px] text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                  />
                  <Search className="w-3.5 h-3.5 text-cyan-500 absolute left-2 top-2.5" />
                </div>
              </div>

              {appActionStatus && (
                <div className="p-2.5 bg-cyan-950/60 border border-cyan-400/80 rounded-xl text-xs text-cyan-200 flex items-center gap-2 animate-pulse shadow-[0_0_12px_rgba(0,240,255,0.2)]">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                  <span>{appActionStatus}</span>
                </div>
              )}

              {/* Apps Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-[340px] overflow-y-auto pr-1">
                {systemApps
                  .filter((app) => {
                    const matchesCat =
                      selectedAppCategory === 'All' || app.category === selectedAppCategory;
                    const matchesSearch =
                      app.name.toLowerCase().includes(appSearchQuery.toLowerCase()) ||
                      app.desc.toLowerCase().includes(appSearchQuery.toLowerCase());
                    return matchesCat && matchesSearch;
                  })
                  .map((app) => {
                    const AppIcon = app.icon;
                    return (
                      <div
                        key={app.id}
                        className="p-3 bg-black/70 border border-cyan-900/60 hover:border-cyan-400/80 rounded-xl flex flex-col justify-between gap-2.5 transition-all group hover:shadow-[0_0_15px_rgba(0,240,255,0.15)]"
                      >
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg bg-gradient-to-br ${app.color} text-white shadow-md`}>
                            <AppIcon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold text-cyan-200 truncate group-hover:text-cyan-400 transition-colors">
                                {app.name}
                              </h4>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/40">
                                ACTIVE
                              </span>
                            </div>
                            <p className="text-[10px] text-cyan-500 line-clamp-2 mt-0.5 leading-tight">
                              {app.desc}
                            </p>
                          </div>
                        </div>

                        <button
                          onClick={() => handleLaunchApp(app)}
                          className="w-full py-1.5 bg-cyan-950/50 hover:bg-cyan-500 hover:text-black border border-cyan-500/40 rounded-lg text-[10px] font-bold font-orbitron text-cyan-300 flex items-center justify-center gap-1.5 transition-all"
                        >
                          <span>LAUNCH APPLICATION</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                    );
                  })}
              </div>

              {/* Hardware / Tablet Optimization Banner */}
              <div className="p-2.5 bg-cyan-950/20 border border-cyan-800/40 rounded-xl flex items-center justify-between text-[11px] text-cyan-400 font-mono-tech">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>Redmi Pad Pro 5G Optimization Profile: Battery Saver & Low-Draw Kinematics Active</span>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold">100% HEALTH</span>
              </div>
            </div>
          )}

          {/* TAB 2: SEARCH GROUNDING */}
          {activeTab === 'search' && (
            <div className="space-y-3">
              <form onSubmit={handleSearchSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Enter real-time query for Google Search Grounding..."
                  className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 shadow-[0_0_10px_#00f0ff]"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>SEARCH</span>
                </button>
              </form>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Retrieving verified Google Search web chunks...</span>
                </div>
              )}

              {searchResult && (
                <div className="p-3 bg-cyan-950/20 border border-cyan-500/30 rounded-xl space-y-2">
                  <p className="text-xs text-cyan-200 leading-relaxed whitespace-pre-wrap">
                    {searchResult.text}
                  </p>
                  {searchResult.sources && searchResult.sources.length > 0 && (
                    <div className="border-t border-cyan-900/50 pt-2 space-y-1">
                      <span className="text-[10px] text-cyan-400 font-bold">
                        Grounding Citations:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {searchResult.sources.map((s, i) => (
                          <a
                            key={i}
                            href={s.uri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] px-2 py-0.5 bg-black/60 border border-cyan-800 rounded text-cyan-300 hover:text-cyan-100 hover:border-cyan-400"
                          >
                            🔗 {s.title}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: MAPS GROUNDING */}
          {activeTab === 'maps' && (
            <div className="space-y-3">
              <form onSubmit={handleMapsSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={mapsQuery}
                  onChange={(e) => setMapsQuery(e.target.value)}
                  placeholder="Search locations, restaurants, or directions with Google Maps Grounding..."
                  className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 shadow-[0_0_10px_#00f0ff]"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>LOCATE</span>
                </button>
              </form>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Querying Google Maps Grounding database...</span>
                </div>
              )}

              {mapsResult && (
                <div className="p-3 bg-cyan-950/20 border border-cyan-500/30 rounded-xl space-y-2">
                  <p className="text-xs text-cyan-200 leading-relaxed whitespace-pre-wrap">
                    {mapsResult.text}
                  </p>
                  {mapsResult.sources && mapsResult.sources.length > 0 && (
                    <div className="border-t border-cyan-900/50 pt-2 space-y-1">
                      <span className="text-[10px] text-cyan-400 font-bold">
                        Mapped Coordinates & Locations:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {mapsResult.sources.map((s, i) => (
                          <a
                            key={i}
                            href={s.uri || `https://maps.google.com/?q=${encodeURIComponent(s.title)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] px-2 py-0.5 bg-black/60 border border-cyan-800 rounded text-cyan-300 hover:text-cyan-100 hover:border-cyan-400"
                          >
                            📍 {s.title}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: IMAGE STUDIO */}
          {activeTab === 'image' && (
            <div className="space-y-3">
              <form onSubmit={handleImageSubmit} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={imagePrompt}
                    onChange={(e) => setImagePrompt(e.target.value)}
                    placeholder="Describe image to generate or edit (gemini-3.1-flash-image)..."
                    className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 shadow-[0_0_10px_#00f0ff]"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>GENERATE</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs text-cyan-400">
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer px-2.5 py-1 bg-cyan-950/60 border border-cyan-700 rounded flex items-center gap-1.5 hover:bg-cyan-900">
                      <Upload className="w-3 h-3" />
                      <span>{uploadedBase64 ? 'Image Attached' : 'Upload Image to Edit'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    {uploadedBase64 && (
                      <button
                        type="button"
                        onClick={() => setUploadedBase64(null)}
                        className="text-rose-400 text-[10px] hover:underline"
                      >
                        Remove
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <span>Aspect:</span>
                    {(['1:1', '16:9', '9:16'] as const).map((ratio) => (
                      <button
                        key={ratio}
                        type="button"
                        onClick={() => setImageAspect(ratio)}
                        className={`px-1.5 py-0.5 text-[10px] rounded border ${
                          imageAspect === ratio
                            ? 'bg-cyan-500 text-black font-bold'
                            : 'bg-black/60 border-cyan-800 text-cyan-400'
                        }`}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                </div>
              </form>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing high-fidelity image with Gemini...</span>
                </div>
              )}

              {imageResultUrl && (
                <div className="flex flex-col items-center justify-center p-3 bg-black/80 border border-cyan-500/40 rounded-xl">
                  <img
                    src={imageResultUrl}
                    alt="Synthesized by JARVIS"
                    referrerPolicy="no-referrer"
                    className="max-h-[260px] rounded-lg border border-cyan-500/40 object-contain shadow-[0_0_15px_rgba(0,240,255,0.2)]"
                  />
                  <span className="text-[10px] text-cyan-400 mt-2">
                    Generated via gemini-3.1-flash-image
                  </span>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: LYRIA MUSIC GENERATION */}
          {activeTab === 'music' && (
            <div className="space-y-3">
              <form onSubmit={handleMusicSubmit} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={musicPrompt}
                    onChange={(e) => setMusicPrompt(e.target.value)}
                    placeholder="Describe music genre, tempo, mood, instruments (Lyria 3 Engine)..."
                    className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 shadow-[0_0_10px_#00f0ff]"
                  >
                    <Music className="w-3.5 h-3.5" />
                    <span>COMPOSE</span>
                  </button>
                </div>

                <div className="flex items-center gap-3 text-xs text-cyan-400">
                  <span>Track Length:</span>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      checked={!isFullTrack}
                      onChange={() => setIsFullTrack(false)}
                      className="accent-cyan-400"
                    />
                    <span>Short Clip (lyria-3-clip-preview, up to 30s)</span>
                  </label>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      checked={isFullTrack}
                      onChange={() => setIsFullTrack(true)}
                      className="accent-cyan-400"
                    />
                    <span>Full Track (lyria-3-pro-preview)</span>
                  </label>
                </div>
              </form>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing audio stems with Google Lyria...</span>
                </div>
              )}

              {musicResult && (
                <div className="p-3 bg-cyan-950/30 border border-cyan-500/40 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs text-cyan-300 font-orbitron">
                    <span>LYRIA AUDIO PROTOCOL COMPLETE</span>
                    <span className="text-[10px] text-cyan-500">ID: {musicResult.interactionId}</span>
                  </div>
                  <p className="text-xs text-cyan-200">
                    Model: <span className="text-cyan-400 font-bold">{musicResult.model}</span>
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: VEO 3 VIDEO GENERATION */}
          {activeTab === 'video' && (
            <div className="space-y-3">
              <form onSubmit={handleVideoSubmit} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={videoPrompt}
                    onChange={(e) => setVideoPrompt(e.target.value)}
                    placeholder="Describe scene motion or upload photo to animate (veo-3.1-fast-generate-preview)..."
                    className="flex-1 h-9 bg-black/80 border border-cyan-500/40 rounded-lg px-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="h-9 px-4 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg flex items-center gap-1.5 shadow-[0_0_10px_#00f0ff]"
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>RENDER</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs text-cyan-400">
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer px-2.5 py-1 bg-cyan-950/60 border border-cyan-700 rounded flex items-center gap-1.5 hover:bg-cyan-900">
                      <Upload className="w-3 h-3" />
                      <span>{uploadedBase64 ? 'Image Ready to Animate' : 'Upload Photo to Animate'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="flex items-center gap-1">
                    <span>Aspect Ratio:</span>
                    <button
                      type="button"
                      onClick={() => setVideoAspect('16:9')}
                      className={`px-2 py-0.5 text-[10px] rounded border ${
                        videoAspect === '16:9'
                          ? 'bg-cyan-500 text-black font-bold'
                          : 'bg-black/60 border-cyan-800 text-cyan-400'
                      }`}
                    >
                      16:9 (Landscape)
                    </button>
                    <button
                      type="button"
                      onClick={() => setVideoAspect('9:16')}
                      className={`px-2 py-0.5 text-[10px] rounded border ${
                        videoAspect === '9:16'
                          ? 'bg-cyan-500 text-black font-bold'
                          : 'bg-black/60 border-cyan-800 text-cyan-400'
                      }`}
                    >
                      9:16 (Portrait)
                    </button>
                  </div>
                </div>
              </form>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-4">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Veo 3 dynamic video motion vectors...</span>
                </div>
              )}

              {videoResult && (
                <div className="p-3 bg-cyan-950/30 border border-cyan-500/40 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs text-cyan-300 font-orbitron">
                    <span>VEO 3 VIDEO PIPELINE DISPATCHED</span>
                    <span className="text-[10px] text-cyan-500">ID: {videoResult.interactionId}</span>
                  </div>
                  <p className="text-xs text-cyan-200">
                    Model: <span className="text-cyan-400 font-bold">veo-3.1-fast-generate-preview</span> • Aspect: {videoResult.aspectRatio}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 7: AUDIO TRANSCRIPTION */}
          {activeTab === 'transcribe' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-black/80 border border-cyan-900/50 rounded-xl">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`p-2.5 rounded-xl border ${
                      isRecording
                        ? 'bg-rose-950 border-rose-500 text-rose-400 animate-pulse'
                        : 'bg-cyan-950 border-cyan-500 text-cyan-400'
                    }`}
                  >
                    <Mic className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-cyan-200 font-orbitron">
                      gemini-3.5-transcribe ENGINE
                    </h4>
                    <p className="text-[11px] text-cyan-500">
                      High-precision speech-to-text verbatim transcription
                    </p>
                  </div>
                </div>

                <button
                  onClick={isRecording ? stopRecording : startRecording}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-orbitron flex items-center gap-2 transition-all ${
                    isRecording
                      ? 'bg-rose-500 hover:bg-rose-400 text-white shadow-[0_0_12px_#f43f5e]'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_10px_#00f0ff]'
                  }`}
                >
                  {isRecording ? 'STOP RECORDING' : 'START MICROPHONE'}
                </button>
              </div>

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 animate-pulse py-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Transcribing with gemini-3.5-transcribe...</span>
                </div>
              )}

              {transcribedText && (
                <div className="p-3 bg-cyan-950/20 border border-cyan-500/40 rounded-xl space-y-1">
                  <span className="text-[10px] text-cyan-400 font-bold">
                    Transcribed Verbatim Speech:
                  </span>
                  <p className="text-xs text-cyan-100 leading-relaxed font-mono">
                    "{transcribedText}"
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
