/**
 * Safe business-automation primitives.
 * These are planning/execution contracts; external CRM, email, calendar and
 * messaging connectors must be explicitly configured and authorized.
 */
export interface BusinessTask {
  id: string;
  title: string;
  kind: 'lead' | 'schedule' | 'report' | 'follow-up' | 'data-sync';
  status: 'planned' | 'approved' | 'running' | 'completed' | 'blocked';
  requiresApproval: boolean;
  payload: Record<string, unknown>;
}

export class BusinessAutomationOrchestrator {
  private readonly tasks = new Map<string, BusinessTask>();

  plan(task: Omit<BusinessTask, 'status'>): BusinessTask {
    const planned: BusinessTask = { ...task, status: task.requiresApproval ? 'planned' : 'approved' };
    this.tasks.set(planned.id, planned);
    return planned;
  }

  approve(id: string): BusinessTask | undefined {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    task.status = 'approved';
    return task;
  }

  get(id: string): BusinessTask | undefined { return this.tasks.get(id); }
  list(): BusinessTask[] { return [...this.tasks.values()]; }

  remove(id: string): boolean { return this.tasks.delete(id); }
}

export const businessAutomation = new BusinessAutomationOrchestrator();
