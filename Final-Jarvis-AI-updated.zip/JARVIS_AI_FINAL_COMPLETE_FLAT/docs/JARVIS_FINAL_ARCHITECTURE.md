# JARVIS AI — Final Architecture

The existing holographic presentation layer is preserved. New capabilities are modular and authorization-gated.

## Layers
- Presentation: existing React/Three.js UI — locked.
- Orchestration: intent routing, task planning, cancellation and barge-in.
- Intelligence: Gemini-backed reasoning/research with source-aware outputs.
- Perception: camera, vision and low-latency hand tracking.
- Voice: wake word, STT, TTS and interruption.
- Tools: browser, GitHub, files, documents, productivity and future connectors.
- Native bridge: Android-only capabilities requiring platform permissions.
- Security: authentication, rate limiting, security headers, audit events, isolation and recovery.
- Maintenance: detect → analyze → propose → test → verify → apply → monitor → rollback.

## Reality constraints
A browser cannot grant itself unrestricted Android/system/application access. Sensitive capabilities must use explicit user permission and, where necessary, an authenticated native Android bridge.

Offensive cyber operations are not implemented as unrestricted capabilities. The security layer is defensive and supports authorized testing/lab workflows.

Medical/environmental readings are never fabricated; real sensors or external data sources are required.
