import { Request, Response } from "express";
import { createMission, listMissions, getMission, approveMission, cancelMission } from "./missionsService";

export const handleMissionsList = (_req: Request, res: Response) => {
  res.json({ missions: listMissions() });
};

export const handleMissionCreate = (req: Request, res: Response) => {
  const { title, description, agent } = req.body as { title?: string; description?: string; agent?: "CASE" | "TARS" };
  if (!title || !description) {
    return res.status(400).json({ error: "title and description are required" });
  }
  const mission = createMission(title, description, agent);
  res.status(201).json({ mission });
};

export const handleMissionGet = (req: Request, res: Response) => {
  const mission = getMission(req.params.id);
  if (!mission) return res.status(404).json({ error: "MISSION_NOT_FOUND" });
  res.json({ mission });
};

export const handleMissionApprove = (req: Request, res: Response) => {
  const mission = approveMission(req.params.id);
  if (!mission) return res.status(404).json({ error: "MISSION_NOT_FOUND" });
  res.json({ mission });
};

export const handleMissionCancel = (req: Request, res: Response) => {
  const mission = cancelMission(req.params.id);
  if (!mission) return res.status(404).json({ error: "MISSION_NOT_FOUND" });
  res.json({ mission });
};
