export interface InvoiceLineItem {
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface InvoiceRequest {
  clientName: string;
  clientEmail?: string;
  invoiceNumber?: string;
  items: InvoiceLineItem[];
  notes?: string;
  currency?: string; // e.g. "USD" — displayed as a symbol/code, no live FX conversion
}

const escapeHtml = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

const fmtMoney = (n: number, currency: string) => `${currency} ${n.toFixed(2)}`;

/**
 * Builds a self-contained, print-ready HTML invoice. Opening this in a browser tab and
 * using Print -> Save as PDF produces a real PDF with zero added dependencies. This is
 * an honest scope choice: a true server-side binary PDF library isn't installed here and
 * can't be added without npm/network access in this environment, so rather than fabricate
 * that, this generates something that actually works today.
 */
export const buildInvoiceHtml = (req: InvoiceRequest): { html: string; total: number; invoiceNumber: string } => {
  const currency = req.currency || "USD";
  const invoiceNumber = req.invoiceNumber || `JARVIS-${Date.now()}`;
  const rows = req.items.map((item) => {
    const lineTotal = item.quantity * item.unitPrice;
    return `<tr>
      <td>${escapeHtml(item.description)}</td>
      <td style="text-align:right">${item.quantity}</td>
      <td style="text-align:right">${fmtMoney(item.unitPrice, currency)}</td>
      <td style="text-align:right">${fmtMoney(lineTotal, currency)}</td>
    </tr>`;
  });
  const total = req.items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0);

  const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Invoice ${escapeHtml(invoiceNumber)}</title>
<style>
  body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a1a2e; padding: 48px; max-width: 720px; margin: 0 auto; }
  h1 { color: #0891b2; letter-spacing: 2px; font-size: 22px; margin-bottom: 4px; }
  .meta { color: #64748b; font-size: 13px; margin-bottom: 32px; }
  table { width: 100%; border-collapse: collapse; margin-top: 24px; }
  th { text-align: left; border-bottom: 2px solid #0891b2; padding: 8px 4px; font-size: 12px; text-transform: uppercase; color: #64748b; }
  th:nth-child(n+2) { text-align: right; }
  td { padding: 10px 4px; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
  .total-row td { font-weight: bold; font-size: 16px; border-top: 2px solid #0891b2; border-bottom: none; }
  .notes { margin-top: 32px; font-size: 13px; color: #475569; white-space: pre-wrap; }
  @media print { body { padding: 24px; } }
</style></head>
<body>
  <h1>JARVIS — INVOICE</h1>
  <div class="meta">
    Invoice #${escapeHtml(invoiceNumber)}<br>
    Bill to: ${escapeHtml(req.clientName)}${req.clientEmail ? ` (${escapeHtml(req.clientEmail)})` : ""}<br>
    Date: ${new Date().toLocaleDateString()}
  </div>
  <table>
    <thead><tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Amount</th></tr></thead>
    <tbody>
      ${rows.join("\n")}
      <tr class="total-row"><td colspan="3">Total</td><td style="text-align:right">${fmtMoney(total, currency)}</td></tr>
    </tbody>
  </table>
  ${req.notes ? `<div class="notes">${escapeHtml(req.notes)}</div>` : ""}
  <script>window.onload = () => window.print();</script>
</body></html>`;

  return { html, total, invoiceNumber };
};
