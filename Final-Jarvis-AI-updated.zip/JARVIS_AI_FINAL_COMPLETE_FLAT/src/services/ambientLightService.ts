export type LightingEnvironment = 'DARK_ROOM' | 'BALANCED' | 'HIGH_AMBIENT';

export interface AmbientLightState {
  luxPercent: number; // 0 - 100%
  environment: LightingEnvironment;
  contrast: number; // e.g. 1.0 - 1.25
  brightness: number; // e.g. 0.95 - 1.12
  saturation: number; // e.g. 1.0 - 1.15
  glowMultiplier: number;
  filterString: string;
  isAutoContrastActive: boolean;
}

type AmbientListener = (state: AmbientLightState) => void;

class AmbientLightService {
  private canvas: HTMLCanvasElement | null = null;
  private ctx: CanvasRenderingContext2D | null = null;
  private currentLux: number = 50; // default 50%
  private smoothLux: number = 50;
  private isAutoContrast: boolean = true;
  private listeners: Set<AmbientListener> = new Set();
  private sampleTimer: any = null;
  private activeVideo: HTMLVideoElement | null = null;

  constructor() {
    if (typeof document !== 'undefined') {
      this.canvas = document.createElement('canvas');
      this.canvas.width = 16;
      this.canvas.height = 16;
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    }
  }

  public setAutoContrast(enabled: boolean) {
    this.isAutoContrast = enabled;
    this.notify();
  }

  public getAutoContrast(): boolean {
    return this.isAutoContrast;
  }

  public toggleAutoContrast(): boolean {
    this.isAutoContrast = !this.isAutoContrast;
    this.notify();
    return this.isAutoContrast;
  }

  public attachVideo(video: HTMLVideoElement | null) {
    this.activeVideo = video;
    if (video && !this.sampleTimer) {
      this.startSampling();
    } else if (!video && this.sampleTimer) {
      this.stopSampling();
    }
  }

  private startSampling() {
    if (this.sampleTimer) return;
    // Sample ambient lux every 2.5 seconds to conserve battery and CPU
    this.sampleTimer = setInterval(() => this.sampleFrame(), 2500);
  }

  private stopSampling() {
    if (this.sampleTimer) {
      clearInterval(this.sampleTimer);
      this.sampleTimer = null;
    }
  }

  private sampleFrame() {
    if (!this.activeVideo || this.activeVideo.readyState < 2 || !this.ctx || !this.canvas) {
      return;
    }

    try {
      this.ctx.drawImage(this.activeVideo, 0, 0, 16, 16);
      const imageData = this.ctx.getImageData(0, 0, 16, 16);
      const data = imageData.data;
      let totalLuminance = 0;
      const count = 16 * 16;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i] / 255;
        const g = data[i + 1] / 255;
        const b = data[i + 2] / 255;
        // Standard Rec. 709 Relative Luminance
        const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        totalLuminance += lum;
      }

      const avgLuminance = totalLuminance / count;
      const rawLux = Math.min(Math.max(avgLuminance * 100, 0), 100);

      // Smooth EMA to avoid sudden flashes
      const previousRoundedLux = this.currentLux;
      this.smoothLux = this.smoothLux * 0.80 + rawLux * 0.20;
      this.currentLux = Math.round(this.smoothLux);

      // Only notify listeners if lux change is noticeable (>= 4%)
      if (Math.abs(this.currentLux - previousRoundedLux) >= 4) {
        this.notify();
      }
    } catch (e) {
      // Ignored if video frame not accessible
    }
  }

  public getState(): AmbientLightState {
    const lux = this.currentLux;
    let environment: LightingEnvironment = 'BALANCED';
    let contrast = 1.0;
    let brightness = 1.0;
    let saturation = 1.05;
    let glowMultiplier = 1.0;

    if (lux < 25) {
      environment = 'DARK_ROOM';
      // In dark environments: rich deep contrast, slightly dimmed overall brightness to prevent blinding glare, high crisp neon
      contrast = 1.08;
      brightness = 0.98;
      saturation = 1.10;
      glowMultiplier = 1.25;
    } else if (lux > 60) {
      environment = 'HIGH_AMBIENT';
      // In bright environments: punch through room reflection with elevated contrast and increased brightness
      contrast = 1.20;
      brightness = 1.12;
      saturation = 1.15;
      glowMultiplier = 0.85;
    } else {
      environment = 'BALANCED';
      contrast = 1.04;
      brightness = 1.02;
      saturation = 1.06;
      glowMultiplier = 1.0;
    }

    if (!this.isAutoContrast) {
      contrast = 1.0;
      brightness = 1.0;
      saturation = 1.0;
      glowMultiplier = 1.0;
    }

    const filterString = `contrast(${contrast.toFixed(2)}) brightness(${brightness.toFixed(2)}) saturate(${saturation.toFixed(2)})`;

    return {
      luxPercent: lux,
      environment,
      contrast,
      brightness,
      saturation,
      glowMultiplier,
      filterString,
      isAutoContrastActive: this.isAutoContrast,
    };
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((fn) => {
      try {
        fn(state);
      } catch (e) {
        // ignore
      }
    });
  }

  public subscribe(listener: AmbientListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }
}

export const ambientLightService = new AmbientLightService();
