import { getCapability, CapabilityDefinition } from './jarvisCapabilities';
export interface AuthorizationDecision { allowed:boolean; requiresApproval:boolean; reason:string; capability?:CapabilityDefinition; }
export function authorizeCapability(id:string, approved=false):AuthorizationDecision {
 const capability=getCapability(id);
 if(!capability) return {allowed:false,requiresApproval:false,reason:'Unknown capability.'};
 if(capability.requiresUserApproval&&!approved) return {allowed:false,requiresApproval:true,reason:'User approval is required for this action.',capability};
 if(capability.requiresNativeBridge&&typeof window!=='undefined'&&!(window as any).JARVIS_NATIVE_BRIDGE) return {allowed:false,requiresApproval:capability.requiresUserApproval,reason:'This capability requires the authorized native Android bridge.',capability};
 return {allowed:true,requiresApproval:false,reason:'Authorized by current policy.',capability};
}
