import React, { useEffect, useState, useCallback } from 'react';
import { X, Bot, Plus, CheckCircle2, XCircle, Loader2, ShieldAlert } from 'lucide-react';

interface Mission {
  id: string;
  title: string;
  description: string;
  agent: 'CASE' | 'TARS';
  status: 'queued' | 'running' | 'awaiting_approval' | 'completed' | 'failed' | 'cancelled';
  log: { time: number; message: string }[];
  result: string | null;
  requiresApproval: boolean;
}

interface MissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const statusColor: Record<Mission['status'], string> = {
  queued: 'text-cyan-300',
  running: 'text-yellow-300',
  awaiting_approval: 'text-orange-300',
  completed: 'text-green-300',
  failed: 'text-red-300',
  cancelled: 'text-gray-400',
};

export const MissionsModal: React.FC<MissionsModalProps> = ({ isOpen, onClose }) => {
  const [missions, setMissions] = useState<Mission[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [agent, setAgent] = useState<'CASE' | 'TARS'>('CASE');
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/missions');
      if (!res.ok) throw new Error(`Failed: ${res.status}`);
      const data = await res.json();
      setMissions(data.missions);
    } catch (err: any) {
      setError(err?.message || 'Could not reach the missions service.');
    }
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    refresh();
    const interval = setInterval(refresh, 2000); // poll while any mission is running
    return () => clearInterval(interval);
  }, [isOpen, refresh]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;
    setError(null);
    try {
      const res = await fetch('/api/missions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, description, agent }),
      });
      if (!res.ok) throw new Error(`Failed: ${res.status}`);
      setTitle('');
      setDescription('');
      refresh();
    } catch (err: any) {
      setError(err?.message || 'Could not create the mission.');
    }
  };

  const approve = async (id: string) => {
    await fetch(`/api/missions/${id}/approve`, { method: 'POST' });
    refresh();
  };
  const cancel = async (id: string) => {
    await fetch(`/api/missions/${id}/cancel`, { method: 'POST' });
    refresh();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn font-rajdhani">
      <div className="relative w-full max-w-3xl h-[85vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-3 overflow-hidden">
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Bot className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
              MISSION CONTROL — BACKGROUND AGENTS
            </h2>
          </div>
          <button onClick={onClose} className="text-cyan-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleCreate} className="flex flex-col gap-2 border-b border-cyan-500/20 pb-3">
          <div className="flex gap-2">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Mission title"
              className="flex-1 bg-black/40 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-sm text-cyan-100 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400"
            />
            <select
              value={agent}
              onChange={(e) => setAgent(e.target.value as 'CASE' | 'TARS')}
              className="bg-black/40 border border-cyan-500/30 rounded-lg px-2 py-1.5 text-sm text-cyan-100 focus:outline-none focus:border-cyan-400"
            >
              <option value="CASE">CASE</option>
              <option value="TARS">TARS</option>
            </select>
          </div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What should this agent do? (Research, drafting, summarizing. Real-world actions like calling or paying get flagged for your approval first.)"
            rows={2}
            className="bg-black/40 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-sm text-cyan-100 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400 resize-none"
          />
          <button
            type="submit"
            className="self-end flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Spawn mission
          </button>
        </form>

        {error && <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</div>}

        <div className="flex-1 overflow-y-auto space-y-2">
          {missions.length === 0 && <p className="text-xs text-cyan-500/50 text-center py-6">No missions yet.</p>}
          {missions.map((m) => (
            <div key={m.id} className="border border-cyan-500/20 rounded-lg p-3 bg-cyan-500/5">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-orbitron text-cyan-400">{m.agent}</span>
                  <span className="text-sm text-cyan-100">{m.title}</span>
                </div>
                <span className={`text-xs flex items-center gap-1 ${statusColor[m.status]}`}>
                  {m.status === 'running' && <Loader2 className="w-3 h-3 animate-spin" />}
                  {m.status === 'completed' && <CheckCircle2 className="w-3 h-3" />}
                  {m.status === 'failed' && <XCircle className="w-3 h-3" />}
                  {m.status === 'awaiting_approval' && <ShieldAlert className="w-3 h-3" />}
                  {m.status.replace('_', ' ')}
                </span>
              </div>
              <p className="text-xs text-cyan-500/70 mb-1">{m.description}</p>
              {m.result && <p className="text-xs text-cyan-100/90 bg-black/30 rounded p-2 mt-1 whitespace-pre-wrap">{m.result}</p>}
              {m.status === 'awaiting_approval' && (
                <div className="flex gap-2 mt-2">
                  <button onClick={() => approve(m.id)} className="text-xs px-2 py-1 rounded bg-green-500/10 border border-green-500/40 text-green-300 hover:bg-green-500/20">
                    Approve & run
                  </button>
                  <button onClick={() => cancel(m.id)} className="text-xs px-2 py-1 rounded bg-red-500/10 border border-red-500/40 text-red-300 hover:bg-red-500/20">
                    Cancel
                  </button>
                </div>
              )}
              {(m.status === 'queued' || m.status === 'running') && (
                <button onClick={() => cancel(m.id)} className="text-xs px-2 py-1 mt-2 rounded bg-red-500/10 border border-red-500/40 text-red-300 hover:bg-red-500/20">
                  Cancel
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
