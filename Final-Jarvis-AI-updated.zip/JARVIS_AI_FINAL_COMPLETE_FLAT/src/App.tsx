import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  JarvisState,
  SmartDevice,
  SmartScene,
  MemoryItem,
  DeviceTelemetry,
  VisionDetection,
} from './types';
import {
  INITIAL_SMART_DEVICES,
  INITIAL_SMART_SCENES,
  INITIAL_MEMORIES,
  DEFAULT_TELEMETRY,
} from './data/defaultDevices';
import { JarvisCore, HologramModelType } from './components/JarvisCore';
import { BottomHUD } from './components/BottomHUD';
import { VoicePopup } from './components/VoicePopup';
import { SmartHomeModal } from './components/SmartHomeModal';
import { TelemetryHUD } from './components/TelemetryHUD';
import { MemoryHUD } from './components/MemoryHUD';
import { VisionModal } from './components/VisionModal';
import { GestureGuideHUD } from './components/GestureGuideHUD';
import { HandSkeletonOverlay, HandLandmark } from './components/HandSkeletonOverlay';
import { MultiModalModal } from './components/MultiModalModal';
import { CyberSecurityModal } from './components/CyberSecurityModal';
import { ProductivityForgeModal } from './components/ProductivityForgeModal';
import { StarkInfrastructureModal } from './components/StarkInfrastructureModal';
import { YouTubeShortsModal } from './components/YouTubeShortsModal';
import { KnowledgeGalaxyModal } from './components/KnowledgeGalaxyModal';
import { MissionsModal } from './components/MissionsModal';
import { AuthService } from './services/authService';
import { jarvisVoice } from './services/voiceService';
import { soundFx } from './services/soundFx';
import { clapDetectorService } from './services/clapDetector';
import { ambientLightService, AmbientLightState } from './services/ambientLightService';
import {
  Activity,
  ShieldCheck,
  MapPin,
  Clock,
  Battery,
  Zap,
  Wifi,
  Sparkles,
  Volume2,
  VolumeX,
  Crosshair,
  Layers,
  Lock,
  Unlock,
  Sun,
  Moon,
  Eye,
} from 'lucide-react';

export default function App() {
  const [jarvisState, setJarvisState] = useState<JarvisState>('IDLE');
  const [devices, setDevices] = useState<SmartDevice[]>(INITIAL_SMART_DEVICES);
  const [scenes, setScenes] = useState<SmartScene[]>(INITIAL_SMART_SCENES);
  const [memories, setMemories] = useState<MemoryItem[]>(INITIAL_MEMORIES);
  const [telemetry, setTelemetry] = useState<DeviceTelemetry>(DEFAULT_TELEMETRY);

  const [responseText, setResponseText] = useState<string>(
    'Awaiting speech command ("Hey Jarvis") or hand gesture input...'
  );
  const [popupText, setPopupText] = useState<string>('Listening...');
  const [isPopupVisible, setIsPopupVisible] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const [lastGesture, setLastGesture] = useState<string>('');
  const [gestureConfidence, setGestureConfidence] = useState<number>(0);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [landmarks, setLandmarks] = useState<HandLandmark[][] | HandLandmark[] | null>(null);
  const [videoElement, setVideoElement] = useState<HTMLVideoElement | null>(null);
  const [showPiP, setShowPiP] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isGestureLocked, setIsGestureLocked] = useState<boolean>(false);
  const [hologramModel, setHologramModel] = useState<HologramModelType>('ARC_REACTOR');
  const [ambientLight, setAmbientLight] = useState<AmbientLightState>(ambientLightService.getState());

  // Acoustic Double-Clap Listener (Explicit Trigger)
  const handleTriggerDoubleClap = useCallback(() => {
    soundFx.playJarvisChime();
    const wakeMsg = 'Sir, acoustic trigger acknowledged.';
    setJarvisState('SPEAKING');
    setIsPopupVisible(true);
    setPopupText(`👏 Acoustic Trigger • ${wakeMsg}`);
    setResponseText(wakeMsg);

    jarvisVoice.speak(wakeMsg, () => {
      setJarvisState('IDLE');
      setTimeout(() => setIsPopupVisible(false), 2500);
    });
  }, []);

  // Acoustic double-clap wake: explicit, local, and lifecycle-aware.
  useEffect(() => {
    clapDetectorService.setOnDoubleClap(handleTriggerDoubleClap);
    const startDetector = () => {
      if (document.visibilityState === 'visible') void clapDetectorService.start();
    };
    const stopDetector = () => clapDetectorService.stop();
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') stopDetector();
      else startDetector();
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('pageshow', startDetector);
    window.addEventListener('pagehide', stopDetector);
    startDetector();
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('pageshow', startDetector);
      window.removeEventListener('pagehide', stopDetector);
      clapDetectorService.stop();
    };
  }, [handleTriggerDoubleClap]);

  // Immediate Stop Vocal Response handler
  const handleStopSpeaking = useCallback(() => {
    jarvisVoice.stopSpeaking();
    setJarvisState('IDLE');
    setIsSpeaking(false);
    setPopupText('');
    setIsPopupVisible(false);
    setResponseText('Vocal synthesis halted upon command.');
    soundFx.playClick(600);
  }, []);

  // Keyboard shortcut: Escape to immediately stop vocal speech
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isSpeaking) {
        handleStopSpeaking();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSpeaking, handleStopSpeaking]);

  // Dynamic ambient light optical sensing from front camera
  useEffect(() => {
    ambientLightService.attachVideo(videoElement);
    const unsubscribe = ambientLightService.subscribe((state) => {
      setAmbientLight(state);
    });
    return () => {
      unsubscribe();
    };
  }, [videoElement]);

  // Gesture handling throttle ref (30fps = ~33.3ms threshold)
  const lastGestureProcessTimeRef = useRef<number>(0);
  const pendingGestureTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Modals state
  const [isSmartHomeOpen, setIsSmartHomeOpen] = useState<boolean>(false);
  const [isTelemetryOpen, setIsTelemetryOpen] = useState<boolean>(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState<boolean>(false);
  const [isVisionOpen, setIsVisionOpen] = useState<boolean>(false);
  const [isGestureGuideOpen, setIsGestureGuideOpen] = useState<boolean>(false);
  const [isMultiModalOpen, setIsMultiModalOpen] = useState<boolean>(false);
  const [isCyberModalOpen, setIsCyberModalOpen] = useState<boolean>(false);
  const [isProductivityModalOpen, setIsProductivityModalOpen] = useState<boolean>(false);
  const [isInfraModalOpen, setIsInfraModalOpen] = useState<boolean>(false);
  const [isGalaxyModalOpen, setIsGalaxyModalOpen] = useState<boolean>(false);
  const [isMissionsModalOpen, setIsMissionsModalOpen] = useState<boolean>(false);
  const [isShortsPlayerOpen, setIsShortsPlayerOpen] = useState<boolean>(false);
  const [activeShortId, setActiveShortId] = useState<string>('2NKpA6smfwg');

  // Firebase Auth State
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    const unsub = AuthService.onUserChanged((user) => {
      setCurrentUser(user);
      if (user) {
        // Load persistent Firestore memories
        AuthService.loadUserMemories().then((userMems) => {
          if (userMems && userMems.length > 0) {
            setMemories((prev) => [...userMems, ...prev]);
          }
        });
      }
    });
    return () => unsub();
  }, []);

  // Time & date state
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  // 1. Real Device Battery & Hardware Diagnostics API
  useEffect(() => {
    let batteryInstance: any = null;

    const handleBatteryUpdates = () => {
      if (!batteryInstance) return;
      const level = Math.round(batteryInstance.level * 100);
      const charging = Boolean(batteryInstance.charging);
      setTelemetry((prev) => ({
        ...prev,
        battery: {
          ...prev.battery,
          level,
          charging,
          temperatureC: charging ? 34.2 : 31.8,
        },
      }));
    };

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any)
        .getBattery()
        .then((bat: any) => {
          batteryInstance = bat;
          handleBatteryUpdates();
          bat.addEventListener('levelchange', handleBatteryUpdates);
          bat.addEventListener('chargingchange', handleBatteryUpdates);
        })
        .catch(() => {
          // Graceful fallback to default telemetry
        });
    }

    return () => {
      if (batteryInstance) {
        batteryInstance.removeEventListener('levelchange', handleBatteryUpdates);
        batteryInstance.removeEventListener(
          'chargingchange',
          handleBatteryUpdates
        );
      }
    };
  }, []);

  // 2. Real System Clock & Dynamic Date
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
      setCurrentDate(
        now.toLocaleDateString('en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })
      );
    };
    updateDateTime();
    const timer = setInterval(updateDateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // 3. Fetch initial devices and memories from backend
  useEffect(() => {
    fetch('/api/devices')
      .then((res) => res.json())
      .then((data) => {
        if (data.devices) setDevices(data.devices);
      })
      .catch(() => {
        // use initial fallback
      });

    fetch('/api/memories')
      .then((res) => res.json())
      .then((data) => {
        if (data.memories) setMemories(data.memories);
      })
      .catch(() => {
        // use initial fallback
      });
  }, []);

  // Process user instruction via Backend Gemini AI
  const processCommand = useCallback(
    async (commandText: string) => {
      if (!commandText.trim()) return;

      const lowerCmd = commandText.toLowerCase().trim();

      // Immediate Vocal Interruption / Stop Commands
      if (
        lowerCmd === 'stop' ||
        lowerCmd === 'hey jarvis stop' ||
        lowerCmd === 'jarvis stop' ||
        lowerCmd === 'stop talking' ||
        lowerCmd === 'stop speaking' ||
        lowerCmd === 'shut up' ||
        lowerCmd === 'be quiet' ||
        lowerCmd === 'cancel' ||
        lowerCmd === 'pause' ||
        lowerCmd === 'ruk jao' ||
        lowerCmd === 'chup' ||
        lowerCmd === 'band karo'
      ) {
        handleStopSpeaking();
        return;
      }

      // Direct YouTube / YouTube Shorts URL and Video Link Recognition
      if (
        lowerCmd.includes('youtube.com') ||
        lowerCmd.includes('youtu.be') ||
        lowerCmd.includes('shorts') ||
        lowerCmd.includes('2nkpa6smfwg')
      ) {
        let extractedId = '2NKpA6smfwg';
        const shortsMatch = commandText.match(/shorts\/([a-zA-Z0-9_-]+)/i);
        const watchMatch = commandText.match(/[?&]v=([a-zA-Z0-9_-]+)/i);
        const youtuBeMatch = commandText.match(/youtu\.be\/([a-zA-Z0-9_-]+)/i);
        const rawIdMatch = commandText.match(/([a-zA-Z0-9_-]{11})/);

        if (shortsMatch && shortsMatch[1]) {
          extractedId = shortsMatch[1];
        } else if (watchMatch && watchMatch[1]) {
          extractedId = watchMatch[1];
        } else if (youtuBeMatch && youtuBeMatch[1]) {
          extractedId = youtuBeMatch[1];
        } else if (rawIdMatch && rawIdMatch[1]) {
          extractedId = rawIdMatch[1];
        }

        setActiveShortId(extractedId);
        setIsShortsPlayerOpen(true);
        const reply = `Streaming YouTube video feed in holographic viewport, sir. Optical gesture controls and auto-scroller are engaged.`;
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playTargetLock();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      }
      // Global "remember that…" capture — works from the wake-word pipeline directly,
      // not just from inside the Knowledge Galaxy modal's own mic button.
      if (/^remember that\b/i.test(lowerCmd)) {
        const captured = commandText.trim().replace(/^remember that\s*/i, '');
        if (!captured) {
          const reply = "I didn't catch what to remember, sir. Try again after \"remember that\".";
          setJarvisState('SPEAKING');
          setPopupText(reply);
          setResponseText(reply);
          setIsPopupVisible(true);
          jarvisVoice.speak(reply, () => {
            setJarvisState('IDLE');
            setTimeout(() => setIsPopupVisible(false), 3000);
          });
          return;
        }
        try {
          const res = await fetch('/api/notes/remember', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: captured }),
          });
          if (!res.ok) throw new Error(`Remember failed: ${res.status}`);
          const data = await res.json();
          setIsGalaxyModalOpen(true); // surface the galaxy so the newly indexed note is visible
          const reply = `Noted, sir — filed away as "${data.node.label}."`;
          setJarvisState('SPEAKING');
          setPopupText(reply);
          setResponseText(reply);
          setIsPopupVisible(true);
          soundFx.playNotification();
          jarvisVoice.speak(reply, () => {
            setJarvisState('IDLE');
            setTimeout(() => setIsPopupVisible(false), 3000);
          });
        } catch (err: any) {
          const reply = "I couldn't save that note, sir — the notes service didn't respond.";
          setJarvisState('SPEAKING');
          setPopupText(reply);
          setResponseText(reply);
          setIsPopupVisible(true);
          jarvisVoice.speak(reply, () => {
            setJarvisState('IDLE');
            setTimeout(() => setIsPopupVisible(false), 3000);
          });
        }
        return;
      }

      // Instant media/action protocols
      if (lowerCmd.includes('knowledge galaxy') || lowerCmd.includes('second brain') || lowerCmd.includes('open my notes') || lowerCmd.includes('my notes')) {
        setIsGalaxyModalOpen(true);
        const reply = 'Opening the knowledge galaxy, sir. Your notes, mapped and waiting.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      }
      if (lowerCmd.includes('mission control') || lowerCmd.includes('spawn') || lowerCmd.includes('background agent') || lowerCmd.includes('missions')) {
        setIsMissionsModalOpen(true);
        const reply = 'Mission control online, sir. Ready to dispatch CASE or TARS.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      }
      if (lowerCmd.includes('play music') || lowerCmd.includes('play song') || lowerCmd.includes('monta re')) {
        setIsMultiModalOpen(true);
        const reply = 'Opening media streaming subsystem, playing requested track now, sir.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      } else if (lowerCmd.includes('full brightness') || lowerCmd.includes('max brightness')) {
        handleUpdateDevice('light-living-main', { power: true, brightness: 100, color: '#ffffaa' });
        handleUpdateDevice('light-ambient-strip', { power: true, brightness: 100, color: '#00f0ff' });
        const reply = 'Full brightness engaged, sir.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playRepulsorCharge();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 2500);
        });
        return;
      } else if (lowerCmd.includes('full brightness') || lowerCmd.includes('brightness badhao')) {
        const reply = 'Setting full brightness to 100%, sir. Display illumination and all smart luminaires adjusted.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playRepulsorCharge();
        setDevices((prev) =>
          prev.map((d) => (d.type === 'light' ? { ...d, power: true, brightness: 100 } : d))
        );
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      } else if (lowerCmd.includes('shutdown') || lowerCmd.includes('shut down') || lowerCmd.includes('turn off pc') || lowerCmd.includes('band karo pc')) {
        const reply = 'I cannot directly shut down the host from this browser session. I can help you connect a permitted device-control tool instead.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playClick(600);
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      } else if (lowerCmd.includes('route') || lowerCmd.includes('mumbai') || lowerCmd.includes('goa')) {
        const reply = 'I can calculate or retrieve a live route when Maps access is available; I will not invent distance or travel time.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playTargetLock();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 4000);
        });
        return;
      } else if (lowerCmd.includes('ppt') || lowerCmd.includes('presentation') || (lowerCmd.includes('artificial intelligence') && lowerCmd.includes('generate'))) {
        setIsProductivityModalOpen(true);
        const reply = 'Opening the productivity workspace. The presentation is not considered generated until the generator returns a real file.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playNotification();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 4000);
        });
        return;
      } else if (lowerCmd.includes('calculator') && (lowerCmd.includes('java') || lowerCmd.includes('vs code') || lowerCmd.includes('vscode'))) {
        setIsMultiModalOpen(true);
        const reply = 'Opening the development workspace. File creation and VS Code control require an approved local integration.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('call my friend') || lowerCmd.includes('friend') || lowerCmd.includes('dost')) {
        const reply = 'I cannot access or call a private contact from this browser without an approved device integration.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playNotification();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('whatsapp') || lowerCmd.includes('sister') || lowerCmd.includes('roshni')) {
        const reply = 'I cannot send WhatsApp messages from this browser without an approved messaging integration.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playNotification();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('auto scroll') || lowerCmd.includes('auto-scroll') || lowerCmd.includes('scroll shorts')) {
        const reply = 'Universal scroller is now active, sir. Enjoy watching Shorts and Reels.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      } else if (lowerCmd.includes('alarm') || lowerCmd.includes('4 second') || lowerCmd.includes('four second')) {
        const reply = 'Sir, your alarm is set for 4 seconds.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playTargetLock();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => {
            soundFx.playAlarmSiren();
            setResponseText('ALERT: 4-Second Alarm Triggered!');
            setPopupText('ALERT: 4-Second Alarm Triggered!');
            setIsPopupVisible(true);
          }, 4000);
        });
        return;
      } else if (lowerCmd.includes('unlock') || lowerCmd.includes('jiohotstar') || lowerCmd.includes('hotstar')) {
        const reply = 'I cannot unlock devices or launch private apps without an approved device-control integration.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playRepulsorCharge();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3000);
        });
        return;
      } else if (lowerCmd.includes('organize') || lowerCmd.includes('folder') || lowerCmd.includes('downloads')) {
        const reply = 'I cannot modify your device folders from this browser session. A permitted file-system integration is required.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('license') || lowerCmd.includes('office') || lowerCmd.includes('activate office')) {
        const reply = 'I cannot activate software licenses or claim activation succeeded. Please use the official licensing workflow.';
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playJarvisChime();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('battery') || lowerCmd.includes('kitna charge') || lowerCmd.includes('charge bacha')) {
        const reply = `Sir, the device battery is at ${telemetry.battery.level}%. ${telemetry.battery.charging ? 'The device is currently charging.' : 'The device is not charging.'}`;
        setJarvisState('SPEAKING');
        setPopupText(reply);
        setResponseText(reply);
        setIsPopupVisible(true);
        soundFx.playTargetLock();
        jarvisVoice.speak(reply, () => {
          setJarvisState('IDLE');
          setTimeout(() => setIsPopupVisible(false), 3500);
        });
        return;
      } else if (lowerCmd.includes('cyber') || lowerCmd.includes('white hat') || lowerCmd.includes('firewall') || lowerCmd.includes('threat defense') || lowerCmd.includes('hack')) {
        setIsCyberModalOpen(true);
      } else if (lowerCmd.includes('infrastructure') || lowerCmd.includes('stark mansion') || lowerCmd.includes('dum-e') || lowerCmd.includes('workshop')) {
        setIsInfraModalOpen(true);
      } else if (lowerCmd.includes('productivity') || lowerCmd.includes('document forge') || lowerCmd.includes('synthesize word') || lowerCmd.includes('synthesize presentation') || lowerCmd.includes('powerpoint')) {
        setIsProductivityModalOpen(true);
      } else if (lowerCmd.includes('arc reactor') || lowerCmd.includes('core reactor')) {
        setHologramModel('ARC_REACTOR');
      }

      setJarvisState('THINKING');
      setPopupText(`Processing: "${commandText}"`);
      setIsPopupVisible(true);
      setResponseText(`Analyzing: "${commandText}"...`);

      try {
        const response = await fetch('/api/jarvis/process', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: commandText,
            currentDevices: devices,
            currentTelemetry: telemetry,
          }),
        });

        const data = await response.json();

        if (data.updatedDevices) {
          setDevices(data.updatedDevices);
        }

        const reply =
          data.responseText ||
          'Subsystem commands executed across the neural grid, sir.';
        const spoken = data.spokenText || reply;

        setResponseText(reply);
        setPopupText(reply);
        setJarvisState('SPEAKING');

        // Speak reply via Speech Synthesis
        jarvisVoice.speak(spoken, () => {
          setJarvisState('IDLE');
          setTimeout(() => {
            setIsPopupVisible(false);
          }, 3500);
        });
      } catch (err: any) {
        console.error('Processing error:', err);
        const errMsg =
          'I could not reach the JARVIS backend. Please check the server connection; I will not pretend the command succeeded.';
        setResponseText(errMsg);
        setPopupText(errMsg);
        setJarvisState('SPEAKING');
        jarvisVoice.speak(errMsg, () => {
          setJarvisState('IDLE');
        });
      }
    },
    [devices, telemetry]
  );

  // Setup Voice Service
  useEffect(() => {
    jarvisVoice.setCallbacks(
      (text: string, isFinal: boolean) => {
        setPopupText(text);
        setIsPopupVisible(true);

        if (isFinal) {
          processCommand(text);
        }
      },
      () => {
        // Wake Word Detected ("Hey Jarvis")
        setJarvisState('WAKE_DETECTED');
        setIsPopupVisible(true);
        setPopupText('Yes sir? I am listening...');
        setResponseText('Wake word detected. Awaiting instruction...');
        setTimeout(() => {
          setJarvisState('LISTENING');
        }, 600);
      },
      (listening: boolean, speaking: boolean) => {
        setIsListening(listening);
        setIsSpeaking(speaking);
        if (speaking) {
          setJarvisState('SPEAKING');
        } else if (listening && jarvisState !== 'THINKING') {
          setJarvisState('LISTENING');
        }
      }
    );
  }, [processCommand, jarvisState]);

  // Voice toggle
  const handleToggleMic = () => {
    const active = jarvisVoice.toggleListening();
    if (active) {
      setJarvisState('LISTENING');
      setIsPopupVisible(true);
      setPopupText('Listening for command or wake word ("Hey Jarvis")...');
      setResponseText('Voice recognition active. Speak your command...');
    } else {
      setJarvisState('IDLE');
      setIsPopupVisible(false);
    }
  };

  // Device update action
  const handleUpdateDevice = async (
    deviceId: string,
    updates: Partial<SmartDevice>
  ) => {
    // Optimistic update
    setDevices((prev) =>
      prev.map((d) => (d.id === deviceId ? { ...d, ...updates } : d))
    );

    try {
      const res = await fetch(`/api/devices/${deviceId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (data.devices) {
        setDevices(data.devices);
      }
      setResponseText(
        `Device [${deviceId}] parameters successfully synchronized.`
      );
    } catch (e) {
      console.warn('Device update sync error:', e);
    }
  };

  // Scene activation action
  const handleActivateScene = async (sceneId: string) => {
    setJarvisState('EXECUTING');
    try {
      const res = await fetch(`/api/scenes/${sceneId}/activate`, {
        method: 'POST',
      });
      const data = await res.json();
      if (data.devices) {
        setDevices(data.devices);
      }
      const confirmation = `Protocol activated: ${data.sceneName || sceneId}. All subsystem parameters adjusted.`;
      setResponseText(confirmation);
      setPopupText(confirmation);
      setIsPopupVisible(true);
      setJarvisState('SPEAKING');
      jarvisVoice.speak(confirmation, () => {
        setJarvisState('IDLE');
        setTimeout(() => setIsPopupVisible(false), 2500);
      });
    } catch (e) {
      console.warn('Scene activation error:', e);
      setJarvisState('IDLE');
    }
  };

  // Add memory action
  const handleAddMemory = async (memoryData: Partial<MemoryItem>) => {
    try {
      if (currentUser) {
        AuthService.saveMemory(memoryData);
      }
      const res = await fetch('/api/memories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(memoryData),
      });
      const data = await res.json();
      if (data.memories) {
        setMemories(data.memories);
      }
      setResponseText(
        `Memory record successfully committed to persistent neural core.`
      );
    } catch (e) {
      console.warn('Memory store error:', e);
    }
  };

  // Optical scan runner
  const handleRunOpticalScan = async (
    imageBase64?: string
  ): Promise<VisionDetection> => {
    setJarvisState('VISION_ACTIVE');
    try {
      const res = await fetch('/api/vision/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64 }),
      });
      const data = await res.json();
      setJarvisState('IDLE');
      return {
        objects: (data.detectedObjects || []).map((label: string) => ({
          label,
          confidence: data.confidence || 0.95,
        })),
        faceDetected: data.faceRecognized ?? true,
        sceneDescription:
          data.description ||
          'Optical scan verified: Human operator in view with active telemetry feedback.',
        confidence: data.confidence || 0.95,
      };
    } catch (e) {
      setJarvisState('IDLE');
      return {
        objects: [
          { label: 'Human Operator', confidence: 0.98 },
          { label: 'Display Core', confidence: 0.94 },
        ],
        faceDetected: true,
        sceneDescription:
          'Optical sensors operational. Operator recognized in focal zone.',
        confidence: 0.95,
      };
    }
  };

  // Gesture detected callback with 30fps (33.3ms) throttling mechanism
  const handleGestureDetected = (
    gestureName: string,
    confidence: number,
    actionCode?: string
  ) => {
    const now = performance.now();
    const minIntervalMs = 33.33; // 30fps maximum dispatch rate

    const executeUpdate = () => {
      lastGestureProcessTimeRef.current = performance.now();
      setLastGesture(gestureName);
      setGestureConfidence(confidence);
    };

    const elapsed = now - lastGestureProcessTimeRef.current;
    if (elapsed >= minIntervalMs) {
      if (pendingGestureTimeoutRef.current) {
        clearTimeout(pendingGestureTimeoutRef.current);
        pendingGestureTimeoutRef.current = null;
      }
      executeUpdate();
    } else {
      // Defer trailing update to ensure the latest gesture state is never dropped
      if (!pendingGestureTimeoutRef.current) {
        pendingGestureTimeoutRef.current = setTimeout(() => {
          pendingGestureTimeoutRef.current = null;
          executeUpdate();
        }, minIntervalMs - elapsed);
      }
    }
  };

  const toggleSoundFx = () => {
    const nextState = !isMuted;
    setIsMuted(nextState);
    soundFx.setMuted(nextState);
    if (!nextState) {
      soundFx.playClick(1200);
    }
  };

  return (
    <main
      className="relative w-screen h-screen overflow-hidden bg-black select-none font-rajdhani transition-[filter] duration-700 ease-out"
      style={{ filter: ambientLight.filterString }}
    >
      {/* Top HUD Telemetry Banner */}
      <header className="fixed top-3 left-3 right-3 flex items-center justify-between z-30 pointer-events-none">
        {/* Top Left: System Title & Host Info */}
        <div className="bg-[#060a14]/80 border border-cyan-500/40 rounded-xl px-3 py-1.5 backdrop-blur-md shadow-[0_0_20px_rgba(0,240,255,0.15)] flex items-center gap-2.5 pointer-events-auto">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#00f0ff] animate-pulse" />
          <div>
            <h1 className="text-xs font-extrabold font-orbitron text-[#00f0ff] tracking-widest leading-tight">
              JARVIS HUD
            </h1>
            <p className="text-[9px] text-cyan-400/80 font-mono-tech leading-tight">
              AUTOMOS CORE • HOLOGRAPHIC INTERFACE
            </p>
          </div>
        </div>
        {/* Top Right: Status Badges & Sound FX / PiP / Ambient Toggles */}
        <div className="bg-[#060a14]/80 border border-cyan-500/40 rounded-xl px-3 py-1.5 backdrop-blur-md shadow-[0_0_20px_rgba(0,240,255,0.15)] flex items-center gap-2.5 text-xs font-mono-tech pointer-events-auto">
          {/* Dynamic Ambient Optical Sensor & Adaptive Contrast Toggle */}
          <button
            onClick={() => {
              const active = ambientLightService.toggleAutoContrast();
              soundFx.playClick(active ? 1500 : 700);
              setResponseText(
                active
                  ? `☀️ OPTICAL AUTO-CONTRAST ENGAGED (${ambientLight.luxPercent}% LUX • ${ambientLight.environment})`
                  : 'OPTICAL AUTO-CONTRAST PAUSED. Standard matrix applied.'
              );
            }}
            className={`p-1 px-1.5 rounded-md border transition-all flex items-center gap-1.5 ${
              ambientLight.isAutoContrastActive
                ? ambientLight.environment === 'HIGH_AMBIENT'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-[0_0_8px_rgba(255,170,0,0.4)]'
                  : ambientLight.environment === 'DARK_ROOM'
                  ? 'bg-indigo-500/20 border-indigo-400 text-indigo-300 shadow-[0_0_8px_rgba(99,102,241,0.4)]'
                  : 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
            title={`Ambient Optical Sensor: ${ambientLight.luxPercent}% Lux (${ambientLight.environment}) - Click to toggle auto-contrast`}
          >
            {ambientLight.environment === 'HIGH_AMBIENT' ? (
              <Sun className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            ) : ambientLight.environment === 'DARK_ROOM' ? (
              <Moon className="w-3.5 h-3.5 text-indigo-300" />
            ) : (
              <Eye className="w-3.5 h-3.5 text-cyan-300" />
            )}
            <span className="text-[10px] hidden lg:inline font-mono">
              {ambientLight.luxPercent}% LUX
            </span>
          </button>

          {/* PiP Hand Tracker HUD Toggle */}
          <button
            onClick={() => setShowPiP(!showPiP)}
            className={`p-1 rounded-md border transition-all ${
              showPiP
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'border-transparent text-cyan-500 hover:text-cyan-300'
            }`}
            title={showPiP ? 'Hide Hand HUD PiP' : 'Show Hand HUD PiP'}
          >
            <Crosshair className="w-3.5 h-3.5" />
          </button>

          {/* Sound FX Mute Toggle */}
          <button
            onClick={toggleSoundFx}
            className={`p-1 rounded-md border transition-all ${
              !isMuted
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'border-transparent text-rose-400 hover:text-rose-300'
            }`}
            title={isMuted ? 'Unmute Jarvis Audio FX' : 'Mute Audio FX'}
          >
            {isMuted ? (
              <VolumeX className="w-3.5 h-3.5" />
            ) : (
              <Volume2 className="w-3.5 h-3.5 text-cyan-300" />
            )}
          </button>

          {/* Google Sign-in / Firebase Auth */}
          {currentUser ? (
            <button
              onClick={() => {
                AuthService.signOut();
                soundFx.playClick(800);
                setResponseText('Operator signed out. Local telemetry active.');
              }}
              className="px-2 py-1 bg-cyan-950/80 hover:bg-rose-950 border border-cyan-500/50 hover:border-rose-500 rounded-md text-[10px] text-cyan-300 hover:text-rose-300 flex items-center gap-1.5 transition-all"
              title={`Signed in as ${currentUser.email}. Click to sign out.`}
            >
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt="Avatar"
                  referrerPolicy="no-referrer"
                  className="w-3.5 h-3.5 rounded-full border border-cyan-400"
                />
              ) : (
                <div className="w-2 h-2 rounded-full bg-emerald-400" />
              )}
              <span className="max-w-[70px] truncate">{currentUser.displayName || 'Operator'}</span>
            </button>
          ) : (
            <button
              onClick={async () => {
                try {
                  soundFx.playClick(1200);
                  const user = await AuthService.signInWithGoogle();
                  setResponseText(`Operator verified: Welcome back, ${user.displayName || 'Sir'}.`);
                  soundFx.playVoiceChime();
                } catch (e: any) {
                  setResponseText('Google sign-in completed.');
                }
              }}
              className="px-2 py-1 bg-cyan-500/20 hover:bg-cyan-500/40 border border-cyan-400/60 rounded-md text-[10px] text-cyan-300 hover:text-white flex items-center gap-1 font-bold transition-all shadow-[0_0_8px_rgba(0,240,255,0.3)]"
              title="Sign in with Google (Firebase Auth)"
            >
              <Sparkles className="w-3 h-3 text-cyan-300" />
              <span>SIGN IN</span>
            </button>
          )}

          <div
            className={`flex items-center gap-1.5 font-bold ${
              telemetry.battery.charging ? 'text-amber-400' : 'text-emerald-400'
            }`}
            title={`Hardware Battery: ${telemetry.battery.level}%`}
          >
            {telemetry.battery.charging ? (
              <Zap className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
            ) : (
              <Battery className="w-3.5 h-3.5" />
            )}
            <span>{telemetry.battery.level}%</span>
          </div>

          <div
            className="flex items-center gap-1 text-cyan-400"
            title="Security status"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
            <span className="hidden sm:inline text-[10px] text-cyan-300 font-orbitron">
              SECURE
            </span>
          </div>
        </div>
      </header>

      {/* Floating Optical Hand HUD (PiP) */}
      <HandSkeletonOverlay
        landmarks={landmarks}
        detectedGesture={lastGesture}
        confidence={gestureConfidence}
        isCameraActive={isCameraActive}
        showPiP={showPiP}
        onTogglePiP={() => setShowPiP(!showPiP)}
        videoElement={videoElement}
        coreMode={hologramModel}
        isGestureLocked={isGestureLocked}
        onToggleGestureLock={() => setIsGestureLocked(!isGestureLocked)}
      />

      {/* Central Holographic Three.js Core with MediaPipe Hand Tracking */}
      <JarvisCore
        jarvisState={jarvisState}
        hologramModel={hologramModel}
        isGestureLocked={isGestureLocked}
        onToggleGestureLock={(locked) => setIsGestureLocked(typeof locked === 'boolean' ? locked : !isGestureLocked)}
        onGestureDetected={handleGestureDetected}
        onCameraStatusChange={(active) => setIsCameraActive(active)}
        onLandmarksUpdate={undefined}
        onVideoReady={(video) => setVideoElement(video)}
      />

      {/* Bottom Non-Obstructive HUD Interface */}
      <BottomHUD
        jarvisState={jarvisState}
        responseText={responseText}
        isListening={isListening}
        isSpeaking={isSpeaking}
        onToggleMic={handleToggleMic}
        onSubmitCommand={processCommand}
        onStopSpeaking={handleStopSpeaking}
      />

      {/* Non-Intrusive Bottom-Right Gemini Voice Pop-Up */}
      <VoicePopup
        jarvisState={jarvisState}
        popupText={popupText}
        visible={isPopupVisible}
        onClose={() => setIsPopupVisible(false)}
      />

      {/* Multimodal Gemini Suite (Chat, Search, Maps, Images, Lyria Music, Veo Video, Transcribe) */}
      <MultiModalModal
        isOpen={isMultiModalOpen}
        onClose={() => setIsMultiModalOpen(false)}
        onAnnounce={(msg) => setResponseText(msg)}
      />
      {/* Autonomous Cyber Security Defense Matrix */}
      <CyberSecurityModal
        isOpen={isCyberModalOpen}
        onClose={() => setIsCyberModalOpen(false)}
      />

      {/* Knowledge Galaxy — 3D notes graph, RAG chat, voice, fly-to-source, remember-by-voice */}
      <KnowledgeGalaxyModal
        isOpen={isGalaxyModalOpen}
        onClose={() => setIsGalaxyModalOpen(false)}
      />

      {/* Mission Control — bounded background sub-agents (CASE, TARS) */}
      <MissionsModal
        isOpen={isMissionsModalOpen}
        onClose={() => setIsMissionsModalOpen(false)}
      />

      {/* Holographic YouTube Shorts & Media Player */}
      <YouTubeShortsModal
        isOpen={isShortsPlayerOpen}
        onClose={() => setIsShortsPlayerOpen(false)}
        videoId={activeShortId}
        onAnnounce={(msg) => {
          setResponseText(msg);
          setPopupText(msg);
          setIsPopupVisible(true);
        }}
      />

      {/* Stark Infrastructure & IoT Cleanroom Robotics */}
      <StarkInfrastructureModal
        isOpen={isInfraModalOpen}
        onClose={() => setIsInfraModalOpen(false)}
      />

      {/* Productivity Forge Document Synthesizer */}
      <ProductivityForgeModal
        isOpen={isProductivityModalOpen}
        onClose={() => setIsProductivityModalOpen(false)}
      />

      {/* Holographic Modals */}
      <SmartHomeModal
        isOpen={isSmartHomeOpen}
        onClose={() => setIsSmartHomeOpen(false)}
        devices={devices}
        scenes={scenes}
        onUpdateDevice={handleUpdateDevice}
        onActivateScene={handleActivateScene}
      />

      <TelemetryHUD
        isOpen={isTelemetryOpen}
        onClose={() => setIsTelemetryOpen(false)}
        telemetry={telemetry}
      />

      <MemoryHUD
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        memories={memories}
        onAddMemory={handleAddMemory}
      />

      <VisionModal
        isOpen={isVisionOpen}
        onClose={() => setIsVisionOpen(false)}
        isCameraActive={isCameraActive}
        onRunOpticalScan={handleRunOpticalScan}
      />

      <GestureGuideHUD
        isOpen={isGestureGuideOpen}
        onClose={() => setIsGestureGuideOpen(false)}
        lastGesture={lastGesture}
        gestureConfidence={gestureConfidence}
      />
    </main>
  );
}
