import React, { useEffect, useRef, useState } from 'react';
import { Crosshair, Zap, Layers, Sparkles, Activity, ShieldAlert } from 'lucide-react';
import { handTrackingService } from '../services/handTrackingService';

export interface HandLandmark {
  x: number;
  y: number;
  z?: number;
}

interface HandSkeletonOverlayProps {
  landmarks: HandLandmark[][] | HandLandmark[] | null;
  detectedGesture: string;
  confidence: number;
  isCameraActive: boolean;
  onToggleCamera?: () => void;
  showPiP?: boolean;
  onTogglePiP?: () => void;
  videoElement?: HTMLVideoElement | null;
  coreMode?: string;
}

// Landmark connectivity bones definition (21 points)
const HAND_CONNECTIONS = [
  // Thumb
  [0, 1],
  [1, 2],
  [2, 3],
  [3, 4],
  // Index
  [0, 5],
  [5, 6],
  [6, 7],
  [7, 8],
  // Middle
  [0, 9],
  [9, 10],
  [10, 11],
  [11, 12],
  // Ring
  [0, 13],
  [13, 14],
  [14, 15],
  [15, 16],
  // Pinky
  [0, 17],
  [17, 18],
  [18, 19],
  [19, 20],
  // Palm base bridge
  [5, 9],
  [9, 13],
  [13, 17],
];

export const HandSkeletonOverlay: React.FC<HandSkeletonOverlayProps> = ({
  landmarks,
  detectedGesture,
  confidence,
  isCameraActive,
  showPiP = true,
  onTogglePiP,
  videoElement,
  coreMode = 'ARC_REACTOR',
  isGestureLocked = false,
  onToggleGestureLock,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // 1. Draw background video frame if available in PiP
      if (videoElement && videoElement.readyState >= 2) {
        ctx.save();
        // Mirror horizontal for natural selfie view
        ctx.translate(w, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(videoElement, 0, 0, w, h);
        ctx.restore();

        // Dark sci-fi cyan grading overlay
        ctx.fillStyle = 'rgba(2, 10, 24, 0.68)';
        ctx.fillRect(0, 0, w, h);

        // Tech grid lines
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.12)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let x = 20; x < w; x += 30) {
          ctx.moveTo(x, 0);
          ctx.lineTo(x, h);
        }
        for (let y = 20; y < h; y += 30) {
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
        }
        ctx.stroke();
      }

      // Query real-time zero-lag landmarks from hand tracking bus (falling back to props)
      const serviceLandmarks = handTrackingService.getLandmarks();
      const rawLandmarks = serviceLandmarks || landmarks;

      // Normalize input into an array of hands: HandLandmark[][]
      let handsList: HandLandmark[][] = [];
      if (rawLandmarks && Array.isArray(rawLandmarks) && rawLandmarks.length > 0) {
        if (Array.isArray(rawLandmarks[0])) {
          handsList = (rawLandmarks as HandLandmark[][]).filter((h) => h && h.length >= 21);
        } else if (rawLandmarks.length >= 21) {
          handsList = [rawLandmarks as HandLandmark[]];
        }
      }

      const time = performance.now() * 0.003;

      if (handsList.length > 0) {
        const palmCenters: { x: number; y: number; handIdx: number }[] = [];

        // Palettes for Hand 1 (Cyan/Blue) vs Hand 2 (Amber/Gold/Crimson), with security amber if locked
        const handThemes = isGestureLocked
          ? [
              {
                primary: '#ffaa00',
                accent: '#fff2aa',
                glow: 'rgba(255, 170, 0, 0.85)',
                jointTip: '#ff4444',
                label: 'SENSOR 1 [LOCKED]',
              },
              {
                primary: '#ff5533',
                accent: '#ffd2aa',
                glow: 'rgba(255, 85, 51, 0.85)',
                jointTip: '#ffaa00',
                label: 'SENSOR 2 [LOCKED]',
              },
            ]
          : [
              {
                primary: '#00f0ff',
                accent: '#ffffff',
                glow: 'rgba(0, 240, 255, 0.85)',
                jointTip: '#00ff88',
                label: 'SENSOR 1 [PRIMARY]',
              },
              {
                primary: '#ffaa00',
                accent: '#fff2aa',
                glow: 'rgba(255, 170, 0, 0.85)',
                jointTip: '#ff3366',
                label: 'SENSOR 2 [SECONDARY]',
              },
            ];

        handsList.forEach((handPoints, handIdx) => {
          const theme = handThemes[handIdx % handThemes.length];
          // Convert normalized coords to mirrored pixel coords
          const points = handPoints.map((pt) => ({
            x: (1 - pt.x) * w,
            y: pt.y * h,
            z: pt.z || 0,
          }));

          // 1. Draw connecting laser bones
          ctx.save();
          ctx.shadowColor = theme.primary;
          ctx.shadowBlur = 8;
          ctx.lineWidth = 2.2;

          HAND_CONNECTIONS.forEach(([startIdx, endIdx]) => {
            const p1 = points[startIdx];
            const p2 = points[endIdx];
            if (!p1 || !p2) return;

            const grad = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
            grad.addColorStop(0, theme.glow);
            grad.addColorStop(0.5, 'rgba(255, 255, 255, 0.95)');
            grad.addColorStop(1, theme.glow);

            ctx.strokeStyle = grad;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          });
          ctx.restore();

          // 2. Draw Pinch Laser Beam (Thumb Tip [4] to Index Tip [8])
          const thumb = points[4];
          const index = points[8];
          if (thumb && index) {
            const pinchDist = Math.hypot(thumb.x - index.x, thumb.y - index.y);
            const isPinching = pinchDist < 30;

            ctx.save();
            ctx.strokeStyle = isPinching ? '#00ff88' : theme.primary;
            ctx.lineWidth = isPinching ? 2.5 : 1.2;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(thumb.x, thumb.y);
            ctx.lineTo(index.x, index.y);
            ctx.stroke();
            ctx.setLineDash([]);

            // Pinch distance tag
            const midX = (thumb.x + index.x) * 0.5;
            const midY = (thumb.y + index.y) * 0.5;
            ctx.fillStyle = isPinching ? '#00ff88' : theme.primary;
            ctx.font = '9px monospace';
            ctx.fillText(`P:${(pinchDist / w).toFixed(2)}`, midX + 4, midY - 4);
            ctx.restore();
          }

          // 3. Draw Joint Nodes with glowing holographic rings
          points.forEach((p, idx) => {
            const isTip = [4, 8, 12, 16, 20].includes(idx);
            const isWrist = idx === 0;
            const r = isTip ? 4.5 : isWrist ? 5.5 : 3;

            ctx.save();
            ctx.shadowColor = isTip ? theme.jointTip : theme.primary;
            ctx.shadowBlur = 8;

            // Outer ring
            ctx.strokeStyle = isTip ? theme.jointTip : theme.primary;
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.arc(p.x, p.y, r + 1.5, 0, Math.PI * 2);
            ctx.stroke();

            // Inner solid circle
            ctx.fillStyle = isTip ? '#ffffff' : theme.primary;
            ctx.beginPath();
            ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          });

          // 4. Palm Center Arc-Reactor Targeting Reticle
          const wrist = points[0];
          const middleMCP = points[9];
          if (wrist && middleMCP) {
            const palmCenterX = (wrist.x + middleMCP.x) * 0.5;
            const palmCenterY = (wrist.y + middleMCP.y) * 0.5;
            palmCenters.push({ x: palmCenterX, y: palmCenterY, handIdx });

            ctx.save();
            ctx.translate(palmCenterX, palmCenterY);

            // Rotating outer ring
            ctx.rotate(time * (handIdx === 0 ? 0.8 : -0.8));
            ctx.strokeStyle = theme.glow;
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(0, 0, 18, 0, Math.PI * 1.5);
            ctx.stroke();

            // Inner counter-rotating ring
            ctx.rotate(-time * 1.6);
            ctx.strokeStyle = theme.primary;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(0, 0, 10, 0, Math.PI * 1.2);
            ctx.stroke();

            // Crosshairs
            ctx.strokeStyle = theme.primary;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(-22, 0);
            ctx.lineTo(-12, 0);
            ctx.moveTo(12, 0);
            ctx.lineTo(22, 0);
            ctx.moveTo(0, -22);
            ctx.lineTo(0, -12);
            ctx.moveTo(0, 12);
            ctx.lineTo(0, 22);
            ctx.stroke();

            // Center repulsor node
            ctx.fillStyle = '#ffffff';
            ctx.shadowColor = theme.primary;
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();

            // Coordinates readout & Hand Tag
            ctx.fillStyle = theme.primary;
            ctx.font = '9px monospace';
            ctx.fillText(
              `H${handIdx + 1} [${(palmCenterX / w).toFixed(2)},${(palmCenterY / h).toFixed(2)}]`,
              palmCenterX + 22,
              palmCenterY - 4
            );
          }
        });

        // 5. TWO-HANDS BI-MANUAL QUANTUM LASER ENERGY BRIDGE
        if (palmCenters.length >= 2) {
          const p1 = palmCenters[0];
          const p2 = palmCenters[1];
          const spanDist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
          const spanRatio = spanDist / w;

          ctx.save();
          // Glowing laser linkage between the two palms
          ctx.shadowColor = '#00f0ff';
          ctx.shadowBlur = 12;

          const bridgeGrad = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
          bridgeGrad.addColorStop(0, 'rgba(0, 240, 255, 0.95)');
          bridgeGrad.addColorStop(0.5, 'rgba(255, 255, 255, 1.0)');
          bridgeGrad.addColorStop(1, 'rgba(255, 170, 0, 0.95)');

          ctx.strokeStyle = bridgeGrad;
          ctx.lineWidth = 2.5;
          ctx.setLineDash([5, 4]);
          ctx.lineDashOffset = -time * 20;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
          ctx.setLineDash([]);

          // Center Bi-Manual Quantum Telemetry Badge
          const midX = (p1.x + p2.x) * 0.5;
          const midY = (p1.y + p2.y) * 0.5;

          // Background chip
          ctx.fillStyle = isGestureLocked ? 'rgba(34, 14, 6, 0.92)' : 'rgba(6, 14, 34, 0.9)';
          ctx.strokeStyle = isGestureLocked ? '#ffaa00' : '#00f0ff';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.roundRect(midX - 45, midY - 14, 90, 28, 6);
          ctx.fill();
          ctx.stroke();

          // Dual-span readout
          ctx.fillStyle = isGestureLocked ? '#ffaa00' : '#ffffff';
          ctx.font = 'bold 9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText(
            isGestureLocked ? '🔒 LOCKED' : `SPAN: ${(spanRatio * 100).toFixed(0)}%`,
            midX,
            midY - 2
          );

          ctx.fillStyle = isGestureLocked
            ? '#ff5533'
            : spanRatio > 0.45
            ? '#00ff88'
            : spanRatio < 0.2
            ? '#ff3366'
            : '#ffaa00';
          ctx.font = '8px monospace';
          ctx.fillText(
            isGestureLocked
              ? 'INPUT FROZEN'
              : spanRatio > 0.45
              ? 'EXPAND MODE'
              : spanRatio < 0.2
              ? 'COMPRESS MODE'
              : 'BI-MANUAL LINK',
            midX,
            midY + 9
          );
          ctx.textAlign = 'start';
          ctx.restore();
        }

        // 6. Watermark for Locked State
        if (isGestureLocked) {
          ctx.save();
          ctx.fillStyle = 'rgba(255, 170, 0, 0.9)';
          ctx.font = 'bold 9px monospace';
          ctx.textAlign = 'center';
          ctx.fillText('🔒 GESTURE LOCK ENGAGED', w * 0.5, 18);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
          ctx.font = '8px monospace';
          ctx.fillText('[CROSS WRISTS "X" OR TAP TO UNLOCK]', w * 0.5, 30);
          ctx.textAlign = 'start';
          ctx.restore();
        }
      } else {
        // Standby scan line animation
        const scanY = (performance.now() * 0.08) % h;
        ctx.strokeStyle = 'rgba(0, 240, 255, 0.4)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, scanY);
        ctx.lineTo(w, scanY);
        ctx.stroke();

        ctx.fillStyle = 'rgba(0, 240, 255, 0.65)';
        ctx.font = '10px monospace';
        ctx.fillText('DUAL SENSORS: SEARCHING HANDS...', w * 0.12, h * 0.5);
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [landmarks, videoElement, isGestureLocked]);

  if (!showPiP) return null;

  let activeHandsCount = 0;
  if (landmarks && Array.isArray(landmarks)) {
    if (landmarks.length > 0 && Array.isArray(landmarks[0])) {
      activeHandsCount = (landmarks as HandLandmark[][]).filter((h) => h && h.length >= 21).length;
    } else if (landmarks.length >= 21) {
      activeHandsCount = 1;
    }
  }

  return (
    <div
      id="pip-hand-hud"
      className="fixed top-20 right-4 z-40 w-60 sm:w-72 h-48 sm:h-52 bg-[#040814]/90 border border-cyan-500/50 rounded-2xl shadow-[0_0_25px_rgba(0,240,255,0.25)] overflow-hidden backdrop-blur-md flex flex-col font-mono-tech transition-all animate-fadeIn"
    >
      {/* HUD Header */}
      <div className="flex items-center justify-between px-2.5 py-1.5 border-b text-[10px] bg-cyan-950/80 border-cyan-500/40">
        <div className="flex items-center gap-1.5">
          <Crosshair className="w-3.5 h-3.5 animate-spin text-cyan-400" style={{ animationDuration: '6s' }} />
          <span className="font-bold tracking-wider font-orbitron text-[10px] text-cyan-300">
            DUAL SENSORS
          </span>
        </div>
        <div className="flex items-center gap-2">
          {/* Dual Sensor Status Indicators */}
          <div className="flex items-center gap-1">
            <span
              className={`w-2 h-2 rounded-full ${
                activeHandsCount >= 1 ? 'bg-cyan-400 animate-ping' : isCameraActive ? 'bg-cyan-900' : 'bg-rose-500'
              }`}
              title="Hand Sensor 1 (Primary)"
            />
            <span
              className={`w-2 h-2 rounded-full ${
                activeHandsCount >= 2 ? 'bg-amber-400 animate-ping' : isCameraActive ? 'bg-amber-950' : 'bg-rose-500'
              }`}
              title="Hand Sensor 2 (Secondary)"
            />
          </div>
          {onTogglePiP && (
            <button
              onClick={onTogglePiP}
              className="text-cyan-400/80 hover:text-white text-[10px] px-1 hover:bg-cyan-900 rounded"
              title="Minimize PiP"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Canvas Stream */}
      <div className="relative flex-1 bg-black">
        {/* Canvas Stream with subtle motion blur CSS filter for seamless visual fluidity */}
        <canvas
          ref={canvasRef}
          width={300}
          height={210}
          className="w-full h-full object-cover [filter:blur(0.45px)_contrast(1.06)_brightness(1.02)] [will-change:filter]"
        />

        {/* Sensor Mode Status Bar */}
        <div className="absolute top-2 left-2 flex items-center gap-1.5">
          <span className="text-[9px] font-mono-tech px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-300">
            {activeHandsCount === 2
              ? '⚡ 2 HANDS DETECTED (BI-MANUAL)'
              : activeHandsCount === 1
              ? '✋ 1 HAND DETECTED (SINGLE)'
              : 'STANDBY (2 HANDS READY)'}
          </span>
        </div>

        {/* Live Detected Gesture HUD Badge */}
        {detectedGesture && (
          <div className="absolute bottom-2 left-2 right-2 bg-[#060e22]/90 border border-cyan-500/60 rounded px-2 py-1 flex items-center justify-between text-[10px] shadow-[0_0_10px_rgba(0,240,255,0.3)]">
            <span className="text-cyan-200 truncate font-semibold">
              {detectedGesture}
            </span>
            <span className="text-emerald-400 font-bold ml-1">
              {(confidence * 100).toFixed(0)}%
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
