/**
 * Feature catalog inspired by the requested JARVIS demonstrations.
 * It describes capabilities without pretending browser code has permissions it
 * does not have. Native/device actions are routed through explicit bridges.
 */
export type FeatureDomain = 'voice' | 'device' | 'business' | 'files' | 'web' | 'vision' | 'security' | 'developer';

export interface DynamicFeature {
  id: string;
  domain: FeatureDomain;
  label: string;
  requiresNativeBridge?: boolean;
  requiresApproval?: boolean;
  enabledByDefault?: boolean;
}

export const DYNAMIC_FEATURES: readonly DynamicFeature[] = [
  { id: 'voice.double-clap-wake', domain: 'voice', label: 'Double-clap wake', enabledByDefault: true },
  { id: 'voice.wake-word', domain: 'voice', label: 'Hey JARVIS wake word', enabledByDefault: true },
  { id: 'device.launch-app', domain: 'device', label: 'Launch authorized app', requiresNativeBridge: true, requiresApproval: true },
  { id: 'device.settings', domain: 'device', label: 'Open authorized system setting', requiresNativeBridge: true, requiresApproval: true },
  { id: 'device.screen-control', domain: 'device', label: 'Authorized screen automation', requiresNativeBridge: true, requiresApproval: true },
  { id: 'device.multi-phone', domain: 'device', label: 'Authorized multi-device control', requiresNativeBridge: true, requiresApproval: true },
  { id: 'device.screen-mirror', domain: 'device', label: 'Authorized screen mirroring', requiresNativeBridge: true, requiresApproval: true },
  { id: 'device.global-hotkeys', domain: 'device', label: 'Authorized global hotkeys', requiresNativeBridge: true, requiresApproval: true },
  { id: 'business.command-center', domain: 'business', label: 'Business command center', requiresApproval: true },
  { id: 'business.lead-follow-up', domain: 'business', label: 'Lead qualification and follow-up', requiresApproval: true },
  { id: 'business.multi-message', domain: 'business', label: 'Multi-message conversation handling', requiresApproval: true },
  { id: 'business.stop-sequence', domain: 'business', label: 'Stop-response sequence handling', requiresApproval: true },
  { id: 'business.calendar-scheduling', domain: 'business', label: 'Conversational scheduling', requiresApproval: true },
  { id: 'business.team-routing', domain: 'business', label: 'Route qualified leads to authorized team channels', requiresApproval: true },
  { id: 'business.custom-integration', domain: 'business', label: 'Custom CRM/calendar integration', requiresApproval: true },
  { id: 'files.organize', domain: 'files', label: 'Intelligent file organization', requiresApproval: true },
  { id: 'web.browser-agent', domain: 'web', label: 'Authorized browser agent', requiresApproval: true },
  { id: 'vision.inventory', domain: 'vision', label: 'Visual inventory / object audit', requiresApproval: true },
  { id: 'security.audit', domain: 'security', label: 'Defensive security audit', requiresApproval: true },
  { id: 'developer.repository', domain: 'developer', label: 'Authorized repository editing', requiresApproval: true },
  { id: 'developer.local-coding', domain: 'developer', label: 'Local coding workspace automation', requiresNativeBridge: true, requiresApproval: true },
  { id: 'developer.cloud-workspace', domain: 'developer', label: 'Authorized cloud workspace automation', requiresApproval: true },
] as const;

export function getDynamicFeature(id: string): DynamicFeature | undefined {
  return DYNAMIC_FEATURES.find((feature) => feature.id === id);
}
