# Demonstration Feature Update

This update adds implementation contracts inspired by the requested JARVIS demonstrations.

## Included
- Local double-clap wake with lifecycle recovery and low-overhead audio analysis.
- Voice wake-word and barge-in behavior already present in the project.
- Explicit native-bridge capability contracts for authorized phone/app/settings control.
- Multi-device control contract (requires a configured authorized bridge).
- Business command-center primitives for lead follow-up, scheduling, reporting and data sync.
- Browser/file/repository/vision/security capability contracts with approval gates.

## Important
The browser build cannot grant itself Android-wide permissions. Device actions require the
native Android bridge and explicit user authorization. External services (CRM, Gmail, calendar,
ADB, etc.) require their own authenticated connectors.

The double-clap feature is intentionally local to the browser microphone and stops when the page
is backgrounded to reduce battery/thermal load.
