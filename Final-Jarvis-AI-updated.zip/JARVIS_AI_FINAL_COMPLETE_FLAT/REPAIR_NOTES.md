# JARVIS AI — Repair Build

This build is intended to preserve the existing holographic UI while repairing the application logic underneath it.

## UI-protected changes
- Preserved the existing JARVIS visual structure and holographic core.
- Removed the MARK V / MARK 85 armor subsystem and its server command path.
- Removed the Satellite Grid / orbital-recon subsystem and stale references.

## Code and reliability repairs
- Authentication now uses `JARVIS_AUTH_SECRET` and safely compares secrets without throwing on different-length inputs.
- Authentication tokens use cryptographically secure random bytes.
- Removed hard-coded personal/system claims from the main AI system instruction.
- Removed fake Gemini/local success responses. Missing Gemini configuration now produces an explicit service error.
- Removed the unsupported `temperature` parameter from the Gemini 3.7 Flash generation request.
- Updated the multimodal UI's default model label to Gemini 3.7 Flash.
- Updated image-generation UI references from the retired `gemini-3.1-flash-image-preview` to `gemini-3.1-flash-image`.
- Removed hard-coded battery, YouTube statistics, contacts, route, PowerPoint, WhatsApp, VS Code, alarm, media-playback and Android-action success claims.
- Memory queries now search the current in-process memory records instead of returning one hard-coded historical answer.
- Telemetry responses now use client-supplied telemetry rather than invented network/IoT values.
- Browser/device capability limitations are reported honestly when no real integration exists.

## Important runtime note
This is still a web/full-stack development project, not an APK. A browser cannot directly control Android system functions, PC shutdown, WhatsApp, physical IoT devices, accessibility scrolling, etc. Those require explicit platform integrations and permissions.

## Gemini model alignment
- Main reasoning: `gemini-3.7-flash`
- Real-time voice foundation available from Google: `gemini-3.1-flash-live-preview`
- TTS: `gemini-3.1-flash-tts-preview`
- Transcription: `gemini-3.5-transcribe`
- Image generation: `gemini-3.1-flash-image`

## Verification
- Source archive extracted successfully.
- Removed-feature references were searched after editing.
- TypeScript source was inspected for the targeted API/model/configuration issues.
- A complete dependency install/build could not be completed in this environment because `npm install` exceeded the execution window; therefore this archive should be treated as a repaired source build that still needs a real Node.js dependency install/build test.


## 2026-08-30 engineering pass
- Removed the remaining Nanotech Armor gesture protocol and armor sound effect.
- Verified no SATELLITE/ARMOR subsystem references remain in executable source paths.
- Updated main reasoning fallback to Gemini 3.6 Flash instead of the older 3.5 Flash Lite.
- Added `/api/capabilities` so the UI/backend can distinguish real integrations from unavailable ones.
- Vision responses no longer fabricate object lists, face recognition, or confidence values.
- Search/Maps no-key fallbacks no longer pretend a result was produced.
- Main vision route now uses Gemini 3.7 Flash.
- Added optional `JARVIS_REASONING_MODEL` and `JARVIS_LIVE_MODEL` environment settings.
- Preserved the existing UI components and styling.

## Important build note
The archive does not include `node_modules`. A full dependency installation could not be completed in the isolated build environment because package installation exceeded the execution time available here. The project therefore remains a normal source project that installs its declared dependencies when opened in a Node-capable development environment.

## 2026-09-02 engineering pass — AI orchestration layer
- Added `src/server/providers/geminiProvider.ts` and `src/server/providers/claudeProvider.ts` — thin, isolated provider wrappers with honest capability maps.
- Added `src/server/aiOrchestrator.ts` — single orchestration layer (`POST /api/ai/orchestrate`, `GET /api/ai/capabilities`) that selects Gemini, Claude, or both based on task/credentials, with explicit fallback and no fabricated responses when a provider is unconfigured (reports `EXTERNAL_CREDENTIAL_REQUIRED`).
- Added `ANTHROPIC_API_KEY` and `JARVIS_CLAUDE_MODEL` to `.env.example`. Key is read server-side only via `process.env`; never sent to the client. `.gitignore` already excludes `.env*`.
- Added `@anthropic-ai/sdk` to `package.json` dependencies.
- Did not modify any existing `/api/gemini/*` routes, UI components, or visual styling. Dual-provider mode ("both") only fires when explicitly requested — it is not the default path, to avoid doubling latency/cost on ordinary requests.
- Not yet done in this pass (flagged, not faked): voice wake-word pipeline audit, Three.js render-loop profiling. These need dedicated passes with a working `npm install` since correctness can't be fully verified without running the app (no network access in this environment).

## 2026-09-02 engineering pass 2 — hand-tracking lifecycle/leak fix
- Found and fixed a real bug in `JarvisCore.tsx`'s camera/MediaPipe pipeline: `isDestroyed` was declared *inside* the async `initMediaPipePipeline` closure, so the component's cleanup function (on unmount) could never actually see or flip it. The inference loop kept calling `handsInstance.send()` against a torn-down video element after unmount — this is very likely a real contributor to the "laggy/unresponsive tracking" symptom, since after any remount (e.g. reopening a modal) two overlapping inference loops could end up running at once.
- Lifted `isDestroyed` to effect scope; cleanup now sets it before anything else runs.
- The `requestVideoFrameCallback` path never stored its handle, so it was never cancelable — only the `requestAnimationFrame` fallback path was actually being canceled on unmount. Now the handle is captured and canceled via `video.cancelVideoFrameCallback()`.
- The `visibilitychange` listener and the OrbitControls `start`/`change` listeners were added on every mount and never removed — a real duplicate-listener leak on remount. Now all three are stored and explicitly removed in cleanup.
- Added `handsInstance.close()` in cleanup to release MediaPipe's WASM-backed resources instead of leaving them allocated.
- No changes to gesture logic, smoothing, thresholds, camera resolution, or any visual/JSX code — this pass was scoped strictly to the lifecycle/cleanup bug.
- Verified brace/paren balance after edit; full type-check still needs `npm install` (no network in this environment) to confirm cleanly.


## 2026-09-02 engineering pass 3 — capability registry + real file authorization
- Added `src/services/capabilityRegistry.ts`: an honest, queryable map of every feature category from the requested "Ultimate JARVIS" list (Intelligence, Vision, Web/Browser, Files, Business, Security, Location, Device/OS bridges, Health/Wearables, Autonomy). Each entry is one of `available`, `requires_credentials`, `requires_external_hardware`, `platform_restricted`, or `not_implemented` — never a blanket "yes." Exposed server-side via `GET /api/capabilities/full`.
- Explicitly marked as NOT going to be built, with reasons: satellite/geospatial access (needs a licensed provider's own key), Android system-settings access (a Chrome tab cannot receive OS-level Android permissions — needs a separate native companion app), remote-computer control (needs an authenticated bridge, not present), vitals monitoring (needs real wearable hardware; JARVIS will not estimate/simulate medical data), unrestricted network intrusion / credential bypass / unbounded autonomy (deliberately out of scope, not a missing feature).
- Added `src/services/fileAccessService.ts`: a real File System Access API wrapper. Every file/folder grant requires an explicit user-gesture picker dialog (`showOpenFilePicker` / `showDirectoryPicker`); nothing is readable without that. Includes live permission re-verification (`queryPermission`/`requestPermission`) since OS-level grants can be revoked outside the app. Falls back honestly (`isSupported()` returns false) in browsers without the API rather than pretending it works.
- No UI/visual changes. These are backend/service-layer additions only; wiring them into HUD panels (e.g. a capability status view) is a UI-layer task for a follow-up pass and was intentionally left alone here per the UI lock.

## 2026-09-02 engineering pass 4 — Knowledge Galaxy (notes → 3D graph → voice-driven RAG chat)
Implemented as an original feature matching the *functional description* requested (3D graph of markdown notes, chat that answers only from them, voice in/out, camera fly-to-source, personality, voice-driven "remember"). This is new code written against this repo's own architecture — it does not reuse or reproduce anyone else's source files.

Backend:
- `src/server/notesService.ts` — scans `JARVIS_NOTES_DIR` (default `./notes`) for `.md` files, builds a node/link graph (node id = array index, per the spec's requirement so later lookups stay stable), links notes that mention each other's titles or use `[[wikilinks]]`. Full note text is kept server-side only (`fullTextById`), never sent to the client — the client only gets id/label/group/excerpt.
- `src/server/notesRoutes.ts` — `GET /api/notes/graph`, `POST /api/notes/chat` (keyword-overlap scoring, title matches weighted higher, top 6 notes fed to whichever provider is configured — Claude preferred, Gemini fallback, same honest-fallback pattern as the main orchestrator, `EXTERNAL_CREDENTIAL_REQUIRED` if neither is configured), `POST /api/notes/remember` (writes a real `.md` file into `<notesRoot>/captures/`, re-indexes, returns the nearest existing node for the "born near" animation).
- Reuses the existing `claudeProvider`/`geminiProvider` from pass 1 rather than duplicating API-call code.

Frontend:
- `src/components/KnowledgeGalaxyModal.tsx` — new modal, styled to match the existing modal system exactly (same glass-panel/cyan/orbitron/rajdhani conventions as `VisionModal.tsx` etc.), so it fits the current design language rather than introducing a new one. Built directly on this repo's existing Three.js + OrbitControls stack — no new heavy dependency (no `3d-force-graph`/npm graph library added). Includes: starfield background, a real spring/repulsion force simulation for node layout, click-to-fly camera with neighbor highlighting, cluster-centroid fly for multi-source answers, a boot greeting with the real note count, a chat input bar, a self-contained mic button (`webkitSpeechRecognition`) so it doesn't interfere with the existing wake-word state machine, and TTS via the existing `jarvisVoice.speak()`.
- Wired into `App.tsx` via the same `useState` + conditional-render pattern already used for every other modal, and opened through the existing voice-command dispatch (phrases: "knowledge galaxy", "second brain", "my notes") — no new visible button was added, so the locked UI/GUI is unchanged. `KnowledgeGalaxyModal` is additive only; no existing component's JSX/visual output was modified.

Not done / honestly flagged:
- No default `notes/` folder or sample notes were generated — point `JARVIS_NOTES_DIR` at a real folder of `.md` files (an Obsidian vault export works) to see it populated.
- "remember that…" via the wake-word pipeline (saying it to JARVIS generally, not just inside this modal) is not wired — right now it only works while the Knowledge Galaxy modal is open, via its own mic button or text input.
- Full typecheck still needs `npm install`, which this environment cannot do (no network access). Verified by careful manual review and a string/comment/regex-aware bracket-balance check on every touched file.

## 2026-09-02 engineering pass 5 — global "remember that…" via wake-word
- Addressed the gap flagged at the end of pass 4: `processCommand` in `App.tsx` (the function every wake-word-captured command already runs through) now matches `/^remember that\b/i` directly, calls `POST /api/notes/remember`, speaks a confirmation, and opens the Knowledge Galaxy modal so the newly indexed note is visible. Works from anywhere JARVIS is listening — not just from inside the modal's own mic button.
- If the capture is empty ("remember that" with nothing after it) or the notes service doesn't respond, JARVIS says so out loud instead of silently failing.
- Note: because this path opens the modal *after* saving (rather than while it's already mounted), the note appears already indexed on open rather than playing the glow-pulse "birth" animation — that animation still fires when using the modal's own mic/text input while it's already open. Making the birth animation fire on this path too would need lifting graph state into shared context; flagged as a possible follow-up, not silently attempted.


## 2026-09-02 engineering pass 6 — real verification tooling (in response to "fix all errors, no fake completion")
Previous passes verified changes by manual review and a crude bracket-counter, which is weak and can't be trusted the way "no errors" implies. This pass used real tooling instead:

- Found that the global environment actually has the TypeScript compiler package available (`/home/claude/.npm-global/lib/node_modules/typescript`), so a genuine syntax parse of every `.ts`/`.tsx` file is possible without `npm install`. Ran it: **0 syntax errors across all 46 source files.**
- Wrote and ran a real import-resolution checker (walks every relative import, resolves it on disk, and separately flags case-sensitivity mismatches — the exact class of bug the original spec called out as a Linux risk): **all local imports resolve cleanly**, no missing files, no case mismatches.
- Cross-checked every external package actually imported in code against `package.json` dependencies: **all declared**, nothing missing.
- Checked for duplicate Express route registrations and duplicate top-level exports: **none found**.
- Checked route registration order against the Vite middleware/catch-all in `server.ts`: all `/api/*` routes (including the ones added in this session) are registered before `app.use(vite.middlewares)` and the SPA catch-all, so they won't get shadowed.
- Ran the repo's own `scripts/validate-project.mjs` static audit for real (not just referenced it): **PASS**.
- Wrote a named-import/export matcher (catches "imports X but the target file never exports X" — a common source of a working-looking file that fails at import time). It found **one real bug**: `tsconfig.json` was missing `"resolveJsonModule": true`, so `src/lib/firebase.ts`'s JSON import (`firebase-applet-config.json`) would fail `tsc --noEmit` — and `npm run lint` / `npm run validate` both run `tsc --noEmit`. **Fixed**: added `resolveJsonModule: true` to `tsconfig.json`.
- Known limitation of the matcher tool itself (not a code bug): it still flags that same JSON import because it only understands `.ts`/`.tsx` export statements, not JSON-module semantics — noted here so it isn't mistaken for an unresolved issue.

**What is still NOT verified, stated plainly:** none of this ran a real `npm install`, `vite build`, or `tsc` module-resolution pass against actual installed dependency types (React 19 types, Three.js types, Express types, etc.) — that needs network access this environment doesn't have. Syntax-correct and import-consistent is a real, meaningful bar, but it is not the same as "compiles with zero type errors" or "runs correctly in a browser." If you run `npm install && npm run validate` locally and hit something, paste the exact output here and it'll get fixed against real output instead of guesses.

## 2026-09-02 engineering pass 7 — Claude model updated to Fable 5.1
- Changed the default Claude model in `src/server/providers/claudeProvider.ts` and `.env.example` from `claude-sonnet-4-6` to `claude-fable-5-1`, per request. Still overridable via `JARVIS_CLAUDE_MODEL` in `.env`, so no code change is needed to switch models again later.

## 2026-09-02 engineering pass 8 — Mission Control (bounded background sub-agents)
Built for real, no external credentials required beyond your existing Gemini/Claude keys:
- `src/server/missionsService.ts` — in-memory mission queue. Missions run reasoning/research/drafting tasks against whichever provider is configured. Any mission description matching consequential-action language (call, dial, purchase, pay, book, deploy campaign, publish) is automatically set to `awaiting_approval` instead of running — it only executes after an explicit `POST /api/missions/:id/approve`. This is the actual mechanism behind "bounded autonomous agents" / "human approval for consequential actions" from the original spec, not just a stated policy.
- `src/server/missionsRoutes.ts` — `GET/POST /api/missions`, `GET /api/missions/:id`, `POST /api/missions/:id/approve`, `POST /api/missions/:id/cancel`.
- `src/components/MissionsModal.tsx` — new modal (same visual conventions as the others), lets you spawn a mission for CASE or TARS, watch status/log live (2s poll), approve or cancel. Wired into `App.tsx` via voice command ("mission control", "spawn", "background agent", "missions") — no new visible button, UI lock respected.

Also updated `src/services/capabilityRegistry.ts` with the full feature list from the two "Zubair Trabzada JARVIS ecosystem" breakdowns pasted into this session, each honestly tagged:
- **available now**: bounded agent tasks, background missions (this pass), generic British-accent TTS, browser geolocation, hand tracking, file-picker access.
- **requires_credentials** (buildable today if you supply the key): screen-image analysis via existing Gemini/Claude vision, code/vuln review, satellite imagery (needs a licensed provider).
- **not_implemented but legitimate** (needs the user's own third-party account + credentials, not yet scaffolded): telephony hotline, outbound autonomous calling, Telegram voice parsing, Gmail/Calendar/Docs/Sheets, invoice generation, Stripe payment links, ad-campaign deployment, Home Assistant/IoT webhooks, remote-computer control.
- **platform_restricted** (a browser app cannot do this by design, not a JARVIS gap): continuous background screen watching without a fresh permission grant, autonomous mouse/keyboard control of arbitrary desktop apps, Android OS-level settings access.
- **declined on principle, not a technical gap**: cloning a specific named real person's (e.g. an actor's) voice likeness without consent.

Nothing in this pass claims to be "done" beyond what's actually wired and runnable against your own provider keys — everything else is labeled by what it actually needs next.

## 2026-09-02 engineering pass 9 — Invoice generation
- `src/server/invoiceService.ts` + `src/server/invoiceRoutes.ts` — `POST /api/invoices/generate` returns a styled, print-ready HTML invoice. Opening it and using the browser's Print -> Save as PDF gives a real PDF. No new npm dependency added (this sandbox has no network access to verify a new binary PDF library would actually install), so this is the honest, fully-functional version rather than an unverified one.
- capabilityRegistry.ts: `invoice-generation` flipped from not_implemented to available.
