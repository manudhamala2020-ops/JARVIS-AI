import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { JarvisState } from '../types';
import { soundFx } from '../services/soundFx';
import { handTrackingService } from '../services/handTrackingService';

export type HologramModelType = 'ARC_REACTOR' | 'EXPLODED_VIEW';

interface JarvisCoreProps {
  jarvisState: JarvisState;
  hologramModel?: HologramModelType;
  isGestureLocked?: boolean;
  onToggleGestureLock?: (locked: boolean) => void;
  onGestureDetected?: (
    gestureName: string,
    confidence: number,
    actionCode?: string
  ) => void;
  onCameraStatusChange?: (active: boolean, error?: string) => void;
  onLandmarksUpdate?: (landmarks: any[] | null) => void;
  onVideoReady?: (video: HTMLVideoElement) => void;
  onSelectSubsystem?: (subsystemKey: string) => void;
}

export const JarvisCore: React.FC<JarvisCoreProps> = ({
  jarvisState,
  hologramModel = 'ARC_REACTOR',
  isGestureLocked = false,
  onToggleGestureLock,
  onGestureDetected,
  onCameraStatusChange,
  onLandmarksUpdate,
  onVideoReady,
  onSelectSubsystem,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const stateRef = useRef<JarvisState>(jarvisState);
  stateRef.current = jarvisState;
  const modelRef = useRef<HologramModelType>(hologramModel);
  modelRef.current = hologramModel;
  const lockedRef = useRef<boolean>(Boolean(isGestureLocked));
  lockedRef.current = Boolean(isGestureLocked);
  const toggleLockCallbackRef = useRef(onToggleGestureLock);
  toggleLockCallbackRef.current = onToggleGestureLock;
  const selectSubsystemRef = useRef(onSelectSubsystem);
  selectSubsystemRef.current = onSelectSubsystem;

  useEffect(() => {
    if (!containerRef.current) return;

    // =================================================================
    // 1. THREE.JS SCENE & 240FPS ULTRA-SMOOTH PIPELINE SETUP
    // =================================================================
    const scene = new THREE.Scene();
    const DEFAULT_ZOOM = 14.0;
    const width = window.innerWidth;
    const height = window.innerHeight;

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 0, DEFAULT_ZOOM);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      precision: 'highp',
    });
    renderer.setSize(width, height);
    // Crisp sub-pixel rendering optimized for battery and performance (1.25x max DPI)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.25));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    // Calibrated exposure for crisp holographic contrast without washing out
    renderer.toneMappingExposure = 0.95;

    // Clear previous children
    while (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    containerRef.current.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 3.0;
    controls.maxDistance = 25.0;

    const renderScene = new RenderPass(scene, camera);
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      0.44, // Calibrated bloom for crisp holographic neon without blinding glare
      0.20,
      0.22
    );

    const composer = new EffectComposer(renderer);
    composer.addPass(renderScene);
    composer.addPass(bloomPass);

    const jarvisGroup = new THREE.Group();
    scene.add(jarvisGroup);

    // Transform Targets with Inertial Damping
    let targetRotX = 0;
    let targetRotY = 0;
    let targetPosX = 0;
    let targetPosY = 0;
    let targetZoom = DEFAULT_ZOOM;
    let speedMultiplier = 1.0;
    let isHandTracking = false;
    let manualControlUntil = 0;

    function recenterGlobe() {
      targetPosX = 0;
      targetPosY = 0;
      targetRotX = 0;
      targetRotY = 0;
      targetZoom = DEFAULT_ZOOM;
    }

    // =================================================================
    // 2. DYNAMIC 3D HOLOGRAPHIC SUITE: ARC REACTOR
    // =================================================================
    const arcReactorGroup = new THREE.Group();

    jarvisGroup.add(arcReactorGroup);

    function createGlowTexture() {
      const canvas = document.createElement('canvas');
      canvas.width = 64;
      canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      gradient.addColorStop(0.0, 'rgba(255, 255, 255, 0.88)');
      gradient.addColorStop(0.3, 'rgba(255, 255, 255, 0.56)');
      gradient.addColorStop(0.7, 'rgba(255, 255, 255, 0.16)');
      gradient.addColorStop(1.0, 'rgba(255, 255, 255, 0.0)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 64, 64);
      return new THREE.CanvasTexture(canvas);
    }
    const particleGlowMap = createGlowTexture();

    const initialColor = new THREE.Color(0xffaa00);

    // --- MODEL 1: ARC REACTOR (Holographic Golden Core & Precision Concentric HUD Rings) ---
    const coreGeo = new THREE.IcosahedronGeometry(0.95, 2);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xffd000,
      wireframe: true,
      transparent: true,
      opacity: 0.90,
      blending: THREE.AdditiveBlending,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    arcReactorGroup.add(coreMesh);

    const haloGeo = new THREE.SphereGeometry(1.25, 32, 32);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0xff8800,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    arcReactorGroup.add(haloMesh);

    const sphereGeo = new THREE.IcosahedronGeometry(3.3, 3);
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0xffaa00,
      wireframe: true,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
    });
    const wireSphere = new THREE.Mesh(sphereGeo, wireMat);
    arcReactorGroup.add(wireSphere);

    const raysGroup = new THREE.Group();
    const rayMat = new THREE.LineBasicMaterial({
      color: 0xffcc33,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });

    for (let i = 0; i < 32; i++) {
      const rayGeo = new THREE.BufferGeometry();
      const dir = new THREE.Vector3(
        (Math.random() - 0.5) * 2,
        (Math.random() - 0.5) * 2,
        (Math.random() - 0.5) * 2
      ).normalize();
      const baseLen = 4.2 + Math.random() * 3.5;
      const end = dir.clone().multiplyScalar(baseLen);
      rayGeo.setFromPoints([new THREE.Vector3(0, 0, 0), end]);
      raysGroup.add(new THREE.Line(rayGeo, rayMat));
    }
    arcReactorGroup.add(raysGroup);

    function createHUDArc(
      innerRadius: number,
      outerWidth: number,
      startAngle: number,
      lengthAngle: number,
      rotX: number,
      rotY: number,
      rotZ: number,
      arcColor: number = 0xffaa00
    ) {
      const ringGeo = new THREE.RingGeometry(
        innerRadius,
        innerRadius + outerWidth,
        64,
        1,
        startAngle,
        lengthAngle
      );
      const ringMat = new THREE.MeshBasicMaterial({
        color: arcColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.65,
        blending: THREE.AdditiveBlending,
      });
      const arc = new THREE.Mesh(ringGeo, ringMat);
      arc.rotation.set(rotX, rotY, rotZ);
      return arc;
    }

    const arc1 = createHUDArc(3.8, 0.40, 0, Math.PI * 1.2, Math.PI / 4, 0, 0.5, 0xffbb00);
    const arc2 = createHUDArc(
      4.8,
      0.45,
      Math.PI * 0.3,
      Math.PI * 1.4,
      -Math.PI / 3,
      Math.PI / 6,
      0,
      0xff7700
    );
    const arc3 = createHUDArc(2.6, 0.25, 0, Math.PI * 2, 0, 0, 0, 0xffdd44);
    const arc4 = createHUDArc(5.4, 0.15, 0, Math.PI * 2, Math.PI / 6, -Math.PI / 4, 0, 0xff9900);
    arcReactorGroup.add(arc1);
    arcReactorGroup.add(arc2);
    arcReactorGroup.add(arc3);
    arcReactorGroup.add(arc4);
    // Click handler for the active holographic core
    const handleCanvasClick = (_event: MouseEvent) => {
      // The locked JARVIS UI exposes only active holographic core interactions.
    };

    renderer.domElement.addEventListener('click', handleCanvasClick);

    // Exact 1800 particles as requested
    const particleCount = 1800;
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);
    const particleDistances = new Float32Array(particleCount);
    const particleAngles = new Float32Array(particleCount);
    const particleSpeeds = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      const r = 3.5 + Math.random() * 15.0;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      particlePositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = r * Math.cos(phi);

      particleDistances[i] = r;
      particleColors[i * 3] = initialColor.r;
      particleColors[i * 3 + 1] = initialColor.g;
      particleColors[i * 3 + 2] = initialColor.b;

      particleAngles[i] = theta;
      particleSpeeds[i] =
        (0.002 + Math.random() * 0.005) * (Math.random() > 0.5 ? 1 : -1);
    }

    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(particlePositions, 3)
    );
    particleGeo.setAttribute(
      'color',
      new THREE.BufferAttribute(particleColors, 3)
    );

    const particleMat = new THREE.PointsMaterial({
      size: 0.14,
      map: particleGlowMap,
      vertexColors: true,
      transparent: true,
      opacity: 0.70,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particleSystem = new THREE.Points(particleGeo, particleMat);
    jarvisGroup.add(particleSystem);

    const tempPColor = new THREE.Color();
    const tempCoreCol = new THREE.Color();
    const tempWireCol = new THREE.Color();
    const tempArcCol = new THREE.Color();

    const _hslA = { h: 0, s: 0, l: 0 };
    const _hslB = { h: 0, s: 0, l: 0 };

    /**
     * Constant-Luminance Shortest-Arc HSL Color Interpolator
     * Eliminates muddy/dull mid-transition grays and prevents blinding spikes
     */
    function lerpColorConstantLuminance(
      c1: THREE.Color,
      c2: THREE.Color,
      t: number,
      target: THREE.Color
    ): THREE.Color {
      c1.getHSL(_hslA);
      c2.getHSL(_hslB);

      let deltaH = _hslB.h - _hslA.h;
      if (deltaH > 0.5) deltaH -= 1.0;
      if (deltaH < -0.5) deltaH += 1.0;

      const h = (_hslA.h + deltaH * t + 1.0) % 1.0;
      const s = THREE.MathUtils.lerp(_hslA.s, _hslB.s, t);
      const l = THREE.MathUtils.lerp(_hslA.l, _hslB.l, t);

      // Keep saturation vivid and lightness firmly locked in the calibrated holographic window
      const clampedS = THREE.MathUtils.clamp(s, 0.90, 1.0);
      const clampedL = THREE.MathUtils.clamp(l, 0.50, 0.54);

      return target.setHSL(h, clampedS, clampedL);
    }

    // =================================================================
    // 3. COLOR WAVE CASCADE ENGINE (Constant Perceptual Luminance)
    // =================================================================
    const colorPalette = [
      0x00f0ff, // Arc Reactor Cyan
      0x00ff88, // Quantum Emerald Green
      0x00a2ff, // Stark Cobalt / Sky Blue
      0xaa33ff, // Arc Violet / Ultraviolet
      0xff3366, // Hot Rod Crimson
      0xff7700, // Plasma Orange
      0xffb300, // Hologram Amber / Gold
      0x00ffcc, // Quantum Teal
    ];
    let currentColorIndex = 0;
    let lastAutoColorTime = performance.now();
    const AUTO_COLOR_INTERVAL_MS = 18000;

    let isTransitioning = false;
    let transitionStartTime = 0;
    const WAVE_DURATION_MS = 4800;

    let startColor = new THREE.Color(0x00f0ff);
    let targetColor = new THREE.Color(0x00f0ff);

    function triggerNextColor(customHex?: number) {
      if (isTransitioning) return;
      if (customHex !== undefined) {
        startColor.copy(targetColor);
        targetColor.setHex(customHex);
      } else {
        currentColorIndex = (currentColorIndex + 1) % colorPalette.length;
        startColor.copy(targetColor);
        targetColor.setHex(colorPalette[currentColorIndex]);
      }
      isTransitioning = true;
      transitionStartTime = performance.now();
    }

    function updateUnifiedCascadeWave(now: number) {
      if (!isTransitioning) return;

      const elapsed = now - transitionStartTime;
      const progress = Math.min(elapsed / WAVE_DURATION_MS, 1.0);

      const coreProgress = Math.min(progress / 0.35, 1.0);
      const wireProgress = Math.min(
        Math.max((progress - 0.15) / 0.45, 0.0),
        1.0
      );
      const arcProgress = Math.min(Math.max((progress - 0.35) / 0.45, 0.0), 1.0);

      lerpColorConstantLuminance(startColor, targetColor, coreProgress, tempCoreCol);
      coreMat.color.copy(tempCoreCol);
      haloMat.color.copy(tempCoreCol);

      lerpColorConstantLuminance(startColor, targetColor, wireProgress, tempWireCol);
      wireMat.color.copy(tempWireCol);
      rayMat.color.copy(tempWireCol);

      lerpColorConstantLuminance(startColor, targetColor, arcProgress, tempArcCol);
      (arc1.material as THREE.MeshBasicMaterial).color.copy(tempArcCol);
      (arc2.material as THREE.MeshBasicMaterial).color.copy(tempArcCol);
      (arc3.material as THREE.MeshBasicMaterial).color.copy(tempArcCol);
      (arc4.material as THREE.MeshBasicMaterial).color.copy(tempArcCol);

      const colorAttr = particleGeo.attributes.color;
      const minR = 3.5;
      const maxR = 18.5;
      const waveRadius = minR + (maxR - minR) * progress;
      const waveBandwidth = 2.5;

      for (let i = 0; i < particleCount; i++) {
        const r = particleDistances[i];
        let particleLerp = 0;

        if (r <= waveRadius - waveBandwidth) {
          particleLerp = 1.0;
        } else if (r >= waveRadius) {
          particleLerp = 0.0;
        } else {
          particleLerp =
            1.0 - (r - (waveRadius - waveBandwidth)) / waveBandwidth;
        }

        lerpColorConstantLuminance(startColor, targetColor, particleLerp, tempPColor);
        colorAttr.setXYZ(i, tempPColor.r, tempPColor.g, tempPColor.b);
      }
      colorAttr.needsUpdate = true;

      if (progress >= 1.0) {
        isTransitioning = false;
      }
    }

    // =================================================================
    // 4. ROBUST 240Hz MULTI-GESTURE KINEMATICS ENGINE
    // =================================================================
    let prevHandX: number | null = null;
    let prevHandY: number | null = null;
    let smoothHandX: number | null = null;
    let smoothHandY: number | null = null;
    let smoothPalmSize: number | null = null;
    let prevPalmSize: number | null = null;

    // Two-hand bi-manual kinematics tracking
    let prevHandsDistance: number | null = null;
    let prevHandsAngle: number | null = null;

    let lastHandTimestamp = performance.now();
    let gestureCooldown = 0;
    let lostTrackCounter = 0;
    const MAX_GRACE_FRAMES = 8;

    let isIndexPinching = false;
    let isMiddlePinching = false;
    let lastGestureTriggerTime = 0;

    function resetHandTracking() {
      prevHandX = null;
      prevHandY = null;
      smoothHandX = null;
      smoothHandY = null;
      smoothPalmSize = null;
      prevPalmSize = null;
      prevHandsDistance = null;
      prevHandsAngle = null;
      isIndexPinching = false;
      isMiddlePinching = false;
      isHandTracking = false;
    }

    function getDist3D(p1: any, p2: any) {
      if (!p1 || !p2) return 1.0;
      const dx = p1.x - p2.x;
      const dy = p1.y - p2.y;
      const dz = (p1.z || 0) - (p2.z || 0);
      return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    function onResults(results: any) {
      const now = performance.now();
      const dt = Math.max((now - lastHandTimestamp) / 1000, 0.004);
      lastHandTimestamp = now;

      if (gestureCooldown > 0) gestureCooldown -= dt;

      if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        lostTrackCounter = 0;
        isHandTracking = true;
        const handsList = results.multiHandLandmarks;

        // Instant zero-allocation update to hand tracking bus (no React re-render bottleneck)
        handTrackingService.updateLandmarks(handsList);

        if (onLandmarksUpdate) {
          onLandmarksUpdate(handsList);
        }

        // =============================================================
        // SCENARIO A: DUAL HANDS (2 SENSORS ACTIVE) BI-MANUAL GESTURES
        // =============================================================
        if (handsList.length >= 2) {
          const h1 = handsList[0];
          const h2 = handsList[1];

          if (h1 && h1.length >= 21 && h2 && h2.length >= 21) {
            const palm1 = { x: (h1[0].x + h1[9].x) * 0.5, y: (h1[0].y + h1[9].y) * 0.5 };
            const palm2 = { x: (h2[0].x + h2[9].x) * 0.5, y: (h2[0].y + h2[9].y) * 0.5 };

            const handsDist = Math.hypot(palm2.x - palm1.x, palm2.y - palm1.y);
            const handsAngle = Math.atan2(palm2.y - palm1.y, palm2.x - palm1.x);

            const p1DistWristIndex = getDist3D(h1[8], h1[0]);
            const p2DistWristIndex = getDist3D(h2[8], h2[0]);
            const p1DistWristMiddle = getDist3D(h1[12], h1[0]);
            const p2DistWristMiddle = getDist3D(h2[12], h2[0]);

            const isH1Repulsor = p1DistWristIndex > 0.16 && p1DistWristMiddle > 0.16;
            const isH2Repulsor = p2DistWristIndex > 0.16 && p2DistWristMiddle > 0.16;

            const wristDist = getDist3D(h1[0], h2[0]);

            // =========================================================
            // DUAL HAND KINEMATICS & GESTURES
            // =========================================================

            // 1. DUAL REPULSOR CANNON (Both Wide Open Spread Palms Facing Forward deliberately)
            const isH1WideOpen = p1DistWristIndex > 0.22 && p1DistWristMiddle > 0.22;
            const isH2WideOpen = p2DistWristIndex > 0.22 && p2DistWristMiddle > 0.22;

            if (isH1WideOpen && isH2WideOpen && gestureCooldown <= 0 && handsDist > 0.25) {
              triggerNextColor(0x00f0ff);
              gestureCooldown = 1.0;
              handTrackingService.setGesture('⚡ Dual Repulsor Overdrive', 0.99);
              if (onGestureDetected) {
                onGestureDetected(
                  '⚡ Dual Repulsor Overdrive',
                  0.99,
                  'REPULSOR_CHARGE'
                );
              }
            }
            // 2. DUAL HANDS DYNAMIC PROPORTIONAL STRETCH & COMPRESS (Zoom In / Out)
            else if (prevHandsDistance !== null) {
              const distDelta = handsDist - prevHandsDistance;
              if (Math.abs(distDelta) > 0.010) {
                // Smooth proportional zoom with zero lag
                targetZoom = THREE.MathUtils.clamp(
                  targetZoom - distDelta * 24.0,
                  controls.minDistance,
                  controls.maxDistance
                );

                if (distDelta > 0.025 && now - lastGestureTriggerTime > 300) {
                  handTrackingService.setGesture('Dual Hand Stretch (Zoom In)', 0.98);
                  if (onGestureDetected) {
                    onGestureDetected('Dual Hand - Holographic Stretch (Zoom In)', 0.98, 'TWO_HAND_EXPAND');
                  }
                  lastGestureTriggerTime = now;
                } else if (distDelta < -0.025 && now - lastGestureTriggerTime > 300) {
                  handTrackingService.setGesture('Dual Hand Compress (Zoom Out)', 0.98);
                  if (onGestureDetected) {
                    onGestureDetected('Dual Hand - Holographic Compress (Zoom Out)', 0.98, 'TWO_HAND_COMPRESS');
                  }
                  lastGestureTriggerTime = now;
                }
              }

              // 3. TWO-HAND 3D SPATIAL TWIST / STEERING WHEEL ROTATION
              if (prevHandsAngle !== null) {
                let angleDelta = handsAngle - prevHandsAngle;
                if (angleDelta > Math.PI) angleDelta -= Math.PI * 2;
                if (angleDelta < -Math.PI) angleDelta += Math.PI * 2;

                if (Math.abs(angleDelta) > 0.04) {
                  targetRotY += angleDelta * 4.0;
                  if (now - lastGestureTriggerTime > 300) {
                    handTrackingService.setGesture('3D Spatial Roll Matrix', 0.96);
                    if (onGestureDetected) {
                      onGestureDetected('Dual Hand - 3D Holographic Roll Matrix', 0.96, 'TWO_HAND_TWIST');
                    }
                    lastGestureTriggerTime = now;
                  }
                }
              }
            }

            // 4. TWO-HAND NANOTECH SHIELD (Crossed / Touching Palms)
            if (handsDist < 0.12 && gestureCooldown <= 0) {
              triggerNextColor(0xaa33ff);
              gestureCooldown = 1.2;
              handTrackingService.setGesture('Nanotech Defense Shield', 0.99);
              if (onGestureDetected) {
                onGestureDetected('Dual Hand - Nanotech Defense Shield Engaged', 0.99, 'SHIELD_MATRIX');
              }
            }

            prevHandsDistance = handsDist;
            prevHandsAngle = handsAngle;
            return;
          }
        }

        // =============================================================
        // SCENARIO B: SINGLE HAND KINEMATICS ENGINE
        // =============================================================
        prevHandsDistance = null;
        prevHandsAngle = null;

        // If gesture recognition is currently LOCKED, freeze single hand gestures completely
        if (lockedRef.current) {
          return;
        }

        const landmarks = handsList[0];
        if (!landmarks || landmarks.length < 21) {
          return;
        }

        const wrist = landmarks[0];
        const thumbTip = landmarks[4];
        const indexMCP = landmarks[5];
        const indexTip = landmarks[8];
        const middleMCP = landmarks[9];
        const middleTip = landmarks[12];
        const ringTip = landmarks[16];
        const pinkyTip = landmarks[20];

        // Strict Structural Hand Integrity Check to reject non-hand noise
        const palmDist = getDist3D(wrist, middleMCP);
        if (palmDist < 0.05 || palmDist > 0.45) {
          return;
        }

        const rawPalmSize = Math.max(palmDist, 0.08);
        prevPalmSize = smoothPalmSize;
        smoothPalmSize =
          smoothPalmSize === null
            ? rawPalmSize
            : smoothPalmSize * 0.70 + rawPalmSize * 0.30;

        // Palm centroid for smooth, instantaneous spatial tracking
        const rawHandX = (wrist.x + middleMCP.x) * 0.5;
        const rawHandY = (wrist.y + middleMCP.y) * 0.5;

        smoothHandX =
          smoothHandX === null
            ? rawHandX
            : smoothHandX * 0.45 + rawHandX * 0.55;
        smoothHandY =
          smoothHandY === null
            ? rawHandY
            : smoothHandY * 0.45 + rawHandY * 0.55;

        // Normalized 3D distances relative to palm size
        const distIndexThumb = getDist3D(indexTip, thumbTip) / smoothPalmSize;
        const distMiddleThumb = getDist3D(middleTip, thumbTip) / smoothPalmSize;
        const distIndexWrist = getDist3D(indexTip, wrist) / smoothPalmSize;
        const distMiddleWrist = getDist3D(middleTip, wrist) / smoothPalmSize;
        const distRingWrist = getDist3D(ringTip, wrist) / smoothPalmSize;
        const distPinkyWrist = getDist3D(pinkyTip, wrist) / smoothPalmSize;

        const isIndexExt = distIndexWrist > 1.18;
        const isMiddleExt = distMiddleWrist > 1.18;
        const isRingExt = distRingWrist > 1.05;
        const isPinkyExt = distPinkyWrist > 1.05;

        const isFist =
          distIndexWrist < 0.95 &&
          distMiddleWrist < 0.95 &&
          distRingWrist < 0.95 &&
          distPinkyWrist < 0.95;

        const isPeaceSign =
          isIndexExt &&
          isMiddleExt &&
          !isRingExt &&
          !isPinkyExt &&
          getDist3D(indexTip, middleTip) / smoothPalmSize > 0.28;

        const isThumbsUp =
          thumbTip.y < indexMCP.y - 0.04 &&
          distIndexWrist < 1.0 &&
          distMiddleWrist < 1.0 &&
          distRingWrist < 1.0 &&
          distPinkyWrist < 1.0;

        const isGunGesture = isIndexExt && !isMiddleExt && !isRingExt && !isPinkyExt;

        // Calculate continuous velocity
        let dx = 0;
        let dy = 0;
        let vx = 0;
        if (prevHandX !== null && prevHandY !== null) {
          dx = smoothHandX - prevHandX;
          dy = smoothHandY - prevHandY;
          vx = dx / dt;
        }

        // Dynamic sensitivity and motion thresholds configured via Gesture Guide HUD
        const motionThreshold = handTrackingService.getMotionThreshold();
        const sensitivityFactor = handTrackingService.getSensitivityFactor();
        const swipeThreshold = handTrackingService.getSwipeThreshold();
        const cooldownFactor = handTrackingService.getCooldownFactor();

        // Additional Hand Pose Detections for Extended Protocol Matrix
        const isOkSign = distIndexThumb < 0.25 && isMiddleExt && isRingExt && isPinkyExt;
        const isRockSign = isIndexExt && isPinkyExt && !isMiddleExt && !isRingExt;
        const isSpiderSign = isIndexExt && isPinkyExt && !isMiddleExt && !isRingExt && distIndexThumb > 0.4;
        const isPointUp = isIndexExt && !isMiddleExt && !isRingExt && !isPinkyExt && indexTip.y < indexMCP.y - 0.08;
        const isPointDown = isIndexExt && !isMiddleExt && !isRingExt && !isPinkyExt && indexTip.y > indexMCP.y + 0.08;
        const isRepulsorPalm = isIndexExt && isMiddleExt && isRingExt && isPinkyExt && smoothPalmSize > 0.16 && wrist.y > indexTip.y;
        const isThumbsDown = thumbTip.y > wrist.y + 0.02 && isFist;

        // Anti-Accidental Trigger Zones:
        // 1. Hand resting against head/ear/chin (upper zone: smoothHandY < 0.28)
        // 2. Hand dropping down to rest on desk/lap (dy > 0.04 downward velocity)
        // 3. Relaxed/ambiguous unengaged hand shape
        const isHandInHeadRestZone = smoothHandY < 0.28;
        const isHandDropping = dy > 0.04 && Math.abs(dy) > Math.abs(dx) * 1.3;
        const isActivelyEngagedHand = !isHandInHeadRestZone && !isHandDropping && (
          isRepulsorPalm || isPeaceSign || isThumbsUp || isThumbsDown || isOkSign ||
          isSpiderSign || isRockSign || isPointUp || isPointDown || isGunGesture ||
          (distIndexThumb < 0.24) || (distMiddleThumb < 0.24) || (Math.abs(vx) > swipeThreshold)
        );

        if (!isActivelyEngagedHand) {
          prevHandX = smoothHandX;
          prevHandY = smoothHandY;
          return;
        }

        // =============================================================
        // GESTURE 1: 3D HOLOGRAPHIC ROTATION / ORBIT (Requires Explicit Repulsor Palm)
        // Only active when upright open palm is intentionally held to avoid random motion
        // =============================================================
        const hasMotion = Math.abs(dx) > motionThreshold || Math.abs(dy) > motionThreshold;

        if (hasMotion && isRepulsorPalm && Math.abs(vx) <= (swipeThreshold * 1.3)) {
          targetRotY += dx * (-9.0 * sensitivityFactor);
          targetRotX = THREE.MathUtils.clamp(
            targetRotX + dy * (7.5 * sensitivityFactor),
            -Math.PI * 0.44,
            Math.PI * 0.44
          );

          if (now - lastGestureTriggerTime > (500 * cooldownFactor)) {
            handTrackingService.setGesture('Hand Orbit (3D Core)', 0.95);
            if (onGestureDetected) {
              onGestureDetected('Hand Orbit - 3D Core Rotation', 0.95, 'ORBIT_3D');
            }
            lastGestureTriggerTime = now;
          }
        }

        // =============================================================
        // GESTURE 2: INTENTIONAL PINCH ZOOM (Index/Middle + Thumb Pinch)
        // Single-hand palm delta auto-zoom is removed to prevent accidental jitter
        // =============================================================
        if (distIndexThumb < 0.24 && !isRingExt && !isPinkyExt && !isFist) {
          if (!isIndexPinching) {
            isIndexPinching = true;
            targetZoom = THREE.MathUtils.clamp(
              targetZoom - 2.8,
              controls.minDistance,
              controls.maxDistance
            );
            handTrackingService.setGesture('Pinch Zoom In', 0.98);
            if (onGestureDetected && now - lastGestureTriggerTime > (350 * cooldownFactor)) {
              onGestureDetected('Pinch (Index) - Zoom In', 0.98, 'ZOOM_IN_4');
              lastGestureTriggerTime = now;
            }
          }
        } else if (distIndexThumb > 0.38) {
          isIndexPinching = false;
        }

        // Intentional Pinch Zoom Out (Middle + Thumb pinched with ring/pinky down)
        if (distMiddleThumb < 0.24 && !isRingExt && !isPinkyExt && !isIndexPinching && !isFist) {
          if (!isMiddlePinching) {
            isMiddlePinching = true;
            targetZoom = THREE.MathUtils.clamp(
              targetZoom + 2.8,
              controls.minDistance,
              controls.maxDistance
            );
            handTrackingService.setGesture('Pinch Zoom Out', 0.98);
            if (onGestureDetected && now - lastGestureTriggerTime > (350 * cooldownFactor)) {
              onGestureDetected('Pinch (Middle) - Zoom Out', 0.98, 'ZOOM_OUT_3_9');
              lastGestureTriggerTime = now;
            }
          }
        } else if (distMiddleThumb > 0.38) {
          isMiddlePinching = false;
        }

        // =============================================================
        // GESTURE 3: FAST SWIPE (Recenter Core to Origin)
        // =============================================================
        if (gestureCooldown <= 0 && Math.abs(vx) > swipeThreshold && !isFist) {
          recenterGlobe();
          triggerNextColor();
          gestureCooldown = 0.5 * cooldownFactor;
          handTrackingService.setGesture('Swipe Recenter Origin', 0.96);
          if (onGestureDetected) {
            onGestureDetected('Swipe - Recenter Core Origin', 0.96, 'RECENTER_CORE');
          }
        }

        // =============================================================
        // GESTURE 4: POINTER / GUN (Spatial Coordinate Pan)
        // =============================================================
        if (isGunGesture && hasMotion) {
          targetPosX = THREE.MathUtils.clamp(targetPosX + dx * -16.0, -8.0, 8.0);
          targetPosY = THREE.MathUtils.clamp(targetPosY - dy * 16.0, -6.0, 6.0);
          if (now - lastGestureTriggerTime > 350) {
            handTrackingService.setGesture('Pointer Pan Coordinate', 0.94);
            if (onGestureDetected) {
              onGestureDetected('Pointer - Pan Coordinate', 0.94, 'PAN_COORDINATE');
            }
            lastGestureTriggerTime = now;
          }
        }

        // =============================================================
        // GESTURE 5: PEACE SIGN (Cycle Lighting Scenes / Hologram)
        // =============================================================
        if (isPeaceSign && gestureCooldown <= 0) {
          triggerNextColor();
          gestureCooldown = 0.8;
          handTrackingService.setGesture('Peace Sign (Theme Cycle)', 0.99);
          if (onGestureDetected) {
            onGestureDetected('Peace Sign - Cycle Hologram Theme', 0.99, 'CYCLE_LIGHTING_SCENE');
          }
        }

        // =============================================================
        // GESTURE 6: THUMBS UP (Morning Scene / Nominal Grid)
        // =============================================================
        if (isThumbsUp && gestureCooldown <= 0) {
          triggerNextColor(0x00ff88);
          gestureCooldown = 0.9;
          handTrackingService.setGesture('Thumbs Up (Morning Scene)', 0.99);
          if (onGestureDetected) {
            onGestureDetected('Thumbs Up - Morning Routine Active', 0.99, 'SCENE_MORNING');
          }
        }

        // =============================================================
        // GESTURE 7: THUMBS DOWN (Good Night Sleep Protocol)
        // =============================================================
        if (isThumbsDown && gestureCooldown <= 0) {
          triggerNextColor(0x0077ff);
          gestureCooldown = 0.9;
          handTrackingService.setGesture('Thumbs Down (Good Night)', 0.99);
          if (onGestureDetected) {
            onGestureDetected('Thumbs Down - Good Night All Off', 0.99, 'SCENE_GOODNIGHT');
          }
        }

        // =============================================================
        // GESTURE 8: OK SIGN (Toggle Living Room Chandelier)
        // =============================================================
        if (isOkSign && gestureCooldown <= 0) {
          gestureCooldown = 0.8;
          handTrackingService.setGesture('OK Sign (Light Toggle)', 0.98);
          if (onGestureDetected) {
            onGestureDetected('OK Sign - Living Room Light Toggle', 0.98, 'TOGGLE_CHANDELIER');
          }
        }

        // =============================================================
        // GESTURE 9: SPIDER-MAN / THEATER SCENE
        // =============================================================
        if (isSpiderSign && gestureCooldown <= 0) {
          triggerNextColor(0xaa33ff);
          gestureCooldown = 0.9;
          handTrackingService.setGesture('Spider Pose (Cinema Mode)', 0.97);
          if (onGestureDetected) {
            onGestureDetected('Spider Pose - Cyberpunk Cinema Mode', 0.97, 'SCENE_THEATER');
          }
        }

        // =============================================================
        // GESTURE 10: ROCK ON / PARTY RGB MODE
        // =============================================================
        if (isRockSign && gestureCooldown <= 0) {
          triggerNextColor(0xff3366);
          gestureCooldown = 0.9;
          handTrackingService.setGesture('Rock Horns (Party Mode)', 0.97);
          if (onGestureDetected) {
            onGestureDetected('Rock Horns - Party RGB Strobe', 0.97, 'SCENE_PARTY');
          }
        }

        // =============================================================
        // GESTURE 11: POINT UP (Brightness +20%)
        // =============================================================
        if (isPointUp && gestureCooldown <= 0) {
          gestureCooldown = 0.6;
          handTrackingService.setGesture('Point Up (Brightness +)', 0.95);
          if (onGestureDetected) {
            onGestureDetected('Point Up - Chandelier Brightness Up', 0.95, 'BRIGHTNESS_UP');
          }
        }

        // =============================================================
        // GESTURE 12: POINT DOWN (Brightness -20%)
        // =============================================================
        if (isPointDown && gestureCooldown <= 0) {
          gestureCooldown = 0.6;
          handTrackingService.setGesture('Point Down (Brightness -)', 0.95);
          if (onGestureDetected) {
            onGestureDetected('Point Down - Chandelier Dimmer Down', 0.95, 'BRIGHTNESS_DOWN');
          }
        }

        // =============================================================
        // GESTURE 13: REPULSOR PALM THRUST (Arc Reactor Charge)
        // =============================================================
        if (isRepulsorPalm && gestureCooldown <= 0) {
          triggerNextColor(0x00f0ff);
          gestureCooldown = 1.0;
          handTrackingService.setGesture('Repulsor Thrust (Core Charge)', 0.99);
          if (onGestureDetected) {
            onGestureDetected('Core Charge', 0.99, 'CORE_CHARGE');
          }
        }

        prevHandX = smoothHandX;
        prevHandY = smoothHandY;
      } else {
        lostTrackCounter++;
        if (lostTrackCounter > MAX_GRACE_FRAMES) {
          resetHandTracking();
          handTrackingService.updateLandmarks(null);
          if (onLandmarksUpdate) onLandmarksUpdate(null);
        }
      }
    }

    // MediaPipe Hands + Direct MediaStream Initialization
    let localStream: MediaStream | null = null;
    let isProcessingFrame = false;
    let handsInstance: any = null;
    let frameLoopId: number;
    // Lifted to effect scope (was previously local to the async initializer, so the
    // cleanup function below could never actually see or flip it — the camera-frame
    // callback kept running after unmount). Also tracks the requestVideoFrameCallback
    // handle and listener references so every one of them can be torn down.
    let isDestroyed = false;
    let videoFrameCallbackId: number | null = null;
    let handleVisibilityRef: (() => void) | null = null;
    let controlsStartHandler: (() => void) | null = null;
    let controlsChangeHandler: (() => void) | null = null;

    const initMediaPipePipeline = async () => {
      let attempts = 0;
      while (!(window as any).Hands && attempts < 15) {
        await new Promise((r) => setTimeout(r, 200));
        attempts++;
      }

      const HandsConstructor = (window as any).Hands;
      if (!HandsConstructor || !videoRef.current) {
        console.warn('HandsConstructor not ready or video element missing.');
        return;
      }

      try {
        handsInstance = new HandsConstructor({
          locateFile: (file: string) =>
            `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
        });

        // Dual Hands Optical Kinematics Tracking (maxNumHands: 2, modelComplexity: 0 for 60fps+ edge speed)
        handsInstance.setOptions({
          maxNumHands: 2,
          modelComplexity: 0,
          minDetectionConfidence: 0.35,
          minTrackingConfidence: 0.35,
        });

        handsInstance.onResults(onResults);

        // Request camera with user facing mode & 60fps ideal rate
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          try {
            localStream = await navigator.mediaDevices.getUserMedia({
              video: {
                width: { ideal: 640 },
                height: { ideal: 480 },
                frameRate: { ideal: 60, min: 30 },
                facingMode: 'user',
              },
              audio: false,
            });

            if (videoRef.current) {
              videoRef.current.srcObject = localStream;
              await videoRef.current.play();
              if (onCameraStatusChange) onCameraStatusChange(true);
              if (onVideoReady) onVideoReady(videoRef.current);

              const video = videoRef.current;
              let lastMediaPipeFrameTime = 0;
              let pageVisible = document.visibilityState === 'visible';

              const handleVisibility = () => {
                pageVisible = document.visibilityState === 'visible';
                if (pageVisible) {
                  void video.play().catch(() => undefined);
                  try { localStream?.getVideoTracks().forEach((track) => { track.enabled = true; }); } catch {}
                } else {
                  try { localStream?.getVideoTracks().forEach((track) => { track.enabled = false; }); } catch {}
                }
              };
              handleVisibilityRef = handleVisibility;
              document.addEventListener('visibilitychange', handleVisibility, { passive: true });

              controlsStartHandler = () => { manualControlUntil = performance.now() + 900; };
              controlsChangeHandler = () => {
                if (performance.now() < manualControlUntil) {
                  targetZoom = THREE.MathUtils.clamp(camera.position.distanceTo(jarvisGroup.position), controls.minDistance, controls.maxDistance);
                }
              };
              controls.addEventListener('start', controlsStartHandler);
              controls.addEventListener('change', controlsChangeHandler);

              const onFrame = async () => {
                if (isDestroyed) return;
                const now = performance.now();

                // Adaptive foreground cadence: run as fast as the pipeline can safely sustain;
                // background tabs stop inference and only resume when visible again.
                const targetInterval = document.visibilityState === 'visible' ? 16 : 1000;
                if (
                  pageVisible &&
                  video &&
                  video.readyState >= 2 &&
                  !video.paused &&
                  handsInstance &&
                  !isProcessingFrame &&
                  now - lastMediaPipeFrameTime >= targetInterval
                ) {
                  lastMediaPipeFrameTime = now;
                  isProcessingFrame = true;
                  try {
                    await handsInstance.send({ image: video });
                  } catch (err) {
                    // graceful recovery
                  }
                  isProcessingFrame = false;
                }

                if (isDestroyed) return;
                if ('requestVideoFrameCallback' in video) {
                  videoFrameCallbackId = (video as any).requestVideoFrameCallback(onFrame);
                } else {
                  frameLoopId = requestAnimationFrame(onFrame);
                }
              };

              if ('requestVideoFrameCallback' in video) {
                videoFrameCallbackId = (video as any).requestVideoFrameCallback(onFrame);
              } else {
                frameLoopId = requestAnimationFrame(onFrame);
              }
            }
          } catch (streamErr: any) {
            console.warn('Webcam stream permission pending:', streamErr);
            if (onCameraStatusChange)
              onCameraStatusChange(false, streamErr.message || 'Permission pending');
          }
        }
      } catch (err: any) {
        console.warn('MediaPipe initialization notice:', err);
      }
    };

    const mediaPipeTimer = setTimeout(initMediaPipePipeline, 300);

    // =================================================================
    // 5. RESIZE HANDLER
    // =================================================================
    const handleResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      composer.setSize(w, h);
      bloomPass.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // =================================================================
    // 6. MAIN 240Hz ANIMATION LOOP
    // =================================================================
    const clock = new THREE.Clock();
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const rawDelta = clock.getDelta();
      // True high-precision delta time without artificial clamping (smooth 60/120/144/240Hz)
      const delta = Math.min(rawDelta, 0.05);
      const time = clock.getElapsedTime();
      const now = performance.now();

      // Dynamic State response
      const curState = stateRef.current;
      if (curState === 'LISTENING' || curState === 'WAKE_DETECTED') {
        speedMultiplier = 1.8;
      } else if (curState === 'THINKING' || curState === 'SEARCHING') {
        speedMultiplier = 2.4;
      } else if (curState === 'EXECUTING') {
        speedMultiplier = 2.0;
      } else if (curState === 'SPEAKING') {
        speedMultiplier = 1.3;
      } else if (curState === 'WARNING' || curState === 'ERROR') {
        speedMultiplier = 0.8;
      } else {
        speedMultiplier = 1.0;
      }

      if (now - lastAutoColorTime > AUTO_COLOR_INTERVAL_MS) {
        triggerNextColor();
        lastAutoColorTime = now;
      }

      updateUnifiedCascadeWave(now);

      // Particles Orbit Animation (High precision time math)
      const positions = particleGeo.attributes.position.array as Float32Array;
      const frameSpeed = delta * 60.0;
      for (let i = 0; i < particleCount; i++) {
        particleAngles[i] += particleSpeeds[i] * speedMultiplier * frameSpeed;
        positions[i * 3] += Math.cos(particleAngles[i] + time) * 0.003;
        positions[i * 3 + 1] += Math.sin(particleAngles[i] + time) * 0.003;
      }
      particleGeo.attributes.position.needsUpdate = true;

      // Mathematically Scale-Invariant Exponential Dampening for 240Hz Smoothness
      const smoothFactor = 1.0 - Math.exp(-24.0 * delta);

      // Subtle ambient idle drift only when hands are not actively piloting the core
      if (!isHandTracking) {
        targetRotY += 0.12 * delta * speedMultiplier;
      }

      jarvisGroup.rotation.y +=
        (targetRotY - jarvisGroup.rotation.y) * smoothFactor;
      jarvisGroup.rotation.x +=
        (targetRotX - jarvisGroup.rotation.x) * smoothFactor;
      jarvisGroup.position.x +=
        (targetPosX - jarvisGroup.position.x) * smoothFactor;
      jarvisGroup.position.y +=
        (targetPosY - jarvisGroup.position.y) * smoothFactor;

      // Smooth spherical camera zoom along optical vector
      const currentCamDist = camera.position.distanceTo(jarvisGroup.position);
      const targetCamDist = targetZoom;
      if (Math.abs(currentCamDist - targetCamDist) > 0.005) {
        const camDir = camera.position.clone().sub(jarvisGroup.position).normalize();
        if (camDir.lengthSq() < 0.001) camDir.set(0, 0, 1);
        const nextDist = THREE.MathUtils.lerp(currentCamDist, targetCamDist, smoothFactor);
        camera.position.copy(jarvisGroup.position).add(camDir.multiplyScalar(nextDist));
      }

      if (performance.now() >= manualControlUntil && !isHandTracking) {
        const observedDistance = camera.position.distanceTo(jarvisGroup.position);
        if (Math.abs(observedDistance - targetZoom) > 0.08) targetZoom = THREE.MathUtils.clamp(observedDistance, controls.minDistance, controls.maxDistance);
      }
      controls.target.copy(jarvisGroup.position);

      // Dynamic Active Hologram Model Visibility & Morphing
      const activeModel = modelRef.current || 'ARC_REACTOR';
      arcReactorGroup.visible = activeModel === 'ARC_REACTOR';

      // Dynamic breathing luminescence
      const breath = 0.96 + 0.04 * Math.sin(time * 2.0);
      coreMat.opacity = 0.80 * breath;
      haloMat.opacity = 0.50 * breath;

      // Model 1: Arc Reactor animations
      if (arcReactorGroup.visible) {
        wireSphere.rotation.y = time * 0.21 * speedMultiplier;
        wireSphere.rotation.x = time * 0.105 * speedMultiplier;
        arc1.rotation.z = time * 0.924 * speedMultiplier;
        arc2.rotation.z = -time * 0.75 * speedMultiplier;
        arc3.rotation.z = time * 0.62 * speedMultiplier;
        arc3.rotation.x = Math.sin(time * 0.45) * 0.35;
        arc4.rotation.z = -time * 0.48 * speedMultiplier;
        arc4.rotation.y = Math.cos(time * 0.38) * 0.45;
        raysGroup.rotation.y = time * 0.21 * speedMultiplier;
      }

      // State-specific pulse dynamics
      const pulseFreq =
        curState === 'SPEAKING' ? 8 : curState === 'LISTENING' ? 6 : 4;
      const pulseAmp = curState === 'SPEAKING' ? 0.09 : 0.05;
      const pulse = 1 + Math.sin(time * pulseFreq) * pulseAmp;

      coreMesh.scale.set(pulse, pulse, pulse);
      haloMesh.scale.set(pulse * 1.05, pulse * 1.05, pulse * 1.05);

      controls.update();
      composer.render();
    };

    animate();

    return () => {
      isDestroyed = true;
      clearTimeout(mediaPipeTimer);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (frameLoopId) {
        cancelAnimationFrame(frameLoopId);
      }
      if (videoFrameCallbackId !== null && videoRef.current && 'cancelVideoFrameCallback' in videoRef.current) {
        try { (videoRef.current as any).cancelVideoFrameCallback(videoFrameCallbackId); } catch {}
      }
      if (handleVisibilityRef) {
        document.removeEventListener('visibilitychange', handleVisibilityRef);
      }
      if (controlsStartHandler) controls.removeEventListener('start', controlsStartHandler);
      if (controlsChangeHandler) controls.removeEventListener('change', controlsChangeHandler);
      if (handsInstance && typeof handsInstance.close === 'function') {
        try { handsInstance.close(); } catch {}
      }
      if (localStream) {
        try {
          localStream.getTracks().forEach((track) => track.stop());
        } catch (e) {
          // ignore
        }
      }
      renderer.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      coreGeo.dispose();
      coreMat.dispose();
      haloGeo.dispose();
      haloMat.dispose();
      sphereGeo.dispose();
      wireMat.dispose();
    };
  }, []);

  return (
    <>
      {/* Hidden Webcam Tracker */}
      <video
        ref={videoRef}
        id="webcam"
        autoPlay
        playsInline
        muted
        className="fixed top-0 left-0 w-screen h-screen object-cover opacity-0 pointer-events-none -z-10"
      />
      {/* Three.js Holographic Canvas Container */}
      <div
        ref={containerRef}
        className="absolute inset-0 w-full h-full pointer-events-auto cursor-grab active:cursor-grabbing"
      />
    </>
  );
};
