import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { X, Sparkles, Mic, Send, Loader2 } from 'lucide-react';
import { jarvisVoice } from '../services/voiceService';

interface GalaxyNode {
  id: number;
  label: string;
  group: string;
  excerpt: string;
}
interface GalaxyLink {
  source: number;
  target: number;
}

interface KnowledgeGalaxyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const GROUP_COLORS = [0x00f0ff, 0xff3366, 0xffd23f, 0x8a5cff, 0x2ee6a6, 0xff8c42];
const colorForGroup = (group: string) => {
  let hash = 0;
  for (let i = 0; i < group.length; i++) hash = (hash * 31 + group.charCodeAt(i)) >>> 0;
  return GROUP_COLORS[hash % GROUP_COLORS.length];
};

export const KnowledgeGalaxyModal: React.FC<KnowledgeGalaxyModalProps> = ({ isOpen, onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    controls: OrbitControls;
    nodeMeshes: Map<number, THREE.Mesh>;
    linkLines: THREE.LineSegments | null;
    positions: Map<number, THREE.Vector3>;
    velocities: Map<number, THREE.Vector3>;
    nodesData: GalaxyNode[];
    linksData: GalaxyLink[];
    animationId: number;
    flyTarget: THREE.Vector3 | null;
    highlighted: Set<number>;
  } | null>(null);

  const [status, setStatus] = useState<'idle' | 'listening' | 'thinking'>('idle');
  const [noteCount, setNoteCount] = useState<number | null>(null);
  const [inputText, setInputText] = useState('');
  const [selectedNote, setSelectedNote] = useState<GalaxyNode | null>(null);
  const [lastAnswer, setLastAnswer] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const sessionIdRef = useRef<string>(`galaxy-${Date.now()}`);

  const flyToNode = useCallback((nodeId: number, neighborsAlso: boolean) => {
    const s = sceneRef.current;
    if (!s) return;
    const pos = s.positions.get(nodeId);
    if (!pos) return;
    s.flyTarget = pos.clone();
    s.highlighted = new Set([nodeId]);
    if (neighborsAlso) {
      for (const link of s.linksData) {
        if (link.source === nodeId) s.highlighted.add(link.target);
        if (link.target === nodeId) s.highlighted.add(link.source);
      }
    }
    const node = s.nodesData.find((n) => n.id === nodeId);
    if (node) setSelectedNote(node);
  }, []);

  const highlightCluster = useCallback((nodeIds: number[]) => {
    const s = sceneRef.current;
    if (!s) return;
    s.highlighted = new Set(nodeIds);
    // Center camera on the cluster's centroid rather than one node.
    const pts = nodeIds.map((id) => s.positions.get(id)).filter(Boolean) as THREE.Vector3[];
    if (pts.length) {
      const centroid = pts.reduce((acc, p) => acc.add(p), new THREE.Vector3()).multiplyScalar(1 / pts.length);
      s.flyTarget = centroid;
    }
  }, []);

  // ---- Three.js scene setup ----
  useEffect(() => {
    if (!isOpen || !containerRef.current) return;
    const container = containerRef.current;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x02040a);

    // Starfield
    const starGeo = new THREE.BufferGeometry();
    const starCount = 1200;
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      starPos[i * 3] = (Math.random() - 0.5) * 400;
      starPos[i * 3 + 1] = (Math.random() - 0.5) * 400;
      starPos[i * 3 + 2] = (Math.random() - 0.5) * 400;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({ color: 0x4488aa, size: 0.6, sizeAttenuation: true });
    scene.add(new THREE.Points(starGeo, starMat));

    const camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 60);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 8;
    controls.maxDistance = 220;

    const ambient = new THREE.AmbientLight(0x8899ff, 1.2);
    scene.add(ambient);

    sceneRef.current = {
      scene,
      camera,
      renderer,
      controls,
      nodeMeshes: new Map(),
      linkLines: null,
      positions: new Map(),
      velocities: new Map(),
      nodesData: [],
      linksData: [],
      animationId: 0,
      flyTarget: null,
      highlighted: new Set(),
    };

    let raf = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      raf = requestAnimationFrame(animate);
      const s = sceneRef.current;
      if (!s) return;
      const dt = Math.min(clock.getDelta(), 0.05);

      // Lightweight force simulation: repulsion between all nodes + spring along links + drift toward center.
      const ids = s.nodesData.map((n) => n.id);
      const forces = new Map<number, THREE.Vector3>();
      for (const id of ids) forces.set(id, new THREE.Vector3());

      for (let i = 0; i < ids.length; i++) {
        for (let j = i + 1; j < ids.length; j++) {
          const a = s.positions.get(ids[i])!;
          const b = s.positions.get(ids[j])!;
          const diff = new THREE.Vector3().subVectors(a, b);
          const distSq = Math.max(diff.lengthSq(), 0.5);
          const repulse = diff.normalize().multiplyScalar(24 / distSq);
          forces.get(ids[i])!.add(repulse);
          forces.get(ids[j])!.add(repulse.clone().negate());
        }
      }
      for (const link of s.linksData) {
        const a = s.positions.get(link.source);
        const b = s.positions.get(link.target);
        if (!a || !b) continue;
        const diff = new THREE.Vector3().subVectors(b, a);
        const dist = diff.length();
        const spring = diff.normalize().multiplyScalar((dist - 14) * 0.02);
        forces.get(link.source)!.add(spring);
        forces.get(link.target)!.add(spring.clone().negate());
      }
      for (const id of ids) {
        const pos = s.positions.get(id)!;
        forces.get(id)!.add(pos.clone().multiplyScalar(-0.006)); // gentle pull to center
      }

      for (const id of ids) {
        const vel = s.velocities.get(id)!;
        vel.add(forces.get(id)!.multiplyScalar(dt));
        vel.multiplyScalar(0.85); // damping
        const pos = s.positions.get(id)!;
        pos.add(vel.clone().multiplyScalar(dt * 6));
        const mesh = s.nodeMeshes.get(id);
        if (mesh) {
          mesh.position.copy(pos);
          const isHighlighted = s.highlighted.has(id);
          const mat = mesh.material as THREE.MeshBasicMaterial;
          mat.opacity = s.highlighted.size === 0 ? 1 : isHighlighted ? 1 : 0.25;
          const targetScale = isHighlighted ? 1.6 : 1;
          mesh.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
        }
      }

      // Update link line positions
      if (s.linkLines) {
        const posAttr = s.linkLines.geometry.getAttribute('position') as THREE.BufferAttribute;
        let i = 0;
        for (const link of s.linksData) {
          const a = s.positions.get(link.source);
          const b = s.positions.get(link.target);
          if (a && b) {
            posAttr.setXYZ(i * 2, a.x, a.y, a.z);
            posAttr.setXYZ(i * 2 + 1, b.x, b.y, b.z);
          }
          i++;
        }
        posAttr.needsUpdate = true;
      }

      // Camera fly-to-target
      if (s.flyTarget) {
        const desired = s.flyTarget.clone().add(new THREE.Vector3(6, 4, 14));
        s.camera.position.lerp(desired, 0.06);
        s.controls.target.lerp(s.flyTarget, 0.08);
        if (s.camera.position.distanceTo(desired) < 0.5) s.flyTarget = null;
      }

      s.controls.update();
      s.renderer.render(s.scene, s.camera);
    };
    animate();
    sceneRef.current.animationId = raf;

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(raf);
      renderer.dispose();
      starGeo.dispose();
      starMat.dispose();
      if (container.contains(renderer.domElement)) container.removeChild(renderer.domElement);
      sceneRef.current = null;
    };
  }, [isOpen]);

  // ---- Load the notes graph once the scene exists ----
  useEffect(() => {
    if (!isOpen) return;
    (async () => {
      try {
        const res = await fetch('/api/notes/graph');
        if (!res.ok) throw new Error(`Graph fetch failed: ${res.status}`);
        const data = await res.json();
        const s = sceneRef.current;
        if (!s) return;

        s.nodesData = data.nodes;
        s.linksData = data.links;
        setNoteCount(data.count ?? data.nodes.length);

        // Seed random-sphere starting positions; the spring/repulsion sim settles them.
        for (const node of data.nodes as GalaxyNode[]) {
          const r = 20 + Math.random() * 10;
          const theta = Math.random() * Math.PI * 2;
          const phi = Math.acos(2 * Math.random() - 1);
          const pos = new THREE.Vector3(
            r * Math.sin(phi) * Math.cos(theta),
            r * Math.sin(phi) * Math.sin(theta),
            r * Math.cos(phi)
          );
          s.positions.set(node.id, pos);
          s.velocities.set(node.id, new THREE.Vector3());

          const color = colorForGroup(node.group);
          const geo = new THREE.SphereGeometry(0.9, 16, 16);
          const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1 });
          const mesh = new THREE.Mesh(geo, mat);
          mesh.position.copy(pos);
          mesh.userData.nodeId = node.id;
          s.scene.add(mesh);
          s.nodeMeshes.set(node.id, mesh);
        }

        const linkGeo = new THREE.BufferGeometry();
        const linkPositions = new Float32Array(data.links.length * 6);
        linkGeo.setAttribute('position', new THREE.BufferAttribute(linkPositions, 3));
        const linkMat = new THREE.LineBasicMaterial({ color: 0x2266aa, transparent: true, opacity: 0.35 });
        const lines = new THREE.LineSegments(linkGeo, linkMat);
        s.scene.add(lines);
        s.linkLines = lines;

        // Boot greeting, per spec — real note count, spoken once per open.
        const greeting = `Good evening, sir. ${data.count ?? data.nodes.length} notes indexed, all present and accounted for.`;
        setLastAnswer(greeting);
        jarvisVoice.speak(greeting);
      } catch (err: any) {
        setError(err?.message || 'Could not load the notes graph.');
      }
    })();
  }, [isOpen]);

  // ---- Click-to-fly on nodes ----
  useEffect(() => {
    if (!isOpen || !containerRef.current) return;
    const container = containerRef.current;
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handleClick = (e: MouseEvent) => {
      const s = sceneRef.current;
      if (!s) return;
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, s.camera);
      const meshes = Array.from(s.nodeMeshes.values());
      const hits = raycaster.intersectObjects(meshes);
      if (hits.length > 0) {
        const nodeId = hits[0].object.userData.nodeId;
        flyToNode(nodeId, true);
      }
    };
    container.addEventListener('click', handleClick);
    return () => container.removeEventListener('click', handleClick);
  }, [isOpen, flyToNode]);

  const askQuestion = useCallback(async (question: string) => {
    if (!question.trim()) return;
    setStatus('thinking');
    setError(null);
    try {
      // "remember that..." routes to the growth endpoint instead of the chat endpoint.
      if (/^remember that\b/i.test(question.trim())) {
        const captured = question.trim().replace(/^remember that\s*/i, '');
        const res = await fetch('/api/notes/remember', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: captured }),
        });
        if (!res.ok) throw new Error(`Remember failed: ${res.status}`);
        const data = await res.json();
        const s = sceneRef.current;
        if (s) {
          const spawnPos = data.nearestNodeId != null && s.positions.get(data.nearestNodeId)
            ? s.positions.get(data.nearestNodeId)!.clone().add(new THREE.Vector3(2, 2, 2))
            : new THREE.Vector3(0, 0, 0);
          s.nodesData.push(data.node);
          s.positions.set(data.node.id, spawnPos);
          s.velocities.set(data.node.id, new THREE.Vector3());
          const color = colorForGroup(data.node.group);
          const geo = new THREE.SphereGeometry(0.9, 16, 16);
          const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0 });
          const mesh = new THREE.Mesh(geo, mat);
          mesh.position.copy(spawnPos);
          mesh.userData.nodeId = data.node.id;
          s.scene.add(mesh);
          s.nodeMeshes.set(data.node.id, mesh);
          // Glow-pulse fade-in
          let t = 0;
          const pulse = () => {
            t += 0.05;
            mat.opacity = Math.min(1, t);
            if (t < 1) requestAnimationFrame(pulse);
          };
          pulse();
          flyToNode(data.node.id, false);
        }
        setNoteCount((c) => (c != null ? c + 1 : c));
        const reply = `Noted, sir — filed away as "${data.node.label}."`;
        setLastAnswer(reply);
        jarvisVoice.speak(reply);
        setStatus('idle');
        return;
      }

      const res = await fetch('/api/notes/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, sessionId: sessionIdRef.current }),
      });
      if (!res.ok) {
        const errBody = await res.json().catch(() => ({}));
        if (errBody.error === 'EXTERNAL_CREDENTIAL_REQUIRED') {
          throw new Error('No AI provider is configured on the server (need GEMINI_API_KEY or ANTHROPIC_API_KEY).');
        }
        throw new Error(errBody.detail || `Chat failed: ${res.status}`);
      }
      const data = await res.json();
      setLastAnswer(data.answer);
      jarvisVoice.speak(data.answer);

      if (data.nodes && data.nodes.length > 0) {
        if (data.nodes.length >= 4) highlightCluster(data.nodes);
        else flyToNode(data.nodes[0], true);
      }
    } catch (err: any) {
      setError(err?.message || 'Something went wrong.');
    } finally {
      setStatus('idle');
    }
  }, [flyToNode, highlightCluster]);

  const handleMicClick = () => {
    const SpeechRecognitionCtor = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognitionCtor) {
      setError('Speech recognition needs Chrome or Edge.');
      return;
    }
    if (status === 'listening') {
      recognitionRef.current?.stop();
      return;
    }
    const recognition = new SpeechRecognitionCtor();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onstart = () => setStatus('listening');
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputText(transcript);
      askQuestion(transcript);
    };
    recognition.onerror = () => setStatus('idle');
    recognition.onend = () => setStatus((s) => (s === 'listening' ? 'idle' : s));
    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    askQuestion(inputText);
    setInputText('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn font-rajdhani">
      <div className="relative w-full max-w-5xl h-[85vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-3 overflow-hidden">
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
                KNOWLEDGE GALAXY — SECOND BRAIN
              </h2>
              <p className="text-xs text-cyan-500/70">
                {noteCount != null ? `${noteCount} notes indexed` : 'Indexing notes…'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-cyan-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative flex-1 min-h-0 rounded-xl overflow-hidden border border-cyan-500/20">
          <div ref={containerRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />
          {selectedNote && (
            <div className="absolute top-3 right-3 max-w-xs bg-[#060d1d]/95 border border-cyan-500/40 rounded-lg p-3 text-xs text-cyan-100 shadow-lg">
              <div className="font-orbitron text-cyan-300 text-sm mb-1">{selectedNote.label}</div>
              <div className="text-cyan-500/70 mb-2 uppercase tracking-wide text-[10px]">{selectedNote.group}</div>
              <p className="text-cyan-100/90 leading-snug max-h-40 overflow-y-auto">{selectedNote.excerpt}</p>
            </div>
          )}
          {status !== 'idle' && (
            <div className="absolute bottom-3 left-3 flex items-center gap-2 text-xs text-cyan-300 bg-[#060d1d]/80 px-3 py-1.5 rounded-full border border-cyan-500/30">
              {status === 'thinking' ? <Loader2 className="w-3 h-3 animate-spin" /> : <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />}
              {status === 'listening' ? 'listening…' : 'thinking…'}
            </div>
          )}
        </div>

        {lastAnswer && (
          <div className="text-sm text-cyan-100/90 bg-cyan-500/5 border border-cyan-500/20 rounded-lg px-3 py-2 max-h-20 overflow-y-auto">
            {lastAnswer}
          </div>
        )}
        {error && (
          <div className="text-xs text-red-300 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleMicClick}
            className={`p-2.5 rounded-full border transition-colors ${
              status === 'listening'
                ? 'bg-red-500/20 border-red-400 text-red-300'
                : 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20'
            }`}
          >
            <Mic className="w-4 h-4" />
          </button>
          <input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder='Ask your notes, or say "remember that…"'
            className="flex-1 bg-black/40 border border-cyan-500/30 rounded-full px-4 py-2 text-sm text-cyan-100 placeholder-cyan-500/40 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            className="p-2.5 rounded-full bg-cyan-500/10 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
