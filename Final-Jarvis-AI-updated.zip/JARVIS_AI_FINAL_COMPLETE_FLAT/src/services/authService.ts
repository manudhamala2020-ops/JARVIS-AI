import { auth, googleProvider, db } from '../lib/firebase';
import {
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  addDoc,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { MemoryItem } from '../types';

export class AuthService {
  private static currentUser: User | null = null;

  public static async signInWithGoogle(): Promise<User> {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    this.currentUser = user;

    // Sync profile document to Firestore
    try {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(
        userRef,
        {
          userId: user.uid,
          email: user.email || '',
          displayName: user.displayName || 'Stark Operator',
          photoURL: user.photoURL || '',
          lastActive: new Date().toISOString(),
          createdTimestamp: Date.now(),
        },
        { merge: true }
      );
    } catch (e) {
      console.warn('Firestore profile sync note:', e);
    }

    return user;
  }

  public static async signOut(): Promise<void> {
    await fbSignOut(auth);
    this.currentUser = null;
  }

  public static onUserChanged(callback: (user: User | null) => void): () => void {
    return onAuthStateChanged(auth, (user) => {
      this.currentUser = user;
      callback(user);
    });
  }

  public static getUser(): User | null {
    return this.currentUser || auth.currentUser;
  }

  // Firestore Persistent Memories
  public static async saveMemory(memory: Partial<MemoryItem>): Promise<void> {
    const user = this.getUser();
    if (!user) return;

    try {
      const memRef = collection(db, 'users', user.uid, 'memories');
      await addDoc(memRef, {
        userId: user.uid,
        summary: memory.summary || 'Memory Record',
        details: memory.details || '',
        category: memory.category || 'conversation',
        importance: memory.importance || 'medium',
        timestamp: Date.now(),
      });
    } catch (e) {
      console.warn('Firestore memory save note:', e);
    }
  }

  public static async loadUserMemories(): Promise<MemoryItem[]> {
    const user = this.getUser();
    if (!user) return [];

    try {
      const memRef = collection(db, 'users', user.uid, 'memories');
      const q = query(memRef, orderBy('timestamp', 'desc'), limit(30));
      const snapshot = await getDocs(q);

      return snapshot.docs.map((docSnap) => {
        const data = docSnap.data();
        return {
          id: docSnap.id,
          category: data.category || 'preference',
          summary: data.summary || 'Memory Log',
          details: data.details || '',
          timestamp: 'Synced Cloud',
          importance: data.importance || 'medium',
        } as MemoryItem;
      });
    } catch (e) {
      return [];
    }
  }
}
