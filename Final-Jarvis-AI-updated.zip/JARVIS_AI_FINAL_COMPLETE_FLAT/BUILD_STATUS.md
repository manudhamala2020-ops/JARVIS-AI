# JARVIS AI — Engineering Build Status

## Completed in this repair pass
- Existing UI preserved; no UI redesign was intentionally introduced.
- Legacy armor gesture/audio subsystem removed.
- Legacy satellite subsystem references removed from executable source.
- Gemini reasoning defaults aligned with current Google model availability.
- Google GenAI SDK dependency updated to the current 2.19.x line.
- Vision endpoint no longer fabricates detection/identity/confidence data.
- Search and Maps no-key fallbacks no longer pretend that live results exist.
- Added `/api/capabilities` for honest capability reporting.
- Added environment overrides for reasoning/live voice model IDs.
- Added beginner setup instructions.
- Authentication secret handling hardened.

## Not falsely claimed as complete
Physical Android control, desktop control, real IoT hardware, private messaging, and persistent OS-level wake-word operation require real device permissions/integrations. The application reports these as unavailable rather than simulating success.

## Dependency installation
`node_modules` is intentionally not bundled. The isolated build environment could not finish downloading the dependency graph within the available execution time. The project declares its dependencies in `package.json` and is ready for installation in a Node-capable environment.
