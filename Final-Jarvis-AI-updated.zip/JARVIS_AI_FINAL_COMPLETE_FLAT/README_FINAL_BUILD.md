# JARVIS AI — Final Build

This archive is intended to be the clean starting point for a fresh private `JARVIS AI` repository.

### Start in GitHub Codespaces
```bash
npm install
npm run validate
npm run dev
```

`npm run validate` performs the repository audit, TypeScript check and production build.

### Important
The browser version cannot obtain unrestricted Android/system/application privileges. Capabilities requiring native permissions must be provided by an authorized Android bridge. Security functionality is defensive/authorized. No unrestricted malware, intrusion, interception or self-propagating behavior is included.
