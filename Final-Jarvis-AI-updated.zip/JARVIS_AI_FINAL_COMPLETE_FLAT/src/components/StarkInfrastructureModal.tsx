import React, { useState } from 'react';
import {
  X,
  Home,
  Sliders,
  ShieldCheck,
  Zap,
  Lock,
  Unlock,
  Cpu,
  RefreshCw,
  Power,
  Fan,
  Sun,
  Flame,
  Camera,
  Activity,
  Bot,
  Layers,
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface StarkInfrastructureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RoboticArm {
  id: string;
  name: string;
  role: string;
  status: 'Active' | 'Holding Extinguisher' | 'Idle' | 'Calibrating';
  battery: number;
  torque: string;
}

export const StarkInfrastructureModal: React.FC<StarkInfrastructureModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'mansion' | 'robotics' | 'cleanroom' | 'power'>('mansion');

  const [gateLocked, setGateLocked] = useState<boolean>(true);
  const [workshopShieldActive, setWorkshopShieldActive] = useState<boolean>(true);
  const [ventilationSpeed, setVentilationSpeed] = useState<number>(3);
  const [ambientLightingColor, setAmbientLightingColor] = useState<string>('#00f0ff');

  const [roboticArms, setRoboticArms] = useState<RoboticArm[]>([
    { id: 'arm-1', name: 'DUM-E (Designation 01)', role: 'Welding & Workshop Support', status: 'Holding Extinguisher', battery: 98, torque: '450 Nm' },
    { id: 'arm-2', name: 'U (Designation 02)', role: 'Camera Operator & Tool Fetching', status: 'Active', battery: 94, torque: '320 Nm' },
    { id: 'arm-3', name: 'Hydraulic Vehicle Lift #1', role: 'Audi R8 / Hot Rod Platform', status: 'Active', battery: 100, torque: '12,000 Nm' },
    { id: 'arm-4', name: 'Plasma Arc Deposition Arm', role: 'Nanotech Suit Sintering', status: 'Idle', battery: 100, torque: '850 Nm' },
  ]);

  if (!isOpen) return null;

  return (
    <div
      id="stark-infrastructure-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-lg animate-in fade-in duration-200 font-sans"
    >
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#050c18] border border-cyan-500/50 rounded-2xl shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col overflow-hidden text-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-black to-cyan-950/40">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-600/20 border border-cyan-500/50 rounded-lg">
              <Home className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[#00f0ff] font-orbitron font-black text-sm tracking-widest uppercase">
                  STARK MANSION & IOT INFRASTRUCTURE
                </span>
                <span className="px-2 py-0.5 bg-cyan-950 border border-cyan-700/60 rounded text-[10px] font-mono text-cyan-300">
                  POINT DUME FACILITY
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Security Gates, Workshop Robotic Arms (DUM-E & U) & Cleanroom Automation
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFx.playTap();
              onClose();
            }}
            className="p-1.5 bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-600/50 rounded-md text-cyan-300 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-950 border-b border-slate-800 text-xs font-semibold overflow-x-auto">
          {[
            { key: 'mansion', label: '1. MANSION GATES & LIGHTING', icon: Home },
            { key: 'robotics', label: '2. WORKSHOP ROBOTIC ARMS (DUM-E & U)', icon: Bot },
            { key: 'cleanroom', label: '3. CLEANROOM & AIR SCRUBBERS', icon: Fan },
            { key: 'power', label: '4. FACILITY GRID & SUB-STATIONS', icon: Zap },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => {
                  soundFx.playTap();
                  setActiveTab(tab.key as any);
                }}
                className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.3)]'
                    : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 text-cyan-400" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-5">
          {/* TAB 1: MANSION GATES & LIGHTING */}
          {activeTab === 'mansion' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-bold">
                    BIOMETRIC SECURITY GATEWAY
                  </h4>
                  <button
                    onClick={() => {
                      soundFx.playTap();
                      setGateLocked(!gateLocked);
                    }}
                    className={`px-3 py-1 text-xs font-mono rounded-lg border transition-all flex items-center gap-1.5 ${
                      gateLocked
                        ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                        : 'bg-red-950 border-red-600 text-red-300'
                    }`}
                  >
                    {gateLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                    <span>{gateLocked ? 'GATES LOCKED (SECURE)' : 'GATES UNLOCKED'}</span>
                  </button>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Heavy reinforced titanium gate with optical iris scan and under-vehicle magnetic bomb sweep sensors.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-mono text-cyan-400 uppercase tracking-wider font-bold">
                    WORKSHOP BLAST SHIELD
                  </h4>
                  <button
                    onClick={() => {
                      soundFx.playTap();
                      setWorkshopShieldActive(!workshopShieldActive);
                    }}
                    className={`px-3 py-1 text-xs font-mono rounded-lg border transition-all flex items-center gap-1.5 ${
                      workshopShieldActive
                        ? 'bg-cyan-950 border-cyan-600 text-cyan-300'
                        : 'bg-slate-900 border-slate-700 text-slate-400'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{workshopShieldActive ? 'SHIELD ENGAGED' : 'SHIELD LOWERED'}</span>
                  </button>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Reinforced laminated polycarbonate & tungsten glass perimeter protecting the workshop bay.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: WORKSHOP ROBOTICS */}
          {activeTab === 'robotics' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400">
                Direct neural & voice commands mapped to Tony Stark’s laboratory manipulator arms.
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {roboticArms.map((arm) => (
                  <div
                    key={arm.id}
                    className="p-4 bg-slate-950 border border-slate-800 hover:border-cyan-500/40 rounded-xl flex items-start justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="font-bold text-white font-orbitron flex items-center gap-2">
                        <Bot className="w-4 h-4 text-cyan-400" />
                        {arm.name}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">{arm.role}</div>
                      <div className="text-[10px] font-mono text-slate-500 mt-2">
                        Max Torque: {arm.torque} • Battery: {arm.battery}%
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-300 font-mono rounded text-[10px] font-bold">
                      {arm.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: CLEANROOM & SCRUBBERS */}
          {activeTab === 'cleanroom' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                <span className="text-slate-400">PARTICULATE COUNT</span>
                <div className="text-xl font-bold text-emerald-400 mt-1">ISO CLASS 1</div>
                <div className="text-[11px] text-slate-500 mt-1">&lt; 10 particles/m³</div>
              </div>
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                <span className="text-slate-400">VENTILATION VELOCITY</span>
                <div className="text-xl font-bold text-cyan-300 mt-1">SPEED {ventilationSpeed} / 5</div>
                <div className="text-[11px] text-slate-500 mt-1">Laminar Flow Airflow</div>
              </div>
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
                <span className="text-slate-400">POSITIVE PRESSURE</span>
                <div className="text-xl font-bold text-white mt-1">+15 Pa DELTA</div>
                <div className="text-[11px] text-slate-500 mt-1">Airlock Sealed</div>
              </div>
            </div>
          )}

          {/* TAB 4: FACILITY GRID */}
          {activeTab === 'power' && (
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between">
                <span className="text-cyan-400 font-bold">PRIMARY FACILITY POWER:</span>
                <span className="text-emerald-400 font-bold">SUB-BASEMENT ARC REACTOR (100%)</span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-3 overflow-hidden border border-slate-800">
                <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full w-full" />
              </div>
              <div className="text-slate-400 text-xs">
                Zero dependence on public municipal grid. Surpluses of 1.8 GW fed back to Malibu regional substation.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-black/60 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>STARK MANSION AUTOMATION • JARVIS CORE</span>
          <span className="text-cyan-400 font-bold">FACILITY ONLINE</span>
        </div>
      </div>
    </div>
  );
};
