import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sourceExt = new Set(['.ts','.tsx','.js','.jsx']);
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','.git','dist'].includes(e.name))continue;const p=path.join(dir,e.name);if(e.isDirectory())walk(p);else if(sourceExt.has(path.extname(e.name)))files.push(p);}}
walk(root);
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const declared=new Set([...Object.keys(pkg.dependencies||{}),...Object.keys(pkg.devDependencies||{})]);
const missing=[];
const bareImport=/from\s+['"]([^'".][^'"]*)['"]|import\s*\(\s*['"]([^'".][^'"]*)['"]\s*\)/g;
for(const file of files){const text=fs.readFileSync(file,'utf8');let m;while((m=bareImport.exec(text))){const spec=m[1]||m[2];const rootName=spec.startsWith('@')?spec.split('/').slice(0,2).join('/'):spec.split('/')[0];if(!declared.has(rootName) && !['node:fs','node:path','node:crypto','node:url','fs','path','crypto','url'].includes(spec))missing.push(`${path.relative(root,file)} -> ${spec}`);}}
const required=['package.json','index.html','server.ts','vite.config.ts','tsconfig.json','src/App.tsx','src/main.tsx','src/components/JarvisCore.tsx','src/services/handTrackingService.ts','src/services/voiceService.ts'];
const absent=required.filter(x=>!fs.existsSync(path.join(root,x)));
console.log(`Scanned ${files.length} source files.`);
if(absent.length) { console.error('Missing required files:', absent.join(', ')); process.exitCode=1; }
if(missing.length) { console.error('Undeclared bare imports:'); for(const x of missing) console.error('  '+x); process.exitCode=1; }
if(!process.exitCode) console.log('Static project audit: PASS');
