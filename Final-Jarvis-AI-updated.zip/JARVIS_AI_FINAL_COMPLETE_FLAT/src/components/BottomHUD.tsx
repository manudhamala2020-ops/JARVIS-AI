import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Send,
  Square,
  VolumeX,
} from 'lucide-react';
import { JarvisState } from '../types';

interface BottomHUDProps {
  jarvisState: JarvisState;
  responseText: string;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleMic: () => void;
  onSubmitCommand: (command: string) => void;
  onStopSpeaking?: () => void;
}

export const BottomHUD: React.FC<BottomHUDProps> = ({
  jarvisState,
  responseText,
  isListening,
  isSpeaking,
  onToggleMic,
  onSubmitCommand,
  onStopSpeaking,
}) => {
  const [inputText, setInputText] = useState('');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSubmitCommand(inputText.trim());
    setInputText('');
  };

  // State text mapping
  const getStatusDisplay = () => {
    switch (jarvisState) {
      case 'LISTENING':
      case 'WAKE_DETECTED':
        return 'JARVIS LISTENING...';
      case 'THINKING':
      case 'PROCESSING':
        return 'NEURAL REASONING IN PROGRESS...';
      case 'SEARCHING':
        return 'SEARCHING MULTI-SOURCE KNOWLEDGE...';
      case 'EXECUTING':
        return 'EXECUTING COMMAND...';
      case 'SPEAKING':
        return 'JARVIS VOCAL SYNTHESIS ACTIVE';
      case 'VISION_ACTIVE':
        return 'OPTICAL SENSORS ENGAGED';
      case 'GESTURE_ACTIVE':
        return 'GESTURE TRACKING ACTIVE';
      case 'WARNING':
        return 'SYSTEM WARNING';
      case 'ERROR':
        return 'SUBSYSTEM RECOVERY';
      default:
        return 'JARVIS ONLINE';
    }
  };

  const getStatusColor = () => {
    switch (jarvisState) {
      case 'LISTENING':
      case 'WAKE_DETECTED':
        return 'bg-emerald-400 shadow-[0_0_12px_#34d399] animate-pulse';
      case 'THINKING':
      case 'PROCESSING':
        return 'bg-amber-400 shadow-[0_0_12px_#fbbf24]';
      case 'SEARCHING':
        return 'bg-purple-400 shadow-[0_0_12px_#c084fc]';
      case 'EXECUTING':
        return 'bg-cyan-300 shadow-[0_0_15px_#67e8f9]';
      case 'SPEAKING':
        return 'bg-cyan-400 shadow-[0_0_12px_#00f0ff] animate-pulse';
      case 'WARNING':
      case 'ERROR':
        return 'bg-rose-500 shadow-[0_0_12px_#f43f5e]';
      default:
        return 'bg-[#00f0ff] shadow-[0_0_8px_#00f0ff]';
    }
  };

  return (
    <div
      id="bottom-hud"
      className="fixed bottom-5 left-1/2 -translate-x-1/2 w-[94%] max-w-[680px] bg-[#060a14]/90 border border-[#00f0ff]/40 rounded-[14px] p-3 md:p-3.5 backdrop-blur-md shadow-[0_0_25px_rgba(0,240,255,0.18)] flex flex-col gap-2 z-40 transition-all"
    >
      {/* Top HUD Row: Clean Status & Start/Stop Vocal Controls */}
      <div id="status-row" className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div
            id="status-indicator"
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${getStatusColor()}`}
          />
          <span
            id="status-text"
            className="text-[#00f0ff] text-[11px] font-bold tracking-[1.2px] uppercase font-orbitron"
          >
            {getStatusDisplay()}
          </span>
        </div>

        {/* Immediate Stop Vocal Response Action when JARVIS is Speaking */}
        {(isSpeaking || jarvisState === 'SPEAKING') && onStopSpeaking && (
          <button
            id="hud-btn-stop-speech"
            type="button"
            onClick={onStopSpeaking}
            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-md text-[11px] font-orbitron font-bold flex items-center gap-1.5 shadow-[0_0_12px_rgba(244,63,94,0.6)] animate-pulse transition-all"
            title="Stop Jarvis speaking immediately (or say 'Hey Jarvis, stop')"
          >
            <Square className="w-3 h-3 fill-current" />
            <span>STOP TALKING</span>
          </button>
        )}
      </div>

      {/* Response Box - Preserves CSS and layout */}
      <div
        id="response-box"
        className="text-white text-[13px] leading-[1.45] min-h-[42px] max-h-[85px] overflow-y-auto p-2 bg-black/60 rounded-[6px] border-l-2 border-[#00f0ff] font-mono-tech select-text"
      >
        {responseText ||
          'Awaiting speech command ("Hey Jarvis") or hand gesture input...'}
      </div>

      {/* Text Command & Voice Input Bar */}
      <form onSubmit={handleFormSubmit} className="flex items-center gap-2 mt-0.5">
        <button
          type="button"
          id="hud-btn-mic"
          onClick={onToggleMic}
          className={`h-9 px-3 rounded-lg border flex items-center justify-center gap-1.5 text-xs font-bold font-orbitron transition-all ${
            isListening
              ? 'bg-rose-950/80 border-rose-500 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.4)] animate-pulse'
              : 'bg-cyan-950/80 border-cyan-500/60 text-cyan-300 hover:bg-cyan-900/80 hover:text-white'
          }`}
          title={isListening ? 'Stop Listening' : 'Start Voice Listening'}
        >
          {isListening ? (
            <>
              <Mic className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
              <span>LISTENING</span>
            </>
          ) : (
            <>
              <MicOff className="w-3.5 h-3.5 text-cyan-400" />
              <span>VOICE MIC</span>
            </>
          )}
        </button>

        <div className="relative flex-1">
          <input
            id="hud-command-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Command JARVIS or ask (English / Hindi / Hinglish)..."
            className="w-full h-9 bg-black/70 border border-cyan-500/40 rounded-lg px-3 pr-8 text-xs text-cyan-100 placeholder-cyan-600/70 focus:outline-none focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff]/50 font-mono-tech"
          />
          {inputText && (
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 text-cyan-400 hover:text-cyan-200"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
