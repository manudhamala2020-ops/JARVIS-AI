import Anthropic from "@anthropic-ai/sdk";

export type ChatMessage = { role: "user" | "model"; text: string };

export interface ProviderChatResult {
  text: string;
  modelUsed: string;
  provider: "claude";
}

// Lazy client. Key is read from process.env only — this file never runs in the browser
// and must never be imported from client code.
const getClaude = (): Anthropic | null => {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;
  return new Anthropic({ apiKey });
};

export const isClaudeConfigured = (): boolean => Boolean(process.env.ANTHROPIC_API_KEY);

const CLAUDE_MODEL = process.env.JARVIS_CLAUDE_MODEL || "claude-fable-5-1";

/**
 * Claude capability map, mirrored against what the orchestrator reports via /api/capabilities.
 * Keep this honest — do not mark a modality true unless this provider actually implements it.
 */
export const claudeCapabilities = {
  text: true,
  reasoning: true,
  coding: true,
  vision: true, // image input via base64 content blocks — implemented below
  audioTranscription: false, // not implemented in this provider
  imageGeneration: false, // Claude does not generate images
  videoGeneration: false,
  search: false, // no built-in web search wired here
};

export const chatWithClaude = async (
  messages: ChatMessage[],
  systemInstruction?: string,
  imageBase64?: { data: string; mediaType: string }
): Promise<ProviderChatResult> => {
  const client = getClaude();
  if (!client) {
    throw Object.assign(new Error("EXTERNAL_CREDENTIAL_REQUIRED: ANTHROPIC_API_KEY is not set on the server."), {
      code: "EXTERNAL_CREDENTIAL_REQUIRED",
    });
  }

  const anthropicMessages = messages.map((m, i) => {
    const isLastUser = imageBase64 && i === messages.length - 1 && m.role === "user";
    return {
      role: (m.role === "user" ? "user" : "assistant") as "user" | "assistant",
      content: isLastUser
        ? [
            { type: "image" as const, source: { type: "base64" as const, media_type: imageBase64!.mediaType as any, data: imageBase64!.data } },
            { type: "text" as const, text: m.text },
          ]
        : m.text,
    };
  });

  const response = await client.messages.create({
    model: CLAUDE_MODEL,
    max_tokens: 2048,
    system:
      systemInstruction ||
      "You are J.A.R.V.I.S., the advanced tactical autonomous assistant. Provide precise, witty, professional responses with expert technical depth.",
    messages: anthropicMessages,
  });

  const text = response.content
    .map((block) => (block.type === "text" ? block.text : ""))
    .filter(Boolean)
    .join("\n");

  return { text, modelUsed: CLAUDE_MODEL, provider: "claude" };
};
