/**
 * JARVIS Capability Registry
 * ---------------------------------------------------------------------------
 * A single, honest source of truth for "can JARVIS actually do X right now".
 * Every entry below reflects code that exists elsewhere in this repo — nothing
 * here is aspirational. Where a requested feature needs something this app
 * cannot provide (real satellite/geospatial credentials, OS-level Android
 * permissions, an authenticated remote-desktop bridge, medical-grade sensors),
 * it is marked accordingly instead of being silently implied as working.
 *
 * Status meanings:
 *  - "available"                   real implementation exists and runs today
 *  - "requires_credentials"        implementation exists but needs an API key
 *                                   the operator must supply (server .env)
 *  - "requires_external_hardware"  cannot exist as browser/Node code — needs
 *                                   a wearable, satellite feed, dedicated
 *                                   hardware bridge, etc.
 *  - "platform_restricted"         a browser (and in most cases a phone OS)
 *                                   will not grant this to a web app, by design
 *  - "not_implemented"             no code for this yet — a real future phase,
 *                                   not a placeholder pretending to work
 */

export type CapabilityStatus =
  | "available"
  | "requires_credentials"
  | "requires_external_hardware"
  | "platform_restricted"
  | "not_implemented";

export interface CapabilityEntry {
  id: string;
  label: string;
  status: CapabilityStatus;
  note: string;
}

export interface CapabilityDomain {
  domain: string;
  entries: CapabilityEntry[];
}

export const CAPABILITY_REGISTRY: CapabilityDomain[] = [
  {
    domain: "Intelligence",
    entries: [
      { id: "gemini-reasoning", label: "Gemini conversation & reasoning", status: "requires_credentials", note: "GEMINI_API_KEY required server-side (src/server/providers/geminiProvider.ts)." },
      { id: "claude-reasoning", label: "Claude conversation & reasoning", status: "requires_credentials", note: "ANTHROPIC_API_KEY required server-side (src/server/providers/claudeProvider.ts)." },
      { id: "dual-provider-synthesis", label: "Gemini + Claude synthesis", status: "requires_credentials", note: "Both keys required; POST /api/ai/orchestrate with provider: \"both\"." },
      { id: "memory", label: "Conversation/memory persistence", status: "available", note: "Firestore-backed via authService.ts, requires the user's own sign-in." },
    ],
  },
  {
    domain: "Vision",
    entries: [
      { id: "hand-tracking", label: "Hand/gesture tracking", status: "available", note: "MediaPipe Hands pipeline in JarvisCore.tsx." },
      { id: "camera-vision", label: "Camera scene understanding", status: "requires_credentials", note: "Routed through Gemini multimodal (geminiMultiModalRoutes.ts)." },
      { id: "document-image-vision", label: "Uploaded image/document analysis", status: "requires_credentials", note: "Claude and Gemini both support image input; needs the respective key." },
    ],
  },
  {
    domain: "Web & Browser",
    entries: [
      { id: "search-grounding", label: "Web search grounding", status: "requires_credentials", note: "Existing /api/gemini/search route; needs GEMINI_API_KEY." },
      { id: "in-tab-browser-agent", label: "Autonomous browsing across arbitrary open tabs/sites", status: "not_implemented", note: "Would need a browser-extension or Chrome-DevTools-Protocol bridge, not just page JS. Real to build, not built yet — do not enable in UI until it exists." },
    ],
  },
  {
    domain: "Files & Documents",
    entries: [
      { id: "file-picker-access", label: "User-selected file/folder access", status: "available", note: "fileAccessService.ts — File System Access API, one explicit picker + permission grant per file/folder, nothing implicit." },
      { id: "document-understanding", label: "Resume/Doc/PDF content understanding", status: "requires_credentials", note: "File text/bytes are read locally then sent to whichever AI provider is configured." },
      { id: "background-filesystem-access", label: "Access to files the user did not explicitly pick", status: "platform_restricted", note: "Browsers will never grant this to a web app — by design, not a JARVIS limitation." },
    ],
  },
  {
    domain: "Business & Enterprise",
    entries: [
      { id: "dashboard-data-analysis", label: "Analyze pasted/uploaded business data", status: "requires_credentials", note: "Generic reasoning task, routed through the orchestrator." },
      { id: "live-crm-erp-integration", label: "Live connection to a specific CRM/ERP/ad platform", status: "not_implemented", note: "Each such integration needs that platform's own OAuth app + API — real, buildable, but per-platform and not generic." },
    ],
  },
  {
    domain: "Security",
    entries: [
      { id: "code-vuln-analysis", label: "Static code/vulnerability analysis", status: "requires_credentials", note: "Reasoning-based review via the orchestrator, not a signature-based scanner." },
      { id: "encrypted-backup", label: "Encrypted local backup/recovery", status: "not_implemented", note: "Real and buildable (e.g. Web Crypto + IndexedDB); not yet built." },
      { id: "intrusion-offense", label: "Network intrusion / credential bypass / interception", status: "not_implemented", note: "Deliberately out of scope — will not be built. See defensive alternatives (code-vuln-analysis, encrypted-backup) instead." },
    ],
  },
  {
    domain: "Location & External Data",
    entries: [
      { id: "geolocation", label: "Browser geolocation (user's own device)", status: "available", note: "Standard navigator.geolocation, with the normal browser permission prompt." },
      { id: "satellite-imagery", label: "Satellite/geospatial imagery access", status: "requires_credentials", note: "Needs a real licensed provider (e.g. Maxar, Sentinel Hub) and its own API key — not something any AI model can conjure without that subscription." },
    ],
  },
  {
    domain: "Autonomy",
    entries: [
      { id: "bounded-agent-tasks", label: "Multi-step tool-using tasks within this app", status: "available", note: "Orchestrator + existing tool routes; every consequential action still needs the normal UI confirmation." },
      { id: "background-missions", label: "Background sub-agents (CASE/TARS) for research, drafting, summarizing", status: "available", note: "src/server/missionsService.ts + MissionsModal.tsx. Missions that mention calling, paying, booking, or publishing are auto-flagged awaiting_approval and require an explicit approve step — they never self-execute." },
      { id: "unbounded-autonomous-control", label: "Fully autonomous action without human approval", status: "not_implemented", note: "Intentionally not built — every consequential action requires an explicit approval gate." },
    ],
  },
  {
    domain: "Telephony & Real-World Calling",
    entries: [
      { id: "telephony-hotline", label: "Dedicated JARVIS phone number with PIN authentication", status: "not_implemented", note: "Buildable with a real telephony provider (e.g. Twilio, Retell AI) — needs its own account, phone number, and API key. Scaffolding not yet written." },
      { id: "outbound-autonomous-calling", label: "JARVIS autonomously calls restaurants/businesses to negotiate/book", status: "not_implemented", note: "Same provider dependency as above, plus this is a 'consequential action' by this project's own rule — would launch through the missions approval gate, never silently." },
      { id: "telegram-voice-parser", label: "Telegram voice notes parsed into tasks", status: "not_implemented", note: "Needs a Telegram bot token (free to create, but still a credential the operator must supply)." },
    ],
  },
  {
    domain: "Voice Identity",
    entries: [
      { id: "generic-tts-british-accent", label: "Generic British-accent text-to-speech", status: "available", note: "Web Speech API in KnowledgeGalaxyModal/voiceService; any system British voice, not a specific person." },
      { id: "clone-named-real-person-voice", label: "Cloning a specific named real person's (e.g. an actor's) voice", status: "not_implemented", note: "Declined on principle, not a technical gap — replicating a real individual's voice likeness without their consent isn't something this project will do, regardless of provider used." },
    ],
  },
  {
    domain: "Google Workspace",
    entries: [
      { id: "gmail-calendar-docs-sheets", label: "Gmail / Calendar / Docs / Sheets integration", status: "not_implemented", note: "Needs a Google Cloud OAuth client (the user's own, consented per-account) — legitimate and buildable, credential-gated like everything else here." },
    ],
  },
  {
    domain: "Desktop & Screen Control",
    entries: [
      { id: "screen-vision-critique", label: "Analyze a screenshot/screen region on request", status: "requires_credentials", note: "Reuses existing Gemini/Claude image-input support — user explicitly shares a screenshot, JARVIS doesn't watch continuously." },
      { id: "continuous-screen-watching", label: "Continuously monitor the desktop without being asked each time", status: "platform_restricted", note: "A browser tab cannot silently capture the screen — getDisplayMedia requires an explicit, visible one-time permission grant per session, by browser design." },
      { id: "autonomous-mouse-keyboard-control", label: "JARVIS drives the mouse/keyboard across arbitrary desktop apps", status: "platform_restricted", note: "Not obtainable from a web app; would need a native OS-level companion process with its own explicit install and permission grant — a different project." },
    ],
  },
  {
    domain: "Business & Payments",
    entries: [
      { id: "invoice-generation", label: "Generate a styled invoice, printable to PDF", status: "available", note: "src/server/invoiceService.ts + POST /api/invoices/generate. Returns print-ready HTML; browser Print -> Save as PDF produces a real PDF with no added dependencies." },
      { id: "stripe-payment-links", label: "Autonomously issue Stripe payment links", status: "not_implemented", note: "Needs the user's own Stripe account/API key. Would route through the missions approval gate before ever generating a real charge link." },
      { id: "ad-campaign-deployment", label: "Autonomously deploy Meta/Google ad campaigns", status: "not_implemented", note: "Needs the user's own ad-platform OAuth credentials, and spends real money — approval-gated by design, not just by missing credentials." },
    ],
  },
  {
    domain: "Home & IoT",
    entries: [
      { id: "smart-home-webhooks", label: "Control Home Assistant / smart lighting / locks", status: "not_implemented", note: "Needs the user's own Home Assistant instance + long-lived access token. Legitimate, buildable, not yet built." },
    ],
  },
  {
    domain: "Device & OS Bridges",
    entries: [
      { id: "android-system-settings", label: "Reading/changing arbitrary Android system settings", status: "platform_restricted", note: "A Chrome tab cannot be granted OS-level Android permissions. Would require a native companion app with its own permission grants — different project, different install." },
      { id: "remote-computer-control", label: "Controlling another computer remotely", status: "not_implemented", note: "Needs an authenticated remote-desktop/bridge protocol (e.g. a signed native agent) — real to build, not present here." },
    ],
  },
  {
    domain: "Health & Wearables",
    entries: [
      { id: "vitals-monitoring", label: "Monitoring human vitals", status: "requires_external_hardware", note: "Requires an actual supported wearable/sensor with its own consented data feed. JARVIS will not simulate or estimate vitals — that would be presenting a guess as medical data." },
    ],
  },
];

/** Flat lookup used by the server capability endpoint and any UI that wants a live status list. */
export const getCapabilitySummary = () => {
  const counts: Record<CapabilityStatus, number> = {
    available: 0,
    requires_credentials: 0,
    requires_external_hardware: 0,
    platform_restricted: 0,
    not_implemented: 0,
  };
  for (const domain of CAPABILITY_REGISTRY) {
    for (const entry of domain.entries) counts[entry.status]++;
  }
  return { domains: CAPABILITY_REGISTRY, counts };
};
