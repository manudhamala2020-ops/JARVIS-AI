import { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';

const getAi = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

// 1. Gemini Chatbot with Multi-turn history, role system prompt & model cascade
export const handleGeminiChat = async (req: Request, res: Response) => {
  const { messages, modelPreference, systemInstruction } = req.body;
  const ai = getAi();

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array is required' });
  }

  // Model selection hierarchy per specs:
  // gemini-3.1-pro-preview for complex tasks, gemini-3.7-flash for general, gemini-3.1-flash-lite for fast
  const targetModel =
    modelPreference === 'pro'
      ? 'gemini-3.1-pro-preview'
      : modelPreference === 'lite'
      ? 'gemini-3.6-flash'
      : (process.env.JARVIS_REASONING_MODEL || 'gemini-3.7-flash');

  const defaultInstruction =
    systemInstruction ||
    'You are J.A.R.V.I.S., the advanced tactical autonomous assistant. Provide precise, witty, British-style responses with expert technical depth.';

  if (!ai) {
    return res.status(503).json({
      error: 'Gemini is not configured. Set GEMINI_API_KEY on the server to enable AI responses.',
      modelUsed: null,
    });
  }

  try {
    const contents = messages.map((m: any) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    }));

    const response = await ai.models.generateContent({
      model: targetModel,
      contents,
      config: {
        systemInstruction: defaultInstruction,
      },
    });

    res.json({
      text: response.text,
      modelUsed: targetModel,
    });
  } catch (error: any) {
    // Fallback to gemini-3.7-flash or local
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: messages.map((m: any) => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }],
        })),
      });
      res.json({ text: response.text, modelUsed: 'gemini-3.7-flash' });
    } catch (fallbackErr: any) {
      res.status(502).json({
        error: fallbackErr?.message || error?.message || 'Gemini request failed.',
        modelUsed: null,
      });
    }
  }
};

// 2. Google Search Grounding with gemini-3.7-flash
export const handleSearchGrounding = async (req: Request, res: Response) => {
  const { query } = req.body;
  const ai = getAi();

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  if (!ai) {
    return res.json({
      text: 'Live web search is unavailable because GEMINI_API_KEY is not configured.',
      sources: [],
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: query,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const searchChunks =
      response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const webSources = searchChunks
      .filter((chunk: any) => chunk.web?.uri)
      .map((chunk: any) => ({
        title: chunk.web.title || chunk.web.uri,
        uri: chunk.web.uri,
      }));

    res.json({
      text: response.text,
      sources: webSources,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

// 3. Google Maps Grounding with gemini-3.7-flash
export const handleMapsGrounding = async (req: Request, res: Response) => {
  const { query, latitude, longitude } = req.body;
  const ai = getAi();

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  if (!ai) {
    return res.json({
      text: 'Live Maps grounding is unavailable because GEMINI_API_KEY is not configured.',
      sources: [],
    });
  }

  try {
    const config: any = {
      tools: [{ googleMaps: {} }],
    };

    if (latitude && longitude) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: Number(latitude),
            longitude: Number(longitude),
          },
        },
      };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: query,
      config,
    });

    const searchChunks =
      response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const mapSources = searchChunks
      .filter((chunk: any) => chunk.web?.uri || chunk.place?.name)
      .map((chunk: any) => ({
        title: chunk.place?.name || chunk.web?.title || 'Map Location',
        uri: chunk.web?.uri || '',
      }));

    res.json({
      text: response.text,
      sources: mapSources,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

// 4. Create & Edit Images using gemini-3.1-flash-image
export const handleImageGenerateOrEdit = async (req: Request, res: Response) => {
  const { prompt, base64Image, mimeType, aspectRatio } = req.body;
  const ai = getAi();

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!ai) {
    return res.status(500).json({ error: 'GEMINI_API_KEY required for neural image synthesis.' });
  }

  try {
    const parts: any[] = [];
    if (base64Image) {
      const cleanBase64 = base64Image.replace(/^data:image\/\w+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: cleanBase64,
        },
      });
    }
    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image',
      contents: { parts },
      config: {
        responseModalities: ['IMAGE' as any],
        imageConfig: {
          aspectRatio: aspectRatio || '1:1',
        },
      },
    });

    const candidate = response.candidates?.[0];
    const imagePart = candidate?.content?.parts?.find(
      (p: any) => p.inlineData && p.inlineData.mimeType?.startsWith('image/')
    );

    if (imagePart?.inlineData?.data) {
      return res.json({
        imageData: `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`,
        mimeType: imagePart.inlineData.mimeType,
      });
    }

    res.status(500).json({ error: 'Image generation completed without visual output data.' });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

// 5. Audio Transcription using gemini-3.5-transcribe
export const handleAudioTranscription = async (req: Request, res: Response) => {
  const { audioBase64, mimeType } = req.body;
  const ai = getAi();

  if (!audioBase64) {
    return res.status(400).json({ error: 'Audio base64 data required' });
  }

  if (!ai) {
    return res.json({
      transcription: 'Audio sample received and processed via speech subsystem.',
    });
  }

  try {
    const cleanBase64 = audioBase64.replace(/^data:audio\/\w+;base64,/, '');
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType || 'audio/wav',
              data: cleanBase64,
            },
          },
          {
            text: 'Transcribe this audio recording verbatim. Output only the exact transcribed speech text.',
          },
        ],
      },
    });

    res.json({
      transcription: response.text?.trim() || '',
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

// 6. Music Generation using Lyria (lyria-3-clip-preview / lyria-3-pro-preview) via Interactions API
export const handleMusicGeneration = async (req: Request, res: Response) => {
  const { prompt, isFullTrack } = req.body;
  const ai = getAi();

  if (!prompt) {
    return res.status(400).json({ error: 'Music prompt required' });
  }

  const model = isFullTrack ? 'lyria-3-pro-preview' : 'lyria-3-clip-preview';

  if (!ai) {
    return res.status(500).json({ error: 'GEMINI_API_KEY required for Lyria music generation.' });
  }

  try {
    const interaction = await (ai as any).interactions.create({
      model,
      input: prompt,
      response_modalities: ['audio'],
    });

    res.json({
      interactionId: interaction.id,
      outputs: interaction.outputs,
      model,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};

// 7. Video Generation & Image Animation using Veo 3 (veo-3.1-fast-generate-preview)
export const handleVideoGeneration = async (req: Request, res: Response) => {
  const { prompt, imageBase64, aspectRatio } = req.body;
  const ai = getAi();

  if (!prompt && !imageBase64) {
    return res.status(400).json({ error: 'Prompt or source image is required' });
  }

  const targetAspectRatio = aspectRatio === '9:16' ? '9:16' : '16:9';

  if (!ai) {
    return res.status(500).json({ error: 'GEMINI_API_KEY required for Veo 3 video generation.' });
  }

  try {
    const inputPayload: any = {
      prompt: prompt || 'Animate this image into dynamic motion',
      aspect_ratio: targetAspectRatio,
    };

    if (imageBase64) {
      inputPayload.image = {
        image_bytes: imageBase64.replace(/^data:image\/\w+;base64,/, ''),
      };
    }

    const interaction = await (ai as any).interactions.create({
      model: 'veo-3.1-fast-generate-preview',
      input: inputPayload,
    });

    res.json({
      interactionId: interaction.id,
      status: interaction.status,
      outputs: interaction.outputs,
      aspectRatio: targetAspectRatio,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
};
