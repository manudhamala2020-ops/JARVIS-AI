import React from 'react';
import { Volume2, Mic, X } from 'lucide-react';
import { JarvisState } from '../types';

interface VoicePopupProps {
  jarvisState: JarvisState;
  popupText: string;
  visible: boolean;
  onClose?: () => void;
}

export const VoicePopup: React.FC<VoicePopupProps> = ({
  jarvisState,
  popupText,
  visible,
  onClose,
}) => {
  return (
    <div
      id="jarvis-popup"
      className={`fixed bottom-6 right-6 w-72 md:w-80 bg-[#0a1020]/90 border border-[#00f0ff]/60 rounded-xl p-3.5 md:p-4 backdrop-blur-xl shadow-[0_0_25px_rgba(0,240,255,0.3)] flex flex-col gap-2 z-50 transition-all duration-300 ${
        visible
          ? 'opacity-100 translate-y-0 pointer-events-auto'
          : 'opacity-0 translate-y-5 pointer-events-none'
      }`}
    >
      <div className="popup-header flex items-center justify-between font-orbitron text-[10px] font-extrabold text-[#00f0ff] tracking-[1px]">
        <div className="flex items-center gap-2">
          <div className="popup-orb w-2.5 h-2.5 bg-[#00f0ff] rounded-full shadow-[0_0_8px_#00f0ff] animate-pulse-orb" />
          <span>JARVIS VOICE CORE</span>
        </div>
        <div className="flex items-center gap-2 text-cyan-400/70 text-[9px] font-mono-tech">
          {jarvisState === 'SPEAKING' ? (
            <>
              <Volume2 className="w-3 h-3 text-cyan-300 animate-pulse" />
              <span>VOCAL</span>
            </>
          ) : (
            <>
              <Mic className="w-3 h-3 text-emerald-400 animate-bounce" />
              <span>AUDIO IN</span>
            </>
          )}
          {onClose && (
            <button
              onClick={onClose}
              className="p-0.5 hover:text-white transition-colors"
              title="Dismiss Popup"
            >
              <X className="w-3 h-3 text-cyan-500 hover:text-white" />
            </button>
          )}
        </div>
      </div>

      <div
        id="popup-text"
        className="text-[#e0f7fc] text-xs leading-relaxed font-mono-tech max-h-28 overflow-y-auto"
      >
        {popupText || 'Listening... Say "Hey Jarvis" or an instruction...'}
      </div>
    </div>
  );
};
