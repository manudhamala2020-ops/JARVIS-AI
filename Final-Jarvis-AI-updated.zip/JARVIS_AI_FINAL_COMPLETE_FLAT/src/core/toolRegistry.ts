import { authorizeCapability } from './authorization';
export interface JarvisToolContext{approved?:boolean;signal?:AbortSignal;}
export interface JarvisTool{id:string;capability:string;description:string;execute:(input:unknown,context:JarvisToolContext)=>Promise<unknown>;}
const tools=new Map<string,JarvisTool>();
export function registerJarvisTool(tool:JarvisTool){if(tools.has(tool.id))throw new Error(`JARVIS tool already registered: ${tool.id}`);tools.set(tool.id,tool);return()=>tools.delete(tool.id);}
export function listJarvisTools(){return[...tools.values()];}
export async function executeJarvisTool(id:string,input:unknown,context:JarvisToolContext={}):Promise<unknown>{const tool=tools.get(id);if(!tool)throw new Error(`Unknown JARVIS tool: ${id}`);const decision=authorizeCapability(tool.capability,Boolean(context.approved));if(!decision.allowed)throw new Error(decision.reason);if(context.signal?.aborted)throw new DOMException('Operation aborted','AbortError');return tool.execute(input,context);}
