import React, { useState } from 'react';
import {
  X,
  Lightbulb,
  Thermometer,
  Lock,
  Unlock,
  Tv,
  Fan,
  Shield,
  Camera,
  Play,
  CheckCircle2,
  Power,
  RotateCw,
  Sun,
  Flame,
  Snowflake,
  Wind,
  ShieldAlert,
  Film,
  Cpu,
} from 'lucide-react';
import { SmartDevice, SmartScene } from '../types';

interface SmartHomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  devices: SmartDevice[];
  scenes: SmartScene[];
  onUpdateDevice: (deviceId: string, updates: Partial<SmartDevice>) => void;
  onActivateScene: (sceneId: string) => void;
}

export const SmartHomeModal: React.FC<SmartHomeModalProps> = ({
  isOpen,
  onClose,
  devices,
  scenes,
  onUpdateDevice,
  onActivateScene,
}) => {
  const [selectedRoom, setSelectedRoom] = useState<string>('All');

  if (!isOpen) return null;

  const rooms = ['All', ...Array.from(new Set(devices.map((d) => d.room)))];
  const filteredDevices =
    selectedRoom === 'All'
      ? devices
      : devices.filter((d) => d.room === selectedRoom);

  const totalWatts = devices
    .filter((d) => d.power && d.powerWatts)
    .reduce((acc, d) => acc + (d.powerWatts || 0), 0);

  const activeCount = devices.filter((d) => d.power).length;

  const getDeviceIcon = (type: SmartDevice['type']) => {
    switch (type) {
      case 'light':
        return <Lightbulb className="w-4 h-4" />;
      case 'thermostat':
        return <Thermometer className="w-4 h-4" />;
      case 'lock':
        return <Lock className="w-4 h-4" />;
      case 'media':
        return <Tv className="w-4 h-4" />;
      case 'fan':
        return <Fan className="w-4 h-4" />;
      case 'camera':
        return <Camera className="w-4 h-4" />;
      case 'security':
        return <Shield className="w-4 h-4" />;
      default:
        return <Power className="w-4 h-4" />;
    }
  };

  const getSceneIcon = (iconName: string) => {
    switch (iconName) {
      case 'Film':
        return <Film className="w-4 h-4" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-4 h-4" />;
      case 'SunMedium':
        return <Sun className="w-4 h-4" />;
      case 'Cpu':
        return <Cpu className="w-4 h-4" />;
      default:
        return <Play className="w-4 h-4" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-4 overflow-hidden font-rajdhani">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-cyan-400 rounded-full shadow-[0_0_10px_#00f0ff] animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider flex items-center gap-2">
                <span>JARVIS SMART HOME NEURAL MATRIX</span>
                <span className="text-xs px-2 py-0.5 bg-cyan-950 border border-cyan-500/40 rounded text-cyan-400 font-mono-tech">
                  {activeCount} / {devices.length} Active
                </span>
              </h2>
              <p className="text-xs text-cyan-500 font-mono-tech">
                Grid Load: {totalWatts}W • IoT Mesh: Synchronized • Voice
                Controllable
              </p>
            </div>
          </div>
          <button
            id="close-smarthome-modal"
            onClick={onClose}
            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-lg border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Automation Protocol Bar */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[11px] font-bold text-cyan-400 font-orbitron tracking-wider">
            ONE-TOUCH AUTOMATION PROTOCOLS:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {scenes.map((scene) => (
              <button
                key={scene.id}
                onClick={() => onActivateScene(scene.id)}
                className="p-2.5 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/40 hover:border-cyan-400 rounded-xl text-left transition-all flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between text-xs font-bold text-cyan-200">
                  <span className="flex items-center gap-1.5">
                    {getSceneIcon(scene.icon)}
                    <span>{scene.name}</span>
                  </span>
                  <Play className="w-3 h-3 text-cyan-400 group-hover:scale-125 transition-transform" />
                </div>
                <p className="text-[10px] text-cyan-400/70 mt-1 line-clamp-2 font-mono-tech leading-tight">
                  {scene.description}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Room Filter Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs border-b border-cyan-900/50">
          <span className="text-cyan-500 font-bold text-xs uppercase font-orbitron mr-1">
            Zone:
          </span>
          {rooms.map((room) => (
            <button
              key={room}
              onClick={() => setSelectedRoom(room)}
              className={`px-3 py-1 rounded-lg border text-xs font-semibold whitespace-nowrap transition-all ${
                selectedRoom === room
                  ? 'bg-cyan-500 text-black border-cyan-300 font-bold shadow-[0_0_10px_#00f0ff]'
                  : 'bg-black/50 text-cyan-300 border-cyan-800/60 hover:bg-cyan-950/60'
              }`}
            >
              {room}
            </button>
          ))}
        </div>

        {/* Devices Grid */}
        <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredDevices.map((device) => {
            const isLight = device.type === 'light';
            const isThermostat = device.type === 'thermostat';
            const isLock = device.type === 'lock';
            const isMedia = device.type === 'media';
            const isCurtain = device.type === 'curtain';
            const isFan = device.type === 'fan';

            return (
              <div
                key={device.id}
                className={`p-3.5 rounded-xl border transition-all flex flex-col justify-between gap-2.5 ${
                  device.power
                    ? 'bg-[#081329]/90 border-cyan-500/60 shadow-[0_0_15px_rgba(0,240,255,0.15)]'
                    : 'bg-black/60 border-cyan-900/40 opacity-70'
                }`}
              >
                {/* Device Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`p-2 rounded-lg border ${
                        device.power
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(0,240,255,0.3)]'
                          : 'bg-gray-900 border-gray-700 text-gray-400'
                      }`}
                    >
                      {getDeviceIcon(device.type)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-cyan-100 font-orbitron line-clamp-1">
                        {device.name}
                      </h4>
                      <p className="text-[10px] text-cyan-500 font-mono-tech">
                        {device.room} • {device.powerWatts ? `${device.powerWatts}W` : 'Nominal'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      onUpdateDevice(device.id, { power: !device.power })
                    }
                    className={`px-2.5 py-1 rounded-md text-[10px] font-bold border font-orbitron transition-all ${
                      device.power
                        ? 'bg-cyan-500 text-black border-cyan-300 shadow-[0_0_8px_#00f0ff]'
                        : 'bg-gray-950 text-gray-400 border-gray-800 hover:text-white'
                    }`}
                  >
                    {device.power ? 'ON' : 'OFF'}
                  </button>
                </div>

                {/* Specific Device Controls */}
                {device.power && (
                  <div className="space-y-2 text-xs border-t border-cyan-900/50 pt-2 font-mono-tech">
                    {/* Light Controls */}
                    {isLight && (
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[11px] text-cyan-300">
                          <span>Brightness:</span>
                          <span className="font-bold">{device.brightness}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={device.brightness || 80}
                          onChange={(e) =>
                            onUpdateDevice(device.id, {
                              brightness: parseInt(e.target.value),
                            })
                          }
                          className="w-full h-1.5 bg-black rounded-lg appearance-none cursor-pointer accent-[#00f0ff]"
                        />

                        {/* Quick Color Presets */}
                        <div className="flex items-center gap-1.5 pt-1">
                          <span className="text-[10px] text-cyan-500">Color:</span>
                          {['#00f0ff', '#aa00ff', '#ff9900', '#00ff00', '#ff0055'].map(
                            (c) => (
                              <button
                                key={c}
                                onClick={() =>
                                  onUpdateDevice(device.id, { color: c })
                                }
                                style={{ backgroundColor: c }}
                                className={`w-3.5 h-3.5 rounded-full border border-black/40 ${
                                  device.color === c
                                    ? 'ring-2 ring-cyan-300 scale-110'
                                    : ''
                                }`}
                              />
                            )
                          )}
                        </div>
                      </div>
                    )}

                    {/* Thermostat Controls */}
                    {isThermostat && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-cyan-200">
                          <span>Target Temp:</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() =>
                                onUpdateDevice(device.id, {
                                  targetTemperature: Math.max(
                                    16,
                                    (device.targetTemperature || 22) - 1
                                  ),
                                })
                              }
                              className="px-2 py-0.5 bg-cyan-950 border border-cyan-600 rounded text-cyan-200 font-bold"
                            >
                              -
                            </button>
                            <span className="text-sm font-bold font-orbitron text-[#00f0ff]">
                              {device.targetTemperature || 22}°C
                            </span>
                            <button
                              onClick={() =>
                                onUpdateDevice(device.id, {
                                  targetTemperature: Math.min(
                                    30,
                                    (device.targetTemperature || 22) + 1
                                  ),
                                })
                              }
                              className="px-2 py-0.5 bg-cyan-950 border border-cyan-600 rounded text-cyan-200 font-bold"
                            >
                              +
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center justify-between gap-1 pt-1">
                          {['cool', 'heat', 'auto', 'eco'].map((m) => (
                            <button
                              key={m}
                              onClick={() =>
                                onUpdateDevice(device.id, {
                                  mode: m as any,
                                })
                              }
                              className={`flex-1 py-1 rounded text-[10px] uppercase font-bold border transition-colors ${
                                device.mode === m
                                  ? 'bg-cyan-500/40 text-cyan-200 border-cyan-400'
                                  : 'bg-black/60 text-cyan-600 border-cyan-900'
                              }`}
                            >
                              {m}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Lock Controls */}
                    {isLock && (
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-cyan-300 text-[11px]">
                          State: {device.locked ? 'LOCKED' : 'UNLOCKED'}
                        </span>
                        <button
                          onClick={() =>
                            onUpdateDevice(device.id, {
                              locked: !device.locked,
                            })
                          }
                          className={`px-3 py-1 rounded text-xs font-bold font-orbitron flex items-center gap-1 border ${
                            device.locked
                              ? 'bg-emerald-950 text-emerald-300 border-emerald-500'
                              : 'bg-rose-950 text-rose-300 border-rose-500 animate-pulse'
                          }`}
                        >
                          {device.locked ? (
                            <>
                              <Lock className="w-3 h-3" />
                              <span>SECURED</span>
                            </>
                          ) : (
                            <>
                              <Unlock className="w-3 h-3" />
                              <span>UNLOCKED</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}

                    {/* Media / TV volume */}
                    {isMedia && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-cyan-300">
                          <span>Volume:</span>
                          <span className="font-bold">{device.volume}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={device.volume || 30}
                          onChange={(e) =>
                            onUpdateDevice(device.id, {
                              volume: parseInt(e.target.value),
                            })
                          }
                          className="w-full h-1.5 bg-black rounded-lg appearance-none cursor-pointer accent-[#00f0ff]"
                        />
                      </div>
                    )}

                    {/* Curtains */}
                    {isCurtain && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] text-cyan-300">
                          <span>Open State:</span>
                          <span className="font-bold">{device.position}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={device.position || 0}
                          onChange={(e) =>
                            onUpdateDevice(device.id, {
                              position: parseInt(e.target.value),
                            })
                          }
                          className="w-full h-1.5 bg-black rounded-lg appearance-none cursor-pointer accent-[#00f0ff]"
                        />
                      </div>
                    )}

                    {/* Fan */}
                    {isFan && (
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-cyan-300">Fan Speed:</span>
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((lvl) => (
                            <button
                              key={lvl}
                              onClick={() =>
                                onUpdateDevice(device.id, { speed: lvl })
                              }
                              className={`w-5 h-5 rounded text-[10px] font-bold border ${
                                device.speed === lvl
                                  ? 'bg-cyan-400 text-black border-cyan-200'
                                  : 'bg-black text-cyan-500 border-cyan-900'
                              }`}
                            >
                              {lvl}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="border-t border-cyan-900/50 pt-2.5 flex items-center justify-between text-[11px] text-cyan-500 font-mono-tech">
          <span>JARVIS Smart Grid v5.2 • Connected via Redmi Pad Pro 5G IoT Gateway</span>
          <span className="text-cyan-300 font-bold">Say "Hey Jarvis, [device name]" anytime</span>
        </div>
      </div>
    </div>
  );
};
