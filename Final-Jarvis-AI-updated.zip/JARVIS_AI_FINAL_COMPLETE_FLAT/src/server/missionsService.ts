import { chatWithClaude, isClaudeConfigured } from "./providers/claudeProvider";
import { chatWithGemini, isGeminiConfigured } from "./providers/geminiProvider";
import type { ChatMessage } from "./providers/claudeProvider";

export type MissionStatus = "queued" | "running" | "awaiting_approval" | "completed" | "failed" | "cancelled";

export interface Mission {
  id: string;
  title: string;
  description: string;
  agent: "CASE" | "TARS"; // named after the spec's own sub-agent names, kept generic beyond that
  status: MissionStatus;
  log: { time: number; message: string }[];
  result: string | null;
  requiresApproval: boolean; // true for anything the spec would call "consequential" — real calls/spend/etc.
  createdAt: number;
  updatedAt: number;
}

const missions = new Map<string, Mission>();
let nextId = 1;

const log = (mission: Mission, message: string) => {
  mission.log.push({ time: Date.now(), message });
  mission.updatedAt = Date.now();
};

/**
 * A mission is intentionally scoped to reasoning/research/drafting work — it can think,
 * summarize, and produce a result, but it does not itself place calls, spend money, or
 * take real-world consequential action. Those stay behind an explicit separate
 * confirmation endpoint (see approveMission) precisely so "spawn a background agent"
 * can never silently turn into "an agent did something irreversible without you."
 */
const CONSEQUENTIAL_KEYWORDS = /\b(call|dial|purchase|buy|pay|charge|send money|book|reserve|deploy campaign|publish|post publicly)\b/i;

export const createMission = (title: string, description: string, agent: "CASE" | "TARS" = "CASE"): Mission => {
  const requiresApproval = CONSEQUENTIAL_KEYWORDS.test(description);
  const mission: Mission = {
    id: `mission-${nextId++}`,
    title,
    description,
    agent,
    status: requiresApproval ? "awaiting_approval" : "queued",
    log: [],
    result: null,
    requiresApproval,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  missions.set(mission.id, mission);
  log(mission, requiresApproval ? "Flagged as consequential — awaiting human approval before running." : "Mission queued.");
  if (!requiresApproval) void runMission(mission.id);
  return mission;
};

export const approveMission = (id: string): Mission | null => {
  const mission = missions.get(id);
  if (!mission || mission.status !== "awaiting_approval") return mission || null;
  mission.status = "queued";
  log(mission, "Approved by user — running now.");
  void runMission(id);
  return mission;
};

export const cancelMission = (id: string): Mission | null => {
  const mission = missions.get(id);
  if (!mission) return null;
  if (mission.status === "queued" || mission.status === "awaiting_approval" || mission.status === "running") {
    mission.status = "cancelled";
    log(mission, "Cancelled by user.");
  }
  return mission;
};

const runMission = async (id: string) => {
  const mission = missions.get(id);
  if (!mission || mission.status !== "queued") return;
  mission.status = "running";
  log(mission, `${mission.agent} picked up the mission.`);

  const claudeUp = isClaudeConfigured();
  const geminiUp = isGeminiConfigured();
  if (!claudeUp && !geminiUp) {
    mission.status = "failed";
    log(mission, "EXTERNAL_CREDENTIAL_REQUIRED — no AI provider configured.");
    return;
  }

  const systemPrompt = `You are ${mission.agent}, a bounded background sub-agent working for JARVIS. Complete the mission described below and produce a clear, concise result. You have no ability to actually place calls, spend money, or take real-world action — if the mission requires that, say exactly what a human needs to approve or do manually instead of pretending to have done it.`;
  const messages: ChatMessage[] = [{ role: "user", text: mission.description }];

  try {
    const result = claudeUp
      ? await chatWithClaude(messages, systemPrompt)
      : await chatWithGemini(messages, systemPrompt);
    if (missions.get(id)?.status === "cancelled") return; // cancelled while running
    mission.result = result.text;
    mission.status = "completed";
    log(mission, `${mission.agent} completed the mission.`);
  } catch (err: any) {
    mission.status = "failed";
    log(mission, `Failed: ${err?.message || String(err)}`);
  }
};

export const listMissions = (): Mission[] => Array.from(missions.values()).sort((a, b) => b.createdAt - a.createdAt);
export const getMission = (id: string): Mission | null => missions.get(id) || null;
