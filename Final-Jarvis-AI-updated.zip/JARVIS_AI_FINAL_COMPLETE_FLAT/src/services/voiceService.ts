// JARVIS Autonomous Voice & Speech Service with Anti-Loop & Audio-Shield Protection

export class JarvisVoiceService {
  private recognition: any = null;
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private isProcessing: boolean = false;
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private onTranscriptCallback: ((text: string, isFinal: boolean) => void) | null = null;
  private onWakeWordCallback: (() => void) | null = null;
  private onStateChangeCallback: ((isListening: boolean, isSpeaking: boolean) => void) | null = null;
  private restartTimeout: any = null;
  private silenceTimeout: any = null;
  private lastSpokenText: string = '';
  private lastSpokenTimestamp: number = 0;
  private isManuallyActivated: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.synth = window.speechSynthesis || null;
      const SpeechRecognition =
        (window as any).SpeechRecognition ||
        (window as any).webkitSpeechRecognition ||
        null;

      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US'; // Supports international English & phonetic queries
        this.recognition.maxAlternatives = 1;

        this.recognition.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
            } else {
              interimTranscript += transcript;
            }
          }

          const activeText = (finalTranscript || interimTranscript).trim();
          if (!activeText || activeText.length < 2) return;

          const lower = activeText.toLowerCase();

          // IMMEDIATE BARGE-IN & STOP COMMAND DETECTION (highest priority)
          const isStopCommand =
            lower.includes('stop') ||
            lower.includes('shut up') ||
            lower.includes('be quiet') ||
            lower.includes('cancel') ||
            lower.includes('pause') ||
            lower.includes('ruk jao') ||
            lower.includes('chup') ||
            lower.includes('band karo') ||
            lower.includes('stop speaking') ||
            lower.includes('stop talking');

          if (isStopCommand && (this.isSpeaking || this.currentAudio)) {
            this.stopSpeaking();
            if (this.onTranscriptCallback) {
              this.onTranscriptCallback('Vocal synthesis stopped upon command.', true);
            }
            return;
          }

          // If JARVIS is currently speaking or processing, discard general query input to prevent feedback loops
          if (this.isSpeaking || this.isProcessing) {
            return;
          }

          // Check if active text matches what JARVIS just spoke (echo suppression)
          const now = Date.now();
          if (now - this.lastSpokenTimestamp < 4000 && this.lastSpokenText) {
            const lowerActive = activeText.toLowerCase();
            const lowerLast = this.lastSpokenText.toLowerCase();
            if (lowerLast.includes(lowerActive) || lowerActive.includes(lowerLast.slice(0, 20))) {
              return; // ignore echo
            }
          }

          // Discard single-word accidental non-speech fragments when in ambient mode
          const isWakeWord =
            lower.includes('hey jarvis') ||
            lower.includes('jarvis') ||
            lower.includes('suno jarvis') ||
            lower.includes('ok jarvis');

          // If wake word detected
          if (isWakeWord && this.onWakeWordCallback) {
            this.onWakeWordCallback();
          }

          if (this.onTranscriptCallback && activeText.length > 0) {
            this.onTranscriptCallback(activeText, !!finalTranscript);
          }

          // Auto-finalize if user pauses speaking for 1.4 seconds on interim transcript
          if (!finalTranscript && interimTranscript.length > 3) {
            if (this.silenceTimeout) clearTimeout(this.silenceTimeout);
            this.silenceTimeout = setTimeout(() => {
              if (this.onTranscriptCallback && !this.isSpeaking && !this.isProcessing) {
                this.onTranscriptCallback(interimTranscript.trim(), true);
              }
            }, 1400);
          }
        };

        this.recognition.onerror = (err: any) => {
          // Suppress common transient speech recognition errors to avoid noise
          if (err.error === 'no-speech' || err.error === 'aborted') {
            return;
          }

          if (err.error === 'not-allowed' || err.error === 'service-not-allowed') {
            console.warn('Speech recognition permission denied:', err.error);
            this.isListening = false;
            this.notifyState();
            return;
          }
        };

        this.recognition.onend = () => {
          // Restart gracefully only if listening is active and not speaking
          if (this.isListening && !this.isSpeaking && !this.isProcessing) {
            if (this.restartTimeout) clearTimeout(this.restartTimeout);
            this.restartTimeout = setTimeout(() => {
              if (this.isListening && !this.isSpeaking && !this.isProcessing) {
                try {
                  this.recognition.start();
                } catch (e) {
                  // Ignore start collision
                }
              }
            }, 800);
          } else {
            this.notifyState();
          }
        };
      }
    }
  }

  public setCallbacks(
    onTranscript: (text: string, isFinal: boolean) => void,
    onWakeWord: () => void,
    onStateChange: (isListening: boolean, isSpeaking: boolean) => void
  ) {
    this.onTranscriptCallback = onTranscript;
    this.onWakeWordCallback = onWakeWord;
    this.onStateChangeCallback = onStateChange;
  }

  public setProcessing(processing: boolean) {
    this.isProcessing = processing;
    if (processing && this.recognition) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
    }
  }

  private notifyState() {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(this.isListening, this.isSpeaking);
    }
  }

  public startListening() {
    if (this.recognition && !this.isListening) {
      if (this.restartTimeout) clearTimeout(this.restartTimeout);
      this.isListening = true;
      this.notifyState();
      try {
        this.recognition.start();
      } catch (e) {
        // start might already be queued
      }
    }
  }

  public stopListening() {
    if (this.restartTimeout) clearTimeout(this.restartTimeout);
    if (this.silenceTimeout) clearTimeout(this.silenceTimeout);
    if (this.recognition && this.isListening) {
      this.isListening = false;
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.notifyState();
    }
  }

  public toggleListening(): boolean {
    if (this.isListening) {
      this.stopListening();
      return false;
    } else {
      this.startListening();
      return true;
    }
  }

  private currentAudio: HTMLAudioElement | null = null;

  public stopSpeaking() {
    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch (e) {
        // ignore
      }
      this.currentAudio = null;
    }
    if (this.synth) {
      this.synth.cancel();
    }
    this.isSpeaking = false;
    this.notifyState();
  }

  public async speak(text: string, onEnd?: () => void) {
    this.stopSpeaking();
    if (!text) {
      if (onEnd) onEnd();
      return;
    }

    // Clean text of markdown symbols
    const cleanText = text
      .replace(/[*#_`>]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    this.lastSpokenText = cleanText;
    this.lastSpokenTimestamp = Date.now();

    // Keep recognition active to catch user stop interruptions ("stop", "Hey Jarvis stop")
    if (this.recognition && this.isListening) {
      try {
        this.recognition.start();
      } catch (e) {
        // already running
      }
    }

    const handleSpeechEnd = () => {
      this.isSpeaking = false;
      this.notifyState();
      if (onEnd) onEnd();

      // Resume listening safely after brief delay if user has mic active
      if (this.isListening && !this.isProcessing) {
        if (this.restartTimeout) clearTimeout(this.restartTimeout);
        this.restartTimeout = setTimeout(() => {
          if (this.isListening && !this.isSpeaking && !this.isProcessing) {
            try {
              this.recognition?.start();
            } catch (e) {
              // ignore
            }
          }
        }, 800);
      }
    };

    // 1. Try high-definition Gemini Orion Voice via server /api/tts endpoint
    try {
      const response = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: cleanText }),
        signal: AbortSignal.timeout(3500),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.audioBase64) {
          const audioSrc = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
          const audio = new Audio(audioSrc);
          this.currentAudio = audio;
          
          this.isSpeaking = true;
          this.notifyState();

          audio.onended = () => {
            this.currentAudio = null;
            handleSpeechEnd();
          };
          audio.onerror = () => {
            this.currentAudio = null;
            this.speakWithBrowserSynth(cleanText, handleSpeechEnd);
          };

          await audio.play();
          return;
        }
      }
    } catch (e) {
      // Fallback directly to browser speech synthesis
    }

    // 2. Client-side browser synthesis fallback
    this.speakWithBrowserSynth(cleanText, handleSpeechEnd);
  }

  private speakWithBrowserSynth(cleanText: string, handleSpeechEnd: () => void) {
    if (!this.synth) {
      handleSpeechEnd();
      return;
    }

    try {
      const utterance = new SpeechSynthesisUtterance(cleanText);
      this.currentUtterance = utterance;

      // Select deep authoritative AI voice (prefer British English or deep male neural voice)
      const voices = this.synth.getVoices();
      const preferredVoice =
        voices.find(
          (v) =>
            v.name.includes('Google UK English Male') ||
            v.name.includes('Daniel') ||
            v.name.includes('George') ||
            v.name.includes('Oliver') ||
            v.name.includes('Arthur') ||
            v.name.includes('Ryan') ||
            v.name.includes('Guy') ||
            (v.lang.startsWith('en-GB') && v.name.toLowerCase().includes('male'))
        ) ||
        voices.find((v) => v.lang.startsWith('en-GB')) ||
        voices.find(
          (v) =>
            v.name.includes('David') ||
            v.name.includes('James') ||
            (v.lang.startsWith('en-US') && v.name.toLowerCase().includes('male'))
        ) ||
        voices.find((v) => v.lang.startsWith('en-US')) ||
        voices[0];

      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.rate = 0.98;
      utterance.pitch = 0.88; // Deep resonant JARVIS timbre

      utterance.onstart = () => {
        this.isSpeaking = true;
        this.notifyState();
      };

      utterance.onend = handleSpeechEnd;
      utterance.onerror = (e) => {
        console.warn('TTS playback notice:', e);
        handleSpeechEnd();
      };

      this.synth.speak(utterance);
    } catch (err) {
      console.warn('Speech synthesis failed:', err);
      handleSpeechEnd();
    }
  }

  public isAvailable(): boolean {
    return !!this.recognition;
  }
}

export const jarvisVoice = new JarvisVoiceService();

