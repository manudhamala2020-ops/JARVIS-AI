import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Sparkles,
  Layers,
  Flame,
  Clock,
  Eye,
  Hand,
  Maximize2,
  Minimize2,
  ExternalLink,
  Youtube,
  Radio,
  Sliders,
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface YouTubeShortsModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoId?: string;
  onAnnounce?: (msg: string) => void;
}

// Preset popular / tech shorts in Stark database
const SHORT_FEED = [
  {
    id: '2NKpA6smfwg',
    title: 'Iron Man Advanced AI Arc Reactor Holographic Prototype',
    author: 'Jarvis AI Spark',
    subs: '44',
    views: '11.4K',
    tags: ['#IronMan', '#Jarvis', '#AI', '#Tech'],
  },
  {
    id: 'dQw4w9WgXcQ',
    title: 'Stark Industries Quantum Cyber Matrix',
    author: 'Stark Neural Labs',
    subs: '1.2M',
    views: '450K',
    tags: ['#StarkTech', '#CyberDefense', '#Quantum'],
  },
  {
    id: 'jNQXAC9IVRw',
    title: 'Advanced Reconnaissance Feed',
    author: 'Defense Intelligence',
    subs: '850K',
    views: '230K',
    tags: ['#Recon', '#AI', '#Analysis'],
  },
];

export const YouTubeShortsModal: React.FC<YouTubeShortsModalProps> = ({
  isOpen,
  onClose,
  videoId = '2NKpA6smfwg',
  onAnnounce,
}) => {
  const [currentVideoId, setCurrentVideoId] = useState<string>(videoId);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState<boolean>(true);
  const [autoScrollSeconds, setAutoScrollSeconds] = useState<number>(15);
  const [countdown, setCountdown] = useState<number>(15);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [customUrlInput, setCustomUrlInput] = useState<string>('');

  useEffect(() => {
    if (videoId) {
      setCurrentVideoId(videoId);
      setCountdown(autoScrollSeconds);
    }
  }, [videoId, autoScrollSeconds]);

  // Auto-scroll countdown timer
  useEffect(() => {
    if (!isOpen || !autoScrollEnabled) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Switch to next Short in playlist or loop
          const currentIndex = SHORT_FEED.findIndex((s) => s.id === currentVideoId);
          const nextIndex = (currentIndex + 1) % SHORT_FEED.length;
          setCurrentVideoId(SHORT_FEED[nextIndex].id);
          soundFx.playRepulsorCharge();
          if (onAnnounce) {
            onAnnounce(`Auto-scrolled to next Short: ${SHORT_FEED[nextIndex].title}`);
          }
          return autoScrollSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, autoScrollEnabled, autoScrollSeconds, currentVideoId, onAnnounce]);

  if (!isOpen) return null;

  const currentMeta = SHORT_FEED.find((s) => s.id === currentVideoId) || {
    id: currentVideoId,
    title: 'Live Holographic Media Stream',
    author: 'Jarvis Media Relay',
    subs: '44',
    views: '11.4K',
    tags: ['#YouTubeShorts', '#JarvisStream', '#Hologram'],
  };

  const handleCustomUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customUrlInput.trim()) return;

    // Extract video ID from youtube.com/shorts/..., youtu.be/..., or youtube.com/watch?v=...
    let extractedId = customUrlInput.trim();
    const shortsMatch = customUrlInput.match(/shorts\/([a-zA-Z0-9_-]+)/);
    const watchMatch = customUrlInput.match(/[?&]v=([a-zA-Z0-9_-]+)/);
    const youtuBeMatch = customUrlInput.match(/youtu\.be\/([a-zA-Z0-9_-]+)/);

    if (shortsMatch && shortsMatch[1]) {
      extractedId = shortsMatch[1];
    } else if (watchMatch && watchMatch[1]) {
      extractedId = watchMatch[1];
    } else if (youtuBeMatch && youtuBeMatch[1]) {
      extractedId = youtuBeMatch[1];
    }

    setCurrentVideoId(extractedId);
    setCountdown(autoScrollSeconds);
    setCustomUrlInput('');
    soundFx.playTargetLock();
    if (onAnnounce) {
      onAnnounce(`Streaming YouTube media feed: ${extractedId}`);
    }
  };

  const handleNext = () => {
    const currentIndex = SHORT_FEED.findIndex((s) => s.id === currentVideoId);
    const nextIndex = (currentIndex + 1) % SHORT_FEED.length;
    setCurrentVideoId(SHORT_FEED[nextIndex].id);
    setCountdown(autoScrollSeconds);
    soundFx.playClick(1000);
  };

  const handlePrev = () => {
    const currentIndex = SHORT_FEED.findIndex((s) => s.id === currentVideoId);
    const prevIndex = (currentIndex - 1 + SHORT_FEED.length) % SHORT_FEED.length;
    setCurrentVideoId(SHORT_FEED[prevIndex].id);
    setCountdown(autoScrollSeconds);
    soundFx.playClick(700);
  };

  return (
    <div
      id="youtube-shorts-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-lg animate-fadeIn"
      onClick={onClose}
    >
      <div
        className={`relative w-full ${
          isFullscreen ? 'max-w-5xl h-[94vh]' : 'max-w-3xl h-[88vh] max-h-[780px]'
        } bg-[#040814]/95 border border-rose-500/50 rounded-2xl shadow-[0_0_40px_rgba(244,63,94,0.35)] flex flex-col overflow-hidden transition-all duration-300`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header HUD */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-rose-500/30 bg-rose-950/40">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-rose-500/20 border border-rose-400/60 rounded-lg text-rose-400">
              <Youtube className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-orbitron font-bold text-rose-300 text-sm tracking-wider">
                  HOLOGRAPHIC YOUTUBE SHORTS FEED
                </span>
                <span className="px-2 py-0.5 bg-rose-500/30 text-rose-200 border border-rose-400/50 rounded-full text-[10px] font-mono-tech font-bold">
                  LIVE STREAM
                </span>
              </div>
              <span className="text-[11px] text-cyan-400 font-mono-tech">
                Optical Auto-Scroller & Universal Gesture Sync Active
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Auto-Scroll Toggle */}
            <button
              onClick={() => {
                setAutoScrollEnabled(!autoScrollEnabled);
                soundFx.playClick(900);
              }}
              className={`px-2.5 py-1 rounded-lg border text-xs font-mono-tech flex items-center gap-1.5 transition-all ${
                autoScrollEnabled
                  ? 'bg-rose-500/30 border-rose-400 text-rose-200 shadow-[0_0_10px_rgba(244,63,94,0.4)]'
                  : 'bg-black/40 border-cyan-800 text-cyan-400'
              }`}
              title="Toggle automatic scrolling for YouTube Shorts & Reels"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Auto-Scroll: {autoScrollEnabled ? `${countdown}s` : 'OFF'}</span>
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 bg-black/40 hover:bg-rose-950/60 text-rose-300 border border-rose-800/50 rounded-lg transition-colors"
              title="Toggle Fullscreen Viewport"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 hover:text-white border border-rose-600/50 rounded-lg transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-black/70">
          {/* Main Video Player Container (9:16 Aspect ratio iframe) */}
          <div className="flex-1 flex items-center justify-center p-3 relative bg-gradient-to-b from-black via-[#060a18] to-black">
            <div className="w-full max-w-[360px] h-full max-h-[580px] rounded-2xl overflow-hidden border-2 border-rose-500/60 shadow-[0_0_30px_rgba(244,63,94,0.4)] relative bg-black">
              <iframe
                key={currentVideoId}
                src={`https://www.youtube-nocookie.com/embed/${currentVideoId}?autoplay=1&rel=0&modestbranding=1&enablejsapi=1&loop=1&playlist=${currentVideoId}`}
                title={currentMeta.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />

              {/* Holographic Watermark Scanline Overlay */}
              <div className="absolute inset-0 pointer-events-none border border-rose-400/20 rounded-2xl bg-gradient-to-b from-rose-500/5 via-transparent to-rose-500/10" />
            </div>

            {/* Quick Navigation Floating Overlay Buttons */}
            <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
              <button
                onClick={handlePrev}
                className="p-2.5 bg-black/80 hover:bg-rose-950 border border-rose-500/60 rounded-full text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.5)] transition-all hover:scale-110"
                title="Previous Short (Gesture: Swipe Down)"
              >
                <SkipBack className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="p-2.5 bg-black/80 hover:bg-rose-950 border border-rose-500/60 rounded-full text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.5)] transition-all hover:scale-110"
                title="Next Short (Gesture: Swipe Up)"
              >
                <SkipForward className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setCountdown(autoScrollSeconds);
                  soundFx.playRepulsorCharge();
                }}
                className="p-2.5 bg-black/80 hover:bg-rose-950 border border-rose-500/60 rounded-full text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.5)] transition-all hover:scale-110"
                title="Replay from start"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Telemetry & Controls Sidebar */}
          <div className="w-full md:w-72 border-t md:border-t-0 md:border-l border-rose-500/30 p-3.5 flex flex-col gap-3 font-mono-tech text-xs bg-[#040918]/90 overflow-y-auto">
            {/* Active Short Metadata */}
            <div className="p-3 bg-rose-950/30 border border-rose-500/40 rounded-xl space-y-2">
              <span className="text-[10px] text-rose-400 font-bold uppercase tracking-wider block">
                Active Stream Info
              </span>
              <h4 className="font-orbitron font-bold text-rose-100 text-xs line-clamp-2">
                {currentMeta.title}
              </h4>
              <div className="flex items-center justify-between text-[11px] text-cyan-300 pt-1 border-t border-rose-900/50">
                <span>{currentMeta.author}</span>
                <span className="text-rose-400 font-bold">{currentMeta.subs} Subs</span>
              </div>
              <div className="flex flex-wrap gap-1 pt-1">
                {currentMeta.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-1.5 py-0.5 bg-rose-950/60 border border-rose-800 text-rose-300 rounded text-[9px]"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Custom URL or Video ID Input */}
            <form onSubmit={handleCustomUrlSubmit} className="space-y-1.5">
              <label className="text-[10px] text-cyan-300 uppercase tracking-wide">
                Load Custom YouTube URL / Shorts ID:
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={customUrlInput}
                  onChange={(e) => setCustomUrlInput(e.target.value)}
                  placeholder="Paste YouTube Shorts URL or ID..."
                  className="flex-1 h-8 bg-black/80 border border-rose-500/40 rounded-lg px-2.5 text-xs text-rose-100 placeholder-rose-700 focus:outline-none focus:border-rose-400"
                />
                <button
                  type="submit"
                  className="h-8 px-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold font-orbitron text-[11px] rounded-lg shadow-[0_0_8px_rgba(244,63,94,0.4)]"
                >
                  LOAD
                </button>
              </div>
            </form>

            {/* Auto-Scroll Duration Selector */}
            <div className="p-2.5 bg-black/50 border border-rose-500/30 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-[11px] text-rose-300">
                <span>Auto-Scroll Timer:</span>
                <span className="font-bold text-rose-400">{autoScrollSeconds}s</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {[10, 15, 25, 45].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => {
                      setAutoScrollSeconds(sec);
                      setCountdown(sec);
                      soundFx.playClick(800);
                    }}
                    className={`py-1 rounded border text-[10px] transition-colors ${
                      autoScrollSeconds === sec
                        ? 'bg-rose-500 text-black font-bold border-rose-400'
                        : 'bg-black/60 border-rose-900 text-rose-300 hover:bg-rose-950'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            </div>

            {/* Gesture Controls Reference */}
            <div className="p-2.5 bg-cyan-950/20 border border-cyan-500/30 rounded-xl space-y-1.5">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold text-[11px]">
                <Hand className="w-3.5 h-3.5 text-cyan-400" />
                <span>Optical Gesture Actions</span>
              </div>
              <ul className="text-[10px] text-cyan-200/90 space-y-1">
                <li className="flex items-center justify-between">
                  <span>Swipe Up / Index Point Up:</span>
                  <span className="text-rose-400 font-bold">Next Short</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Swipe Down / Index Point Down:</span>
                  <span className="text-rose-400 font-bold">Previous</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Open Palm ✋:</span>
                  <span className="text-amber-400 font-bold">Pause / Play</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Vocal Interruption:</span>
                  <span className="text-emerald-400 font-bold">"Hey Jarvis, stop"</span>
                </li>
              </ul>
            </div>

            {/* Direct YouTube Link */}
            <a
              href={`https://youtube.com/shorts/${currentVideoId}`}
              target="_blank"
              rel="noreferrer"
              className="mt-auto py-2 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/50 rounded-xl text-rose-200 text-center flex items-center justify-center gap-1.5 transition-all text-xs"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in YouTube App</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
