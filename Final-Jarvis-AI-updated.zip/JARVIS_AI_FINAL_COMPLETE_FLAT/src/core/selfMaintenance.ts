export type MaintenanceStage='detect'|'analyze'|'propose'|'test'|'verify'|'apply'|'monitor'|'rollback';
export interface MaintenancePlan{id:string;createdAt:string;target:string;stages:MaintenanceStage[];rollbackRequired:boolean;}
export function createMaintenancePlan(target:string):MaintenancePlan{return{id:`maint_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,createdAt:new Date().toISOString(),target,stages:['detect','analyze','propose','test','verify','apply','monitor','rollback'],rollbackRequired:true};}
