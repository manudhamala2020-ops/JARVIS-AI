import { GoogleGenAI } from "@google/genai";
import type { ChatMessage, ProviderChatResult } from "./claudeProvider";

const getGemini = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const isGeminiConfigured = (): boolean => Boolean(process.env.GEMINI_API_KEY);

const GEMINI_MODEL = process.env.JARVIS_REASONING_MODEL || "gemini-3.7-flash";

/** Keep in sync with what the multimodal routes actually implement — do not overclaim. */
export const geminiCapabilities = {
  text: true,
  reasoning: true,
  coding: true,
  vision: true,
  audioTranscription: true,
  imageGeneration: true,
  videoGeneration: true,
  search: true, // via existing /api/gemini/search grounding route
};

export const chatWithGemini = async (
  messages: ChatMessage[],
  systemInstruction?: string
): Promise<ProviderChatResult & { provider: "gemini" }> => {
  const client = getGemini();
  if (!client) {
    throw Object.assign(new Error("EXTERNAL_CREDENTIAL_REQUIRED: GEMINI_API_KEY is not set on the server."), {
      code: "EXTERNAL_CREDENTIAL_REQUIRED",
    });
  }

  const contents = messages.map((m) => ({
    role: m.role === "user" ? "user" : "model",
    parts: [{ text: m.text }],
  }));

  const response = await client.models.generateContent({
    model: GEMINI_MODEL,
    contents,
    config: {
      systemInstruction:
        systemInstruction ||
        "You are J.A.R.V.I.S., the advanced tactical autonomous assistant. Provide precise, witty, professional responses with expert technical depth.",
    },
  });

  return { text: response.text || "", modelUsed: GEMINI_MODEL, provider: "gemini" };
};
