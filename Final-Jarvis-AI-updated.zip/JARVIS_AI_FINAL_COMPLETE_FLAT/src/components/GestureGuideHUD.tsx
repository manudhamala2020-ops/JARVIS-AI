import React, { useState, useMemo, useEffect } from 'react';
import {
  X,
  Hand,
  Search,
  Zap,
  Play,
  Rotate3d,
  ZoomIn,
  ZoomOut,
  Lightbulb,
  ShieldAlert,
  BarChart3,
  Brain,
  Palette,
  Volume2,
  Filter,
  Sliders,
  Gauge,
} from 'lucide-react';
import { GESTURE_PROTOCOLS, GestureProtocol } from '../data/gestureProtocols';
import { handTrackingService } from '../services/handTrackingService';
import { soundFx } from '../services/soundFx';

interface GestureGuideHUDProps {
  isOpen: boolean;
  onClose: () => void;
  lastGesture: string;
  gestureConfidence: number;
  onExecuteGesture?: (protocol: GestureProtocol) => void;
}

export const GestureGuideHUD: React.FC<GestureGuideHUDProps> = ({
  isOpen,
  onClose,
  lastGesture,
  gestureConfidence,
  onExecuteGesture,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sensitivity, setSensitivity] = useState<number>(handTrackingService.getSensitivity());

  useEffect(() => {
    const unsub = handTrackingService.subscribeSensitivity((val) => {
      setSensitivity(val);
    });
    return () => unsub();
  }, []);

  const handleSensitivityChange = (newVal: number) => {
    setSensitivity(newVal);
    handTrackingService.setSensitivity(newVal);
    soundFx.playClick(800 + newVal * 8);
  };

  const categories = [
    { id: 'all', label: 'All Protocols', count: GESTURE_PROTOCOLS.length, icon: Filter },
    { id: 'twohands', label: 'Two Hands Sensor', count: 6, icon: Zap },
    { id: 'core3d', label: 'Core 3D', count: 20, icon: Rotate3d },
    { id: 'smarthome', label: 'Smart Grid', count: 20, icon: Lightbulb },
    { id: 'defense', label: 'Arc Defense', count: 15, icon: ShieldAlert },
    { id: 'telemetry', label: 'Telemetry', count: 15, icon: BarChart3 },
    { id: 'ai', label: 'Gemini AI', count: 15, icon: Brain },
    { id: 'themes', label: 'Themes', count: 10, icon: Palette },
    { id: 'hud', label: 'HUD & Media', count: 10, icon: Volume2 },
  ];

  const filteredGestures = useMemo(() => {
    return GESTURE_PROTOCOLS.filter((g) => {
      const matchCategory =
        selectedCategory === 'all' || g.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        g.name.toLowerCase().includes(q) ||
        g.action.toLowerCase().includes(q) ||
        g.poseDesc.toLowerCase().includes(q) ||
        g.categoryLabel.toLowerCase().includes(q);
      return matchCategory && matchSearch;
    });
  }, [selectedCategory, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md animate-fadeIn font-rajdhani">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#050b18]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_50px_rgba(0,240,255,0.25)] flex flex-col gap-3.5 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-950/80 border border-cyan-500/50 rounded-xl">
              <Hand className="w-6 h-6 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-xl font-bold font-orbitron text-cyan-300 tracking-wider">
                  100+ HOLOGRAPHIC GESTURE PROTOCOLS
                </h2>
                <span className="text-[10px] px-2 py-0.5 bg-cyan-950 border border-cyan-500/40 text-cyan-300 rounded font-mono-tech">
                  105 TOTAL
                </span>
              </div>
              <p className="text-xs text-cyan-400/70 font-mono-tech">
                MediaPipe 3D Kinematics • Zoom in (4.0) • Zoom out (3.9) • 1800 Particle Core Control
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-xl border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Detected Gesture Feedback */}
        <div className="p-2.5 bg-cyan-950/50 border border-cyan-500/40 rounded-xl flex items-center justify-between font-mono-tech text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-cyan-300">
              Live Sensor Feedback:{' '}
              <strong className="text-white font-bold font-orbitron">
                {lastGesture || 'Awaiting Hand Presence in Viewport...'}
              </strong>
            </span>
          </div>
          {lastGesture && (
            <span className="text-emerald-400 font-bold px-2 py-0.5 bg-emerald-950/60 border border-emerald-500/40 rounded">
              {(gestureConfidence * 100).toFixed(0)}% Kinetic Match
            </span>
          )}
        </div>

        {/* Dynamic Speed Threshold & Gesture Sensitivity Slider Control */}
        <div className="p-3 bg-[#030814]/90 border border-cyan-500/30 rounded-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 font-mono-tech">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-cyan-950/80 border border-cyan-500/40 rounded-lg text-cyan-300">
              <Sliders className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold font-orbitron text-cyan-200">
                  SPEED THRESHOLD & SENSITIVITY
                </span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                    sensitivity > 75
                      ? 'bg-amber-950 text-amber-300 border border-amber-500/50'
                      : sensitivity < 30
                      ? 'bg-indigo-950 text-indigo-300 border border-indigo-500/50'
                      : 'bg-cyan-950 text-cyan-300 border border-cyan-500/50'
                  }`}
                >
                  {sensitivity > 75 ? 'HYPER-RESPONSIVE' : sensitivity < 30 ? 'STRICT / ACCIDENTAL-PROOF' : 'BALANCED PRECISION'}
                </span>
              </div>
              <p className="text-[11px] text-cyan-400/60">
                Adjust deadzone & recognition velocity threshold ({sensitivity}%)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 min-w-[240px] sm:max-w-[320px] flex-1">
            <span className="text-[10px] text-gray-400 font-mono">Strict</span>
            <input
              type="range"
              min="0"
              max="100"
              value={sensitivity}
              onChange={(e) => handleSensitivityChange(Number(e.target.value))}
              className="flex-1 accent-cyan-400 cursor-pointer h-1.5 bg-cyan-950 rounded-lg appearance-none border border-cyan-800"
            />
            <span className="text-[10px] text-cyan-300 font-mono font-bold">{sensitivity}%</span>
            <span className="text-[10px] text-cyan-400 font-mono">Fast</span>
          </div>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-cyan-500" />
            <input
              type="text"
              placeholder="Search across 100+ gestures, actions, smart devices, or assistant capabilities..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/60 border border-cyan-900/80 focus:border-cyan-400 text-cyan-200 text-xs rounded-xl pl-9 pr-3 py-2 outline-none font-mono-tech transition-colors placeholder:text-cyan-600"
            />
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono-tech whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,240,255,0.4)]'
                    : 'bg-black/60 text-cyan-400/80 border border-cyan-900/50 hover:border-cyan-500/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
                <span
                  className={`text-[10px] px-1 py-0.2 rounded ${
                    isSelected ? 'bg-black/20 text-black' : 'bg-cyan-950 text-cyan-400'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Gestures Grid */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-2 max-h-[50vh] font-mono-tech text-xs">
          {filteredGestures.length === 0 ? (
            <div className="text-center py-10 text-cyan-500 font-mono-tech">
              No gesture protocol found matching "{searchQuery}".
            </div>
          ) : (
            filteredGestures.map((g) => (
              <div
                key={g.id}
                className="p-3 bg-black/60 border border-cyan-900/50 hover:border-cyan-500/60 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-all hover:bg-cyan-950/20 group"
              >
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 bg-cyan-950/80 border border-cyan-500/40 rounded-lg text-cyan-300 group-hover:scale-105 transition-transform">
                    <Zap className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="space-y-1 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-bold text-white font-orbitron tracking-wide">
                        {g.name}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 bg-cyan-950 border border-cyan-500/30 text-cyan-300 rounded uppercase">
                        {g.categoryLabel}
                      </span>
                    </div>
                    <p className="text-[11px] text-cyan-300 font-semibold">
                      Action: {g.action}
                    </p>
                    <p className="text-[10px] text-cyan-400/60 font-sans">
                      Pose: {g.poseDesc}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <span className="text-[10px] font-mono-tech text-cyan-500 hidden md:inline">
                    {g.id}
                  </span>
                  {onExecuteGesture && (
                    <button
                      onClick={() => onExecuteGesture(g)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-950/80 hover:bg-cyan-500 hover:text-black text-cyan-300 border border-cyan-500/50 rounded-lg transition-all text-xs font-bold shadow-[0_0_10px_rgba(0,240,255,0.15)]"
                      title={`Simulate / Trigger ${g.name}`}
                    >
                      <Play className="w-3 h-3" />
                      <span>Execute</span>
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-cyan-900/50 pt-2 text-[11px] text-cyan-500 font-mono-tech flex flex-wrap justify-between items-center gap-2">
          <span>Showing {filteredGestures.length} of {GESTURE_PROTOCOLS.length} Gesture Protocols</span>
          <span className="text-cyan-400">Pipeline: 240Hz MediaPipe Hands • Gemini Deep Voice Ready</span>
        </div>
      </div>
    </div>
  );
};
