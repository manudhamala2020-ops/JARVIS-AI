export type CapabilityRisk = 'low' | 'medium' | 'high' | 'critical';
export type CapabilityKind = 'intelligence' | 'voice' | 'vision' | 'gesture' | 'files' | 'web' | 'coding' | 'productivity' | 'device' | 'security' | 'science' | 'business' | 'automation';
export interface CapabilityDefinition { id:string; name:string; kind:CapabilityKind; risk:CapabilityRisk; requiresUserApproval:boolean; requiresNativeBridge?:boolean; description:string; }
const definitions: Array<[string,string,CapabilityKind,CapabilityRisk,boolean,boolean,string]> = [
['reasoning','Expert reasoning','intelligence','low',false,false,'Contextual reasoning, calculations and decision support.'],
['research','Research and investigation','intelligence','low',false,false,'Multi-source research with uncertainty and source tracking.'],
['voice','Continuous voice interaction','voice','medium',true,false,'Wake word, speech recognition, interruption and speech output.'],
['vision','Computer vision','vision','medium',true,false,'Camera-based scene, object and motion understanding.'],
['gesture','Low-latency gesture control','gesture','medium',true,false,'Responsive single- and multi-hand interaction.'],
['files','Authorized file management','files','high',true,true,'Create, organize, move, rename and edit user-authorized files.'],
['browser','Browser automation','web','high',true,false,'Authorized browser navigation and task execution.'],
['coding','Software engineering','coding','medium',false,false,'Code generation, analysis, testing and project maintenance.'],
['productivity','Documents and productivity','productivity','medium',true,false,'Documents, spreadsheets, presentations and email workflows.'],
['device','Device integration','device','critical',true,true,'Authorized native device actions and settings.'],
['security','Defensive cybersecurity','security','high',true,true,'Detection, hardening, isolation, malware analysis and authorized testing.'],
['science','Science and engineering','science','low',false,false,'Scientific, mathematical and engineering assistance.'],
['business','Business and finance analysis','business','medium',true,false,'Business, commerce and financial analysis.'],
['automation','Bounded autonomous tasks','automation','high',true,true,'Multi-step task execution with approval gates and rollback.'],
];
export const JARVIS_CAPABILITIES: CapabilityDefinition[] = definitions.map(([id,name,kind,risk,requiresUserApproval,requiresNativeBridge,description]) => ({id,name,kind,risk,requiresUserApproval,requiresNativeBridge,description}));
export function getCapability(id:string){ return JARVIS_CAPABILITIES.find(c=>c.id===id); }
