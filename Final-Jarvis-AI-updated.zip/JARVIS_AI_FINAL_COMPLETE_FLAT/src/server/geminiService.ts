import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

// Lazy-initialized Gemini Client
export const getGemini = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({ apiKey });
};
