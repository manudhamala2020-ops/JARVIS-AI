import React, { useState } from 'react';
import { X, Database, Search, Plus, Clock, Tag, Sparkles } from 'lucide-react';
import { MemoryItem } from '../types';

interface MemoryHUDProps {
  isOpen: boolean;
  onClose: () => void;
  memories: MemoryItem[];
  onAddMemory: (memory: Partial<MemoryItem>) => void;
}

export const MemoryHUD: React.FC<MemoryHUDProps> = ({
  isOpen,
  onClose,
  memories,
  onAddMemory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newDetails, setNewDetails] = useState('');
  const [newCategory, setNewCategory] =
    useState<MemoryItem['category']>('preference');
  const [isAdding, setIsAdding] = useState(false);

  if (!isOpen) return null;

  const filteredMemories = memories.filter(
    (m) =>
      m.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSaveMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSummary.trim()) return;
    onAddMemory({
      summary: newSummary.trim(),
      details: newDetails.trim(),
      category: newCategory,
      importance: 'high',
    });
    setNewSummary('');
    setNewDetails('');
    setIsAdding(false);
  };

  const getCategoryBadge = (cat: MemoryItem['category']) => {
    switch (cat) {
      case 'preference':
        return 'bg-amber-950 text-amber-300 border-amber-500/50';
      case 'automation':
        return 'bg-cyan-950 text-cyan-300 border-cyan-500/50';
      case 'security':
        return 'bg-rose-950 text-rose-300 border-rose-500/50';
      case 'fact':
        return 'bg-purple-950 text-purple-300 border-purple-500/50';
      default:
        return 'bg-emerald-950 text-emerald-300 border-emerald-500/50';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn font-rajdhani">
      <div className="relative w-full max-w-4xl max-h-[85vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Database className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
                JARVIS PERSISTENT MEMORY CORE
              </h2>
              <p className="text-xs text-cyan-500 font-mono-tech">
                Searchable Long-Term Memory • Semantic Neural Records • Real Time
                Index
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-lg border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Add Button */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search memories (e.g., '10 days ago', 'temperature', 'preference', 'lock')..."
              className="w-full h-10 bg-black/70 border border-cyan-500/40 rounded-xl pl-9 pr-3 text-xs text-cyan-100 placeholder-cyan-600 focus:outline-none focus:border-[#00f0ff] font-mono-tech"
            />
          </div>
          <button
            onClick={() => setIsAdding(!isAdding)}
            className="h-10 px-3.5 bg-cyan-500 text-black font-bold font-orbitron text-xs rounded-xl hover:bg-cyan-400 flex items-center gap-1.5 transition-all shadow-[0_0_10px_#00f0ff]"
          >
            <Plus className="w-4 h-4" />
            <span>{isAdding ? 'CANCEL' : 'SAVE MEMORY'}</span>
          </button>
        </div>

        {/* Add Memory Form */}
        {isAdding && (
          <form
            onSubmit={handleSaveMemory}
            className="p-3 bg-cyan-950/40 border border-cyan-500/40 rounded-xl space-y-2 font-mono-tech text-xs animate-fadeIn"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                value={newSummary}
                onChange={(e) => setNewSummary(e.target.value)}
                placeholder="Memory Summary / Title (e.g. AC Temperature Rule)"
                className="h-8 bg-black/80 border border-cyan-500/40 rounded-lg px-2.5 text-cyan-100 placeholder-cyan-600 text-xs focus:outline-none focus:border-cyan-400"
                required
              />
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="h-8 bg-black/80 border border-cyan-500/40 rounded-lg px-2 text-cyan-300 text-xs focus:outline-none focus:border-cyan-400"
              >
                <option value="preference">Preference</option>
                <option value="automation">Automation</option>
                <option value="security">Security</option>
                <option value="fact">Fact / Knowledge</option>
                <option value="conversation">Conversation</option>
              </select>
            </div>
            <textarea
              value={newDetails}
              onChange={(e) => setNewDetails(e.target.value)}
              placeholder="Full details of what JARVIS should remember indefinitely..."
              rows={2}
              className="w-full bg-black/80 border border-cyan-500/40 rounded-lg p-2 text-cyan-100 placeholder-cyan-600 text-xs focus:outline-none focus:border-cyan-400"
            />
            <button
              type="submit"
              className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold font-orbitron text-xs rounded-lg shadow-[0_0_8px_#00f0ff]"
            >
              COMMIT TO PERSISTENT MEMORY
            </button>
          </form>
        )}

        {/* Memory Items List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 font-mono-tech">
          {filteredMemories.length === 0 ? (
            <div className="text-center py-8 text-cyan-600 text-xs">
              No matching memory logs found in neural database.
            </div>
          ) : (
            filteredMemories.map((mem) => (
              <div
                key={mem.id}
                className="p-3 bg-black/60 border border-cyan-900/50 hover:border-cyan-500/50 rounded-xl space-y-1.5 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${getCategoryBadge(
                        mem.category
                      )}`}
                    >
                      {mem.category}
                    </span>
                    <h4 className="text-xs font-bold text-cyan-200 font-orbitron">
                      {mem.summary}
                    </h4>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-cyan-500">
                    <Clock className="w-3 h-3" />
                    <span>{mem.timestamp}</span>
                  </div>
                </div>
                <p className="text-xs text-cyan-300/80 leading-relaxed pl-1 border-l border-cyan-500/30">
                  {mem.details}
                </p>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-cyan-900/50 pt-2 text-[11px] text-cyan-500 font-mono-tech flex justify-between">
          <span>Total Records: {memories.length}</span>
          <span className="text-cyan-400 font-bold">
            Ask: "Jarvis, what did I ask you 10 days ago?"
          </span>
        </div>
      </div>
    </div>
  );
};
