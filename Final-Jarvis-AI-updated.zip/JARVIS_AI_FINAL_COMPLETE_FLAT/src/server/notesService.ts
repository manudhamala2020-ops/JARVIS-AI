import fs from "fs";
import path from "path";

export interface NoteNode {
  id: number;
  label: string;
  group: string;
  excerpt: string;
  /** relative path from the notes root — never sent further than this server needs it for */
  relPath: string;
}

export interface NoteLink {
  source: number;
  target: number;
}

export interface NotesGraph {
  nodes: NoteNode[];
  links: NoteLink[];
}

// Full note text is kept server-side only, indexed by node id, for the chat scorer —
// never sent to the client. The client gets id/label/group/excerpt via the graph endpoints.
const fullTextById = new Map<number, string>();

let cachedGraph: NotesGraph | null = null;
let cachedRoot: string | null = null;

const getNotesRoot = (): string => {
  const configured = process.env.JARVIS_NOTES_DIR;
  return configured ? path.resolve(configured) : path.resolve(process.cwd(), "notes");
};

const CAPTURES_SUBDIR = "captures";

const walkMarkdownFiles = (root: string): string[] => {
  const results: string[] = [];
  const walk = (dir: string) => {
    let entries: fs.Dirent[] = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
        walk(full);
      } else if (entry.isFile() && entry.name.toLowerCase().endsWith(".md")) {
        results.push(full);
      }
    }
  };
  walk(root);
  return results;
};

const titleFromFilename = (filePath: string): string => {
  return path.basename(filePath).replace(/\.md$/i, "");
};

const extractExcerpt = (content: string, maxLen = 700): string => {
  const stripped = content.replace(/^---[\s\S]*?---/, "").trim(); // drop frontmatter if present
  return stripped.length > maxLen ? stripped.slice(0, maxLen) + "…" : stripped;
};

const extractWikilinks = (content: string): string[] => {
  const matches = content.matchAll(/\[\[([^\]|]+)(?:\|[^\]]+)?\]\]/g);
  return Array.from(matches, (m) => m[1].trim());
};

/**
 * Scans every .md file under the configured notes root and builds a node/link graph.
 * Nodes: one per file, group = its immediate parent folder name (relative to root).
 * Links: A -> B when A's content mentions B's title (case-insensitive) or wikilinks it.
 * Node ids are the array index, matching the "id === array position" contract the
 * frontend graph viewer and fly-to-source feature depend on.
 */
export const buildNotesGraph = (forceRefresh = false): NotesGraph => {
  const root = getNotesRoot();
  if (!forceRefresh && cachedGraph && cachedRoot === root) return cachedGraph;

  fullTextById.clear();
  const files = walkMarkdownFiles(root);

  const nodes: NoteNode[] = files.map((filePath, id) => {
    const content = fs.readFileSync(filePath, "utf-8");
    fullTextById.set(id, content);
    const relPath = path.relative(root, filePath);
    const group = path.dirname(relPath) === "." ? "root" : path.dirname(relPath).split(path.sep)[0];
    return {
      id,
      label: titleFromFilename(filePath),
      group,
      excerpt: extractExcerpt(content),
      relPath,
    };
  });

  const titleToId = new Map(nodes.map((n) => [n.label.toLowerCase(), n.id]));
  const links: NoteLink[] = [];
  const seen = new Set<string>();

  for (const node of nodes) {
    const content = fullTextById.get(node.id) || "";
    const mentioned = new Set<number>();

    for (const wikilink of extractWikilinks(content)) {
      const targetId = titleToId.get(wikilink.toLowerCase());
      if (targetId !== undefined && targetId !== node.id) mentioned.add(targetId);
    }
    for (const other of nodes) {
      if (other.id === node.id) continue;
      if (content.toLowerCase().includes(other.label.toLowerCase())) mentioned.add(other.id);
    }

    for (const targetId of mentioned) {
      const key = [node.id, targetId].sort((a, b) => a - b).join("-");
      if (seen.has(key)) continue;
      seen.add(key);
      links.push({ source: node.id, target: targetId });
    }
  }

  cachedGraph = { nodes, links };
  cachedRoot = root;
  return cachedGraph;
};

export const getFullText = (nodeId: number): string | undefined => fullTextById.get(nodeId);

/** Simple keyword-overlap scorer — title matches weigh extra. No embeddings/vector DB, matches the spec's lightweight approach. */
export const scoreNotesForQuestion = (question: string, topN = 6): NoteNode[] => {
  const graph = buildNotesGraph();
  const qWords = question.toLowerCase().match(/[a-z0-9]+/g) || [];
  if (qWords.length === 0) return [];

  const scored = graph.nodes.map((node) => {
    const text = (fullTextById.get(node.id) || "").toLowerCase();
    const titleLower = node.label.toLowerCase();
    let score = 0;
    for (const word of qWords) {
      if (word.length < 3) continue;
      const bodyMatches = text.split(word).length - 1;
      score += bodyMatches;
      if (titleLower.includes(word)) score += 5; // title matches weigh extra
    }
    return { node, score };
  });

  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topN)
    .map((s) => s.node);
};

/**
 * Writes a new markdown note into <notesRoot>/captures/ and refreshes the in-memory graph.
 * Returns the new node plus the id of its most-related existing node (by simple title/word
 * overlap) so the client can animate it being "born" near that node, per the spec.
 */
export const rememberNote = (rawText: string): { node: NoteNode; nearestNodeId: number | null } => {
  const root = getNotesRoot();
  const capturesDir = path.join(root, CAPTURES_SUBDIR);
  fs.mkdirSync(capturesDir, { recursive: true });

  const words = rawText.trim().split(/\s+/).slice(0, 6).join(" ") || "note";
  const safeTitle = words.replace(/[^a-zA-Z0-9 _-]/g, "").trim().slice(0, 60) || `note-${Date.now()}`;
  const filename = `${safeTitle.replace(/\s+/g, "-").toLowerCase()}-${Date.now()}.md`;
  const filePath = path.join(capturesDir, filename);

  const content = `# ${safeTitle}\n\n${rawText.trim()}\n`;
  fs.writeFileSync(filePath, content, "utf-8");

  const graph = buildNotesGraph(true); // refresh — this also re-reads the file we just wrote
  const newNode = graph.nodes.find((n) => n.relPath === path.relative(root, filePath));
  if (!newNode) throw new Error("Failed to index the newly written note.");

  // Nearest existing node by simple shared-word overlap with the excerpt.
  const newWords = new Set((newNode.excerpt.toLowerCase().match(/[a-z0-9]+/g) || []).filter((w) => w.length >= 4));
  let bestId: number | null = null;
  let bestScore = 0;
  for (const other of graph.nodes) {
    if (other.id === newNode.id) continue;
    const otherWords = other.excerpt.toLowerCase().match(/[a-z0-9]+/g) || [];
    let overlap = 0;
    for (const w of otherWords) if (newWords.has(w)) overlap++;
    if (overlap > bestScore) {
      bestScore = overlap;
      bestId = other.id;
    }
  }

  return { node: newNode, nearestNodeId: bestId };
};
