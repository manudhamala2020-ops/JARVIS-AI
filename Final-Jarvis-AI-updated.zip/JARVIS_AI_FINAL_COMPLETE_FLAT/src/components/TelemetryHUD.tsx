import React from 'react';
import {
  X,
  Battery,
  Wifi,
  HardDrive,
  Cpu,
  MapPin,
  CloudSun,
  Activity,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { DeviceTelemetry } from '../types';

interface TelemetryHUDProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: DeviceTelemetry;
}

export const TelemetryHUD: React.FC<TelemetryHUDProps> = ({
  isOpen,
  onClose,
  telemetry,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[85vh] bg-[#060d1d]/95 border border-[#00f0ff]/50 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(0,240,255,0.25)] flex flex-col gap-4 overflow-y-auto font-rajdhani">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cyan-500/30 pb-3">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-bold font-orbitron text-cyan-300 tracking-wider">
                REDMI PAD PRO 5G TELEMETRY & DIAGNOSTICS
              </h2>
              <p className="text-xs text-cyan-500 font-mono-tech">
                Platform: {telemetry.device.model} • {telemetry.device.os} •{' '}
                {telemetry.device.platform}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-cyan-400 hover:text-white hover:bg-cyan-950/80 rounded-lg border border-cyan-500/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* System Telemetry */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs font-mono-tech">
          {/* Battery Status */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <Battery className="w-4 h-4 text-emerald-400" />
                <span>BATTERY SUBSYSTEM</span>
              </span>
              <span className="text-emerald-400 font-bold">
                {telemetry.battery.level}%
              </span>
            </div>
            <div className="w-full bg-cyan-950 h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-400 h-full rounded-full transition-all"
                style={{ width: `${telemetry.battery.level}%` }}
              />
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-0.5 pt-1">
              <div>Health: {telemetry.battery.health}</div>
              <div>Thermal Core: {telemetry.battery.temperatureC}°C</div>
              <div>Status: {telemetry.battery.charging ? 'SuperFast 33W Fast Charging' : 'On Internal Battery'}</div>
            </div>
          </div>

          {/* Network & 5G */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <Wifi className="w-4 h-4 text-cyan-400" />
                <span>CONNECTIVITY</span>
              </span>
              <span className="text-cyan-300 font-bold">{telemetry.network.pingMs} ms</span>
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-1 pt-1">
              <div>Network SSID: <span className="text-white font-bold">{telemetry.network.ssid}</span></div>
              <div>Type: {telemetry.network.type}</div>
              <div>IP Address: {telemetry.network.ip}</div>
              <div>Link Bandwidth: {telemetry.network.speedMbps} Mbps</div>
            </div>
          </div>

          {/* Storage & Memory */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <HardDrive className="w-4 h-4 text-purple-400" />
                <span>STORAGE & RAM</span>
              </span>
              <span className="text-purple-300 font-bold">
                {telemetry.storage.usedGb} / {telemetry.storage.totalGb} GB
              </span>
            </div>
            <div className="w-full bg-cyan-950 h-2 rounded-full overflow-hidden">
              <div
                className="bg-purple-400 h-full rounded-full transition-all"
                style={{
                  width: `${(telemetry.storage.usedGb / telemetry.storage.totalGb) * 100}%`,
                }}
              />
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-0.5 pt-1">
              <div>RAM Load: {telemetry.device.ramUsagePercent}% (LPDDR4X)</div>
              <div>CPU Load: {telemetry.device.cpuUsage}% (Octa-Core 2.4GHz)</div>
              <div>Uptime: {telemetry.device.uptime}</div>
            </div>
          </div>

          {/* Location & Dynamic GPS */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <MapPin className="w-4 h-4 text-rose-400" />
                <span>GEOLOCATION</span>
              </span>
              <span className="text-rose-300 font-bold">{telemetry.location.city}</span>
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-1 pt-1">
              <div>Coordinates: {telemetry.location.lat}°N, {telemetry.location.lon}°E</div>
              <div>Country: {telemetry.location.country}</div>
              <div>Timezone: {telemetry.location.timezone}</div>
              <div>GPS Fix: High Precision Dual-Band GNSS</div>
            </div>
          </div>

          {/* Weather & Atmospheric Telemetry */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <CloudSun className="w-4 h-4 text-amber-400" />
                <span>ATMOSPHERICS</span>
              </span>
              <span className="text-amber-300 font-bold">{telemetry.weather.tempC}°C</span>
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-1 pt-1">
              <div>Condition: {telemetry.weather.condition}</div>
              <div>Humidity: {telemetry.weather.humidity}% • UV Index: {telemetry.weather.uvIndex}</div>
              <div>Wind: {telemetry.weather.windKmph} km/h</div>
              <div>Air Quality: {telemetry.weather.airQuality}</div>
            </div>
          </div>

          {/* Ambient Room Sensors */}
          <div className="p-3.5 bg-black/60 border border-cyan-500/30 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-cyan-300">
              <span className="flex items-center gap-1.5 font-bold font-orbitron">
                <Zap className="w-4 h-4 text-cyan-300" />
                <span>ROOM SENSORS</span>
              </span>
              <span className="text-cyan-300 font-bold">Live Feed</span>
            </div>
            <div className="text-[11px] text-cyan-400/80 space-y-1 pt-1">
              <div>Ambient Illumination: {telemetry.sensors.ambientLightLux} Lux</div>
              <div>Acoustic Level: {telemetry.sensors.noiseLevelDb} dB</div>
              <div>Motion Sensor: {telemetry.sensors.motionDetected ? 'Movement Active' : 'Calm'}</div>
              <div>Room Ambient Temp: {telemetry.sensors.roomTemperatureC}°C</div>
            </div>
          </div>
        </div>

        {/* Security / System Integrity Banner */}
        <div className="p-3 bg-cyan-950/40 border border-cyan-500/40 rounded-xl flex items-center justify-between text-xs font-mono-tech">
          <div className="flex items-center gap-2 text-cyan-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>JARVIS Autonomous Defense Matrix: All 11 Nodes Encrypted & Verified</span>
          </div>
          <span className="text-emerald-400 font-bold">100% OPERATIONAL</span>
        </div>
      </div>
    </div>
  );
};
