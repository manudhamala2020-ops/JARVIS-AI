export type JarvisState =
  | 'IDLE'
  | 'WAKE_DETECTED'
  | 'LISTENING'
  | 'PROCESSING'
  | 'THINKING'
  | 'SEARCHING'
  | 'EXECUTING'
  | 'SPEAKING'
  | 'VISION_ACTIVE'
  | 'GESTURE_ACTIVE'
  | 'WARNING'
  | 'ERROR'
  | 'OFFLINE';

export type DeviceType =
  | 'light'
  | 'thermostat'
  | 'lock'
  | 'media'
  | 'vacuum'
  | 'plug'
  | 'curtain'
  | 'fan'
  | 'camera'
  | 'security';

export interface SmartDevice {
  id: string;
  name: string;
  type: DeviceType;
  room: string;
  status: 'online' | 'offline';
  power: boolean;
  brightness?: number; // 0 - 100
  color?: string; // hex
  temperature?: number; // deg C
  targetTemperature?: number;
  mode?: 'cool' | 'heat' | 'auto' | 'fan' | 'eco';
  locked?: boolean;
  battery?: number; // 0 - 100
  volume?: number; // 0 - 100
  speed?: number; // 1 - 5
  position?: number; // 0 - 100% open
  recording?: boolean;
  powerWatts?: number;
  lastUpdated: string;
}

export interface SmartScene {
  id: string;
  name: string;
  icon: string;
  description: string;
  color: string;
  active: boolean;
  deviceUpdates: Record<string, Partial<SmartDevice>>;
}

export interface DeviceTelemetry {
  battery: {
    level: number;
    charging: boolean;
    health: string;
    temperatureC: number;
  };
  storage: {
    usedGb: number;
    totalGb: number;
  };
  network: {
    ssid: string;
    ip: string;
    pingMs: number;
    speedMbps: number;
    type: string;
    connected: boolean;
  };
  device: {
    model: string;
    os: string;
    platform: string;
    uptime: string;
    cpuUsage: number;
    ramUsagePercent: number;
  };
  location: {
    city: string;
    country: string;
    lat: number;
    lon: number;
    timezone: string;
  };
  weather: {
    tempC: number;
    condition: string;
    humidity: number;
    windKmph: number;
    uvIndex: number;
    airQuality: string;
  };
  sensors: {
    ambientLightLux: number;
    noiseLevelDb: number;
    motionDetected: boolean;
    roomTemperatureC: number;
  };
}

export interface MemoryItem {
  id: string;
  category: 'conversation' | 'preference' | 'fact' | 'automation' | 'security';
  summary: string;
  details: string;
  timestamp: string;
  importance: 'high' | 'medium' | 'low';
}

export interface VisionDetection {
  objects: Array<{
    label: string;
    confidence: number;
  }>;
  faceDetected: boolean;
  faceLabel?: string;
  gestureDetected?: string;
  sceneDescription: string;
  opticalSummary?: string;
  confidence?: number;
}

export interface ResearchReport {
  id: string;
  query: string;
  timestamp: string;
  summary: string;
  sources: Array<{ title: string; uri: string }>;
  keyPoints: string[];
  category?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
  intent?: string;
  toolExecuted?: string;
  data?: any;
}

export interface HandGestureState {
  currentGesture: string;
  confidence: number;
  isIndexClosed: boolean;
  isMiddleClosed: boolean;
  zoomLevel: number;
  lastGestureTimestamp: number;
}
