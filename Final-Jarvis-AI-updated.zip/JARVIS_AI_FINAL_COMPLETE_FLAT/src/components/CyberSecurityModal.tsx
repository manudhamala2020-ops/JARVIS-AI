import React, { useState } from 'react';
import {
  X,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Unlock,
  Terminal,
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Zap,
  RefreshCw,
  Eye,
  Server,
  Layers,
  Radio,
  Sparkles,
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface CyberSecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CyberThreat {
  id: string;
  name: string;
  origin: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Neutralized' | 'Deflected' | 'Sandboxed';
  mitigation: string;
  timestamp: string;
}

export const CyberSecurityModal: React.FC<CyberSecurityModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'taxonomy' | 'defense' | 'live-logs'>('defense');
  const [activeShieldLevel, setActiveShieldLevel] = useState<'Standard' | 'Military' | 'Quantum-Lock'>(
    'Military'
  );
  const [counterAttackEnabled, setCounterAttackEnabled] = useState<boolean>(true);
  const [simulatingAttack, setSimulatingAttack] = useState<boolean>(true);
  const [simulatedLogs, setSimulatedLogs] = useState<string[]>([
    '[INIT] Quantum-Defensive IPS Kernel v6.8 Loaded.',
    '[MONITOR] 0.0.0.0/0 Ingress Packet Filtering active with Deep Packet Inspection (DPI).',
    '[SANDBOX] Zero-Trust Enclave verified: Device Storage Encrypted (AES-256-GCM).',
    '[OK] All 28 local microservice ports protected against buffer overflows.',
  ]);

  const [threatHistory, setThreatHistory] = useState<CyberThreat[]>([
    {
      id: 't-1',
      name: 'SQL/NoSQL Ingestion Injection Attempt',
      origin: '194.26.29.114 (Botnet Probe)',
      severity: 'High',
      status: 'Neutralized',
      mitigation: 'Parameterized Query Sanitizer & IP Drop',
      timestamp: '2 mins ago',
    },
    {
      id: 't-2',
      name: 'Cryptojacking Memory Scraping Payload',
      origin: 'Malicious Web Worker (Reflected XSS)',
      severity: 'Critical',
      status: 'Sandboxed',
      mitigation: 'Active Heuristic Sandbox & Process Eviction',
      timestamp: '14 mins ago',
    },
    {
      id: 't-3',
      name: 'Distributed SYN Flood Burst (45k req/s)',
      origin: 'Mirai IoT Cluster',
      severity: 'High',
      status: 'Deflected',
      mitigation: 'Adaptive SYN Cookies & BGP Rate Limiter',
      timestamp: '1 hour ago',
    },
  ]);

  const handleSimulateAttack = () => {
    soundFx.playAlert();
    setSimulatingAttack(true);

    setSimulatedLogs((prev) => [
      ...prev,
      `[ALERT ${new Date().toLocaleTimeString()}] High-velocity exploit detected: CVE-2026-X Zero-Day payload ingress!`,
      `[ANALYZING] Heuristic analyzer dissects shellcode signature...`,
    ]);

    setTimeout(() => {
      setSimulatedLogs((prev) => [
        ...prev,
        `[COUNTER-ACTION] White Hat Defensive Counter-Shield engaged: Sandboxing origin socket.`,
        `[NEUTRALIZED] Payload isolated inside virtual decoy trap without executing on device.`,
        `[SUCCESS] 0 device compromise. Local database and memory integrity 100% intact.`,
      ]);
      setThreatHistory((prev) => [
        {
          id: `t-${Date.now()}`,
          name: 'CVE-2026 Zero-Day Memory Injector',
          origin: 'Simulated Threat Vector',
          severity: 'Critical',
          status: 'Neutralized',
          mitigation: 'White Hat Counter-Isolation Shield',
          timestamp: 'Just now',
        },
        ...prev,
      ]);
      setSimulatingAttack(false);
      soundFx.playNotification();
    }, 1500);
  };

  if (!isOpen) return null;

  return (
    <div
      id="cyber-security-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-lg animate-in fade-in duration-200 font-sans"
    >
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#050c18] border border-cyan-500/50 rounded-2xl shadow-[0_0_40px_rgba(0,240,255,0.2)] flex flex-col overflow-hidden text-slate-200">
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-black to-cyan-950/40">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-600/20 border border-cyan-500/50 rounded-lg">
              <ShieldCheck className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[#00f0ff] font-orbitron font-black text-sm tracking-widest uppercase">
                  CYBER INTELLIGENCE & ACTIVE DEFENSE
                </span>
                <span className="px-2 py-0.5 bg-cyan-950 border border-cyan-700/60 rounded text-[10px] font-mono text-cyan-300">
                  WHITE HAT FORTRESS
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Ethical Security Taxonomy, Zero-Trust Hardening & Real-Time Threat Counter-Shield
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFx.playTap();
              onClose();
            }}
            className="p-1.5 bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-600/50 rounded-md text-cyan-300 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-950 border-b border-slate-800 text-xs font-semibold overflow-x-auto">
          {[
            { key: 'defense', label: '1. MILITARY ACTIVE SHIELD', icon: Shield },
            { key: 'taxonomy', label: '2. CYBER TAXONOMY (WHITE/GREY/BLACK)', icon: Layers },
            { key: 'live-logs', label: '3. IPS LOGS & THREAT HISTORY', icon: Terminal },
          ].map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => {
                  soundFx.playTap();
                  setActiveTab(tab.key as any);
                }}
                className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.3)]'
                    : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 text-cyan-400" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-5">
          {/* TAB 1: ACTIVE DEFENSE SHIELD */}
          {activeTab === 'defense' && (
            <div className="flex flex-col gap-5">
              <div className="p-4 bg-gradient-to-r from-cyan-950/30 via-slate-900/40 to-slate-950 border border-cyan-800/40 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-500/60 flex items-center justify-center text-cyan-400">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                      ACTIVE DEFENSE STATUS
                    </div>
                    <div className="text-lg font-orbitron font-bold text-white">
                      DEVICE & DATABASE 100% PROTECTED
                    </div>
                    <div className="text-xs text-slate-400">
                      Heuristic Zero-Day Engine • Real-time Automated Counter-Isolation active
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSimulateAttack}
                  disabled={simulatingAttack}
                  className="px-4 py-2 bg-red-600/30 hover:bg-red-600/50 text-red-300 border border-red-500 rounded-lg text-xs font-mono font-bold flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(255,0,0,0.3)]"
                >
                  <AlertTriangle className="w-4 h-4 text-red-400 animate-pulse" />
                  {simulatingAttack ? 'NEUTRALIZING SIMULATED ATTACK...' : 'TEST ACTIVE COUNTER-DEFENSE'}
                </button>
              </div>

              {/* Shield Tiers */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  {
                    tier: 'Standard',
                    desc: 'Stateful firewall & basic TLS encryption.',
                    badge: 'Baseline',
                  },
                  {
                    tier: 'Military',
                    desc: 'Deep packet inspection, heuristic sandbox & zero-trust token rotation.',
                    badge: 'Recommended',
                  },
                  {
                    tier: 'Quantum-Lock',
                    desc: 'Post-Quantum Lattice Cryptography (Kyber-1024) + automated counter-neutralization.',
                    badge: 'Ultimate',
                  },
                ].map((s) => (
                  <div
                    key={s.tier}
                    onClick={() => {
                      soundFx.playTap();
                      setActiveShieldLevel(s.tier as any);
                    }}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                      activeShieldLevel === s.tier
                        ? 'bg-cyan-950/60 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.25)] text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold font-orbitron">{s.tier} Defense</span>
                      <span className="px-2 py-0.5 bg-black/60 border border-slate-700 text-[10px] font-mono rounded text-cyan-300">
                        {s.badge}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed text-slate-300">{s.desc}</p>
                  </div>
                ))}
              </div>

              {/* Active Counter-Defense Protocol */}
              <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-mono text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Automated White Hat Counter-Neutralization Engine
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono text-emerald-400">
                      {counterAttackEnabled ? 'AUTOMATED ENGAGE' : 'STANDBY'}
                    </span>
                    <button
                      onClick={() => {
                        soundFx.playTap();
                        setCounterAttackEnabled(!counterAttackEnabled);
                      }}
                      className={`w-10 h-5 rounded-full transition-all relative ${
                        counterAttackEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                      }`}
                    >
                      <div
                        className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.75 transition-all ${
                          counterAttackEnabled ? 'right-1' : 'left-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  When a malicious actor launches a severe zero-day exploit, ransomware attempt, or distributed botnet flooding against the user’s device, this subsystem automatically isolates their ingress connection, engages an isolated decoy sandbox, and returns an equal defensive neutralization packet that terminates the hostile connection at the gateway without inflicting external damage.
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: CYBER TAXONOMY (WHITE / GREY / BLACK HAT) */}
          {activeTab === 'taxonomy' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* White Hat */}
              <div className="p-4 bg-emerald-950/20 border border-emerald-500/40 rounded-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                    <h3 className="text-sm font-orbitron font-bold text-white">WHITE HAT (DEFENSIVE)</h3>
                  </div>
                  <div className="text-[11px] font-mono text-emerald-400 mb-3">
                    Ethical, Authorized, Protective
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    Ethical security practitioners who perform vulnerability assessments, penetration tests, and patch development with explicit consent to defend systems against bad actors.
                  </p>
                  <ul className="text-xs text-slate-400 space-y-1.5">
                    <li>• Cryptographic Hardening (AES/RSA)</li>
                    <li>• Penetration Testing & Red Teaming</li>
                    <li>• Bug Bounty & Patch Deployment</li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-emerald-900/50 text-[11px] font-mono text-emerald-300 font-bold">
                  Status: 100% Active in JARVIS
                </div>
              </div>

              {/* Grey Hat */}
              <div className="p-4 bg-amber-950/20 border border-amber-500/40 rounded-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
                    <h3 className="text-sm font-orbitron font-bold text-white">GREY HAT (DUAL-USE)</h3>
                  </div>
                  <div className="text-[11px] font-mono text-amber-400 mb-3">
                    Unsolicited Research, Responsible Disclosure
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    Independent researchers who discover flaws without prior authorization, but without malicious intent to steal data, typically disclosing vulnerabilities to the vendor for a fee or credit.
                  </p>
                  <ul className="text-xs text-slate-400 space-y-1.5">
                    <li>• Unsolicited System Auditing</li>
                    <li>• Dual-Use Exploit Proof-of-Concepts</li>
                    <li>• Coordinated Vulnerability Disclosure</li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-amber-900/50 text-[11px] font-mono text-amber-300">
                  Status: Monitored Intelligence Feed
                </div>
              </div>

              {/* Black Hat */}
              <div className="p-4 bg-rose-950/20 border border-rose-500/40 rounded-xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500 shadow-[0_0_8px_#f43f5e]" />
                    <h3 className="text-sm font-orbitron font-bold text-white">BLACK HAT (MALICIOUS)</h3>
                  </div>
                  <div className="text-[11px] font-mono text-rose-400 mb-3">
                    Unauthorized, Destructive, Illegal
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    Malicious cyber adversaries who violate computer security for personal gain, extortion, data theft, ransomware deployment, or state-sponsored disruption.
                  </p>
                  <ul className="text-xs text-slate-400 space-y-1.5">
                    <li>• Ransomware & Data Extortion</li>
                    <li>• Zero-Day Exploit Weaponization</li>
                    <li>• Distributed Denial of Service (DDoS)</li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-rose-900/50 text-[11px] font-mono text-rose-300 font-bold">
                  Status: Neutralized by Counter-Shield
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LIVE LOGS & THREAT HISTORY */}
          {activeTab === 'live-logs' && (
            <div className="flex flex-col gap-4">
              <div className="p-3.5 bg-black border border-slate-800 rounded-xl font-mono text-xs text-cyan-300 max-h-48 overflow-y-auto space-y-1">
                {simulatedLogs.map((log, i) => (
                  <div key={i} className="leading-relaxed">
                    {log}
                  </div>
                ))}
              </div>

              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mt-2">
                RECENT DEFENSIVE INTERCEPTIONS
              </h4>
              <div className="space-y-2">
                {threatHistory.map((t) => (
                  <div
                    key={t.id}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        {t.name}
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                            t.severity === 'Critical'
                              ? 'bg-rose-950 text-rose-300 border border-rose-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {t.severity}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Origin: {t.origin} • Mitigation: {t.mitigation}
                      </div>
                    </div>
                    <div className="text-right font-mono">
                      <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-300 rounded text-[10px]">
                        {t.status}
                      </span>
                      <div className="text-[10px] text-slate-500 mt-1">{t.timestamp}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-black/60 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>STARK CYBERNETIC DEFENSE MATRIX v6.8</span>
          <span className="text-emerald-400 font-bold">FIREWALL: UNCOMPROMISED</span>
        </div>
      </div>
    </div>
  );
};
