import { Request, Response } from "express";
import { buildNotesGraph, scoreNotesForQuestion, rememberNote } from "./notesService";
import { chatWithClaude, isClaudeConfigured } from "./providers/claudeProvider";
import { chatWithGemini, isGeminiConfigured } from "./providers/geminiProvider";
import type { ChatMessage } from "./providers/claudeProvider";

// Per-session (in-memory, server-restart-clears) conversation history for notes chat follow-ups.
const sessionHistory = new Map<string, ChatMessage[]>();
const MAX_HISTORY_TURNS = 12;

/** GET /api/notes/graph — nodes/links for the 3D knowledge galaxy viewer. */
export const handleNotesGraph = (_req: Request, res: Response) => {
  try {
    const graph = buildNotesGraph();
    res.json({
      nodes: graph.nodes.map(({ id, label, group, excerpt }) => ({ id, label, group, excerpt })),
      links: graph.links,
      count: graph.nodes.length,
    });
  } catch (err: any) {
    res.status(500).json({ error: "NOTES_SCAN_FAILED", detail: err?.message || String(err) });
  }
};

const JARVIS_NOTES_SYSTEM_PROMPT = (excerpts: string) => `You are JARVIS, a dry, impeccably polite British-butler-toned assistant with a razor wit. Address the user as "sir" occasionally — not every sentence.

Answer the user's question using ONLY the note excerpts below. If the notes don't cover it, say so plainly instead of guessing. Keep the factual answer to 2-3 sentences — never recite a note back in full, since it is already shown on screen. One genuinely witty line beats three bland ones. Do not drag the conversation toward the notes unless the question is actually about them — handle small talk naturally.

NOTE EXCERPTS:
${excerpts}`;

/**
 * POST /api/notes/chat
 * body: { question: string, sessionId?: string }
 * Scores notes by keyword overlap, feeds the top matches to whichever AI provider is
 * configured (Claude preferred, Gemini fallback — same honest-fallback pattern as the
 * main orchestrator), and returns which note ids were actually used so the client can
 * fly the camera to them.
 */
export const handleNotesChat = async (req: Request, res: Response) => {
  const { question, sessionId } = req.body as { question?: string; sessionId?: string };
  if (!question || typeof question !== "string" || !question.trim()) {
    return res.status(400).json({ error: "question is required" });
  }

  const claudeUp = isClaudeConfigured();
  const geminiUp = isGeminiConfigured();
  if (!claudeUp && !geminiUp) {
    return res.status(503).json({ error: "EXTERNAL_CREDENTIAL_REQUIRED", detail: "Neither ANTHROPIC_API_KEY nor GEMINI_API_KEY is configured." });
  }

  const topNotes = scoreNotesForQuestion(question, 6);
  const excerptsBlock = topNotes.length
    ? topNotes.map((n) => `### ${n.label}\n${n.excerpt}`).join("\n\n")
    : "(No notes matched this question by keyword overlap.)";

  const sid = sessionId || "default";
  const history = sessionHistory.get(sid) || [];
  const messages: ChatMessage[] = [...history, { role: "user", text: question }];

  try {
    const systemPrompt = JARVIS_NOTES_SYSTEM_PROMPT(excerptsBlock);
    let answerText: string;
    let providerUsed: "claude" | "gemini";

    if (claudeUp) {
      try {
        const result = await chatWithClaude(messages, systemPrompt);
        answerText = result.text;
        providerUsed = "claude";
      } catch (err) {
        if (!geminiUp) throw err;
        const result = await chatWithGemini(messages, systemPrompt);
        answerText = result.text;
        providerUsed = "gemini";
      }
    } else {
      const result = await chatWithGemini(messages, systemPrompt);
      answerText = result.text;
      providerUsed = "gemini";
    }

    const updatedHistory = [...messages, { role: "model" as const, text: answerText }].slice(-MAX_HISTORY_TURNS * 2);
    sessionHistory.set(sid, updatedHistory);

    res.json({
      answer: answerText,
      nodes: topNotes.map((n) => n.id),
      providerUsed,
    });
  } catch (err: any) {
    res.status(502).json({ error: "NOTES_CHAT_FAILED", detail: err?.message || String(err) });
  }
};

/**
 * POST /api/notes/remember
 * body: { text: string }
 * Writes a real markdown note into <notesRoot>/captures/ and returns the new node plus
 * the id of the existing node it's most related to, for the client's "born near" animation.
 */
export const handleNotesRemember = (req: Request, res: Response) => {
  const { text } = req.body as { text?: string };
  if (!text || typeof text !== "string" || !text.trim()) {
    return res.status(400).json({ error: "text is required" });
  }
  try {
    const { node, nearestNodeId } = rememberNote(text);
    res.json({
      node: { id: node.id, label: node.label, group: node.group, excerpt: node.excerpt },
      nearestNodeId,
    });
  } catch (err: any) {
    res.status(500).json({ error: "REMEMBER_FAILED", detail: err?.message || String(err) });
  }
};
