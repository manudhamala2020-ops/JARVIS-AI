import React, { useState } from 'react';
import {
  X,
  FileText,
  Table,
  Presentation,
  Mail,
  Code,
  Copy,
  Download,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Send,
  Sliders,
  Layers,
} from 'lucide-react';
import { soundFx } from '../services/soundFx';

interface ProductivityForgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type DocType = 'word' | 'excel' | 'powerpoint' | 'gmail' | 'html';

export const ProductivityForgeModal: React.FC<ProductivityForgeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeDocType, setActiveDocType] = useState<DocType>('word');
  const [promptInput, setPromptInput] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Generated Content state
  const [wordContent, setWordContent] = useState<string>(`# EXECUTIVE SUMMARY: STARK INDUSTRIES CLEAN ENERGY INITIATIVE
**Date:** ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
**Prepared By:** J.A.R.V.I.S. Autonomous Research Core
**Classification:** Confidential / Level 7

---

### 1. Project Overview & Scope
The purpose of this document is to formalize the deployment parameters for the new Arc Reactor micro-grid infrastructure across urban centers. By harnessing zero-emission quantum plasma confinement, the system delivers sustainable municipal power with zero carbon footprint.

### 2. Key Objectives
- Complete secondary superconductor calibration across all 14 distribution nodes.
- Maintain a minimum 99.999% grid uptime during peak industrial cycles.
- Integrate real-time biometric and cyber-threat defense mechanisms to ensure infrastructure sovereignty.

### 3. Projected Timelines & Milestones
- **Q1 2026:** Sub-surface thermal shielding validation.
- **Q2 2026:** High-density capacitor bank activation.
- **Q3 2026:** Autonomous AI load-balancing orchestration.`);

  const [excelData, setExcelData] = useState<Array<Record<string, string | number>>>([
    { Component: 'Arc Reactor Core Mk VII', Quantity: 4, 'Unit Cost ($)': 12500000, 'Total ($)': 50000000, Status: 'Operational' },
    { Component: 'Vibranium-Titanium Composite Plating', Quantity: 120, 'Unit Cost ($)': 45000, 'Total ($)': 5400000, Status: 'In Stock' },
    { Component: 'MicroLED Retinal HUD Optics', Quantity: 24, 'Unit Cost ($)': 12000, 'Total ($)': 288000, Status: 'Calibrated' },
    { Component: 'Solid-State Lithium Supercapacitors', Quantity: 350, 'Unit Cost ($)': 3200, 'Total ($)': 1120000, Status: 'Testing' },
    { Component: 'YBCO Superconducting Tape (meters)', Quantity: 1500, 'Unit Cost ($)': 850, 'Total ($)': 1275000, Status: 'Operational' },
  ]);

  const [pptSlides, setPptSlides] = useState<
    Array<{ slideNo: number; title: string; bullets: string[]; speakerNotes: string }>
  >([
    {
      slideNo: 1,
      title: 'Stark Industries: Advanced AI Autonomous Systems',
      bullets: [
        'Next-generation AI systems platform',
        'Direct neural link & real-time cognitive reasoning',
        'Self-healing molecular composite matrices',
      ],
      speakerNotes: 'Introduce the core vision of autonomous tactical engineering to the board.',
    },
    {
      slideNo: 2,
      title: 'Architectural Breakdown & Material Science',
      bullets: [
        'Single-crystal titanium-vibranium lattice',
        'Micro-plasma magnetohydrodynamic propulsion',
        'Zero-latency edge computation via J.A.R.V.I.S.',
      ],
      speakerNotes: 'Emphasize the 400% increase in structural load capacity over Mark 50.',
    },
    {
      slideNo: 3,
      title: 'Strategic Roadmap & Global Deployment',
      bullets: [
        'Distributed systems telemetry integration',
        'Autonomous Iron Legion fleet coordination',
        'Zero-trust military active cybersecurity shield',
      ],
      speakerNotes: 'Conclude with rollout schedules and defense certification approvals.',
    },
  ]);

  const [gmailSubject, setGmailSubject] = useState<string>(
    'CONFIDENTIAL: Stark Industries Nanotech Architecture Review'
  );
  const [gmailBody, setGmailBody] = useState<string>(`Dear Team,

Following our recent engineering review, J.A.R.V.I.S. has verified the structural integrity of the Advanced AI AI systems suite. All secondary flight telemetry, thermal dissipation matrices, and superconducting busbars meet full operational specifications.

Please review the attached material science blueprint and provide sign-off by 17:00 EST today.

Best regards,

Tony Stark / J.A.R.V.I.S. Neural Core
Stark Industries Advanced Technologies Division`);

  const [htmlCode, setHtmlCode] = useState<string>(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>JARVIS Tactical Dashboard</title>
  <style>
    body { background: #050b14; color: #00f0ff; font-family: 'Orbitron', monospace, sans-serif; margin: 0; padding: 20px; }
    .card { background: rgba(6, 16, 32, 0.8); border: 1px solid #00f0ff; border-radius: 12px; padding: 20px; box-shadow: 0 0 20px rgba(0,240,255,0.2); }
    h1 { font-size: 20px; text-transform: uppercase; letter-spacing: 2px; }
    .status { color: #34d399; font-weight: bold; }
  </style>
</head>
<body>
  <div class="card">
    <h1>J.A.R.V.I.S. Neural Node</h1>
    <p>Status: <span class="status">ONLINE (100%)</span></p>
    <p>Core Frequency: 3.8 GHz • RT Flux: 3.2 GW</p>
  </div>
</body>
</html>`);

  const handleGenerate = () => {
    if (!promptInput.trim()) return;
    setIsGenerating(true);
    soundFx.playTap();

    setTimeout(() => {
      if (activeDocType === 'word') {
        setWordContent(`# RESEARCH REPORT: ${promptInput.toUpperCase()}
**Date:** ${new Date().toLocaleDateString()}
**Generated by:** J.A.R.V.I.S. Cognitive Studio

---

### Executive Overview
This technical report analyzes the operational mechanics and implementation strategies for ${promptInput}.

### Detailed Analysis & Methodologies
1. System architecture adheres to advanced modular design principles.
2. Real-time telemetry monitoring eliminates latency bottlenecks.
3. Strict cryptographic isolation ensures full data integrity and zero-trust compliance.

### Conclusion & Recommendations
Immediate execution of the proposed protocol is recommended to maximize performance.`);
      } else if (activeDocType === 'excel') {
        setExcelData([
          { Item: `${promptInput} Primary Matrix`, Quantity: 10, 'Unit Cost ($)': 15000, 'Total ($)': 150000, Status: 'Ready' },
          { Item: `${promptInput} Secondary Buffer`, Quantity: 25, 'Unit Cost ($)': 4200, 'Total ($)': 105000, Status: 'Active' },
          { Item: `${promptInput} Diagnostic Module`, Quantity: 4, 'Unit Cost ($)': 35000, 'Total ($)': 140000, Status: 'Calibrated' },
        ]);
      } else if (activeDocType === 'gmail') {
        setGmailSubject(`Urgent Update: ${promptInput}`);
        setGmailBody(`Sir,

Regarding your query on "${promptInput}": All relevant datasets, diagnostic metrics, and deployment pipelines have been processed. 

Subsystem status remains at 100% operational readiness. Please let me know if you would like me to execute the next phase.

Respectfully,
J.A.R.V.I.S.`);
      } else if (activeDocType === 'html') {
        setHtmlCode(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${promptInput}</title>
  <style>
    body { background: #060a14; color: #fff; font-family: sans-serif; padding: 2rem; }
    .hero { border: 1px solid #00f0ff; border-radius: 12px; padding: 24px; background: rgba(0,240,255,0.05); }
    h1 { color: #00f0ff; }
  </style>
</head>
<body>
  <div class="hero">
    <h1>${promptInput}</h1>
    <p>Engineered autonomously by J.A.R.V.I.S. Studio.</p>
  </div>
</body>
</html>`);
      }
      setIsGenerating(false);
      soundFx.playNotification();
    }, 800);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    soundFx.playTap();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCSV = () => {
    soundFx.playTap();
    const headers = Object.keys(excelData[0]).join(',');
    const rows = excelData.map((row) => Object.values(row).join(',')).join('\n');
    const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(headers + '\n' + rows);
    const link = document.createElement('a');
    link.setAttribute('href', csvContent);
    link.setAttribute('download', `Stark_Financial_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  return (
    <div
      id="productivity-forge-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-lg animate-in fade-in duration-200 font-sans"
    >
      <div className="relative w-full max-w-5xl max-h-[90vh] bg-[#050b16] border border-cyan-500/50 rounded-2xl shadow-[0_0_40px_rgba(0,240,255,0.2)] flex flex-col overflow-hidden text-slate-200">
        {/* Top Title Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-black to-cyan-950/40">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-600/20 border border-cyan-500/50 rounded-lg">
              <FileText className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[#00f0ff] font-orbitron font-black text-sm tracking-widest uppercase">
                  PRODUCTIVITY & OFFICE FORGE
                </span>
                <span className="px-2 py-0.5 bg-cyan-950 border border-cyan-700/60 rounded text-[10px] font-mono text-cyan-300">
                  WORD • EXCEL • PPT • GMAIL • HTML
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Instant Professional Document Synthesis, Spreadsheets & Code Forge
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFx.playTap();
              onClose();
            }}
            className="p-1.5 bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-600/50 rounded-md text-cyan-300 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Doc Type Selector */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-950 border-b border-slate-800 text-xs font-semibold overflow-x-auto">
          {[
            { key: 'word', label: '1. WORD / DOCS (.DOC)', icon: FileText },
            { key: 'excel', label: '2. EXCEL / CSV SHEET', icon: Table },
            { key: 'powerpoint', label: '3. POWERPOINT SLIDES', icon: Presentation },
            { key: 'gmail', label: '4. GMAIL / EMAIL WRITER', icon: Mail },
            { key: 'html', label: '5. HTML5 / WEB CODE', icon: Code },
          ].map((item) => {
            const Icon = item.icon;
            const isSelected = activeDocType === item.key;
            return (
              <button
                key={item.key}
                onClick={() => {
                  soundFx.playTap();
                  setActiveDocType(item.key as any);
                }}
                className={`px-3.5 py-1.5 rounded-lg whitespace-nowrap transition-all flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.3)]'
                    : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 text-cyan-400" />
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex gap-2">
          <input
            type="text"
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
            placeholder={`Describe the ${activeDocType.toUpperCase()} you want J.A.R.V.I.S. to write or generate...`}
            className="flex-1 px-4 py-2 bg-slate-900 border border-slate-700 focus:border-cyan-400 rounded-xl text-xs text-white placeholder:text-slate-500 outline-none"
          />
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-black font-bold text-xs rounded-xl flex items-center gap-2 transition-all shadow-[0_0_15px_rgba(0,240,255,0.4)]"
          >
            {isGenerating ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span>GENERATE</span>
          </button>
        </div>

        {/* Content Viewer */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* WORD VIEW */}
          {activeDocType === 'word' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  MICROSOFT WORD / STARK DOC EDITOR
                </span>
                <button
                  onClick={() => handleCopy(wordContent)}
                  className="px-3 py-1 bg-slate-900 border border-slate-700 hover:border-cyan-400 text-xs rounded-md flex items-center gap-1.5 text-slate-300"
                >
                  {copied ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copied ? 'Copied!' : 'Copy Text'}</span>
                </button>
              </div>
              <textarea
                value={wordContent}
                onChange={(e) => setWordContent(e.target.value)}
                className="w-full h-80 p-4 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-200 leading-relaxed outline-none focus:border-cyan-500/50 resize-none"
              />
            </div>
          )}

          {/* EXCEL VIEW */}
          {activeDocType === 'excel' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-emerald-400 font-bold">
                  EXCEL SPREADSHEET / FINANCIAL LEDGER
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCopy(JSON.stringify(excelData, null, 2))}
                    className="px-3 py-1 bg-slate-900 border border-slate-700 hover:border-emerald-400 text-xs rounded-md flex items-center gap-1.5 text-slate-300"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy JSON</span>
                  </button>
                  <button
                    onClick={handleDownloadCSV}
                    className="px-3 py-1 bg-emerald-600/30 border border-emerald-500 hover:bg-emerald-600/50 text-xs rounded-md flex items-center gap-1.5 text-emerald-300 font-bold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .CSV</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-800 rounded-xl">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-900 text-slate-400 font-mono border-b border-slate-800">
                    <tr>
                      {Object.keys(excelData[0]).map((h) => (
                        <th key={h} className="p-3">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-950 font-mono">
                    {excelData.map((row, i) => (
                      <tr key={i} className="hover:bg-slate-900/50">
                        {Object.values(row).map((val, j) => (
                          <td key={j} className="p-3 text-slate-200">
                            {typeof val === 'number' ? val.toLocaleString() : val}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* POWERPOINT VIEW */}
          {activeDocType === 'powerpoint' && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-amber-400 font-bold">
                  POWERPOINT SLIDE DECK ARCHITECTURE
                </span>
                <button
                  onClick={() =>
                    handleCopy(
                      pptSlides
                        .map(
                          (s) =>
                            `Slide ${s.slideNo}: ${s.title}\n${s.bullets.map((b) => `- ${b}`).join('\n')}\nNotes: ${s.speakerNotes}`
                        )
                        .join('\n\n')
                    )
                  }
                  className="px-3 py-1 bg-slate-900 border border-slate-700 hover:border-amber-400 text-xs rounded-md flex items-center gap-1.5 text-slate-300"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Presentation</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {pptSlides.map((slide) => (
                  <div
                    key={slide.slideNo}
                    className="p-4 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-xl flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[10px] font-mono text-amber-400 mb-2">
                        <span>SLIDE 0{slide.slideNo}</span>
                        <Presentation className="w-3.5 h-3.5" />
                      </div>
                      <h4 className="text-xs font-bold text-white mb-2">{slide.title}</h4>
                      <ul className="text-xs text-slate-300 space-y-1 mb-3">
                        {slide.bullets.map((b, i) => (
                          <li key={i}>• {b}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
                      Speaker Notes: {slide.speakerNotes}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* GMAIL VIEW */}
          {activeDocType === 'gmail' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-rose-400 font-bold">
                  GMAIL & PROFESSIONAL EMAIL FORGE
                </span>
                <button
                  onClick={() => handleCopy(`Subject: ${gmailSubject}\n\n${gmailBody}`)}
                  className="px-3 py-1 bg-slate-900 border border-slate-700 hover:border-rose-400 text-xs rounded-md flex items-center gap-1.5 text-slate-300"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Email</span>
                </button>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 block mb-1">
                    SUBJECT:
                  </label>
                  <input
                    type="text"
                    value={gmailSubject}
                    onChange={(e) => setGmailSubject(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-mono text-slate-400 block mb-1">
                    BODY:
                  </label>
                  <textarea
                    value={gmailBody}
                    onChange={(e) => setGmailBody(e.target.value)}
                    rows={8}
                    className="w-full p-3 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white outline-none focus:border-rose-500 resize-none font-sans"
                  />
                </div>
              </div>
            </div>
          )}

          {/* HTML VIEW */}
          {activeDocType === 'html' && (
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-cyan-400 font-bold">
                  HTML5 / CSS / JS WEB FORGE
                </span>
                <button
                  onClick={() => handleCopy(htmlCode)}
                  className="px-3 py-1 bg-slate-900 border border-slate-700 hover:border-cyan-400 text-xs rounded-md flex items-center gap-1.5 text-slate-300"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <textarea
                  value={htmlCode}
                  onChange={(e) => setHtmlCode(e.target.value)}
                  className="w-full h-80 p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-cyan-300 leading-relaxed outline-none focus:border-cyan-500 resize-none"
                />
                <div className="w-full h-80 border border-slate-800 rounded-xl overflow-hidden bg-black flex flex-col">
                  <div className="px-3 py-1.5 bg-slate-900 text-[10px] font-mono text-slate-400 border-b border-slate-800">
                    LIVE SANDBOX PREVIEW
                  </div>
                  <iframe
                    srcDoc={htmlCode}
                    title="Live Preview"
                    className="w-full flex-1 border-none bg-white"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-black/60 flex items-center justify-between text-xs text-slate-400 font-mono">
          <span>STARK PRODUCTIVITY FORGE</span>
          <span className="text-cyan-400 font-bold">READY FOR EXPORT</span>
        </div>
      </div>
    </div>
  );
};
