export interface HandLandmark {
  x: number;
  y: number;
  z?: number;
}

type HandListener = (landmarks: HandLandmark[][] | null) => void;
type GestureListener = (gesture: string, confidence: number) => void;
type SensitivityListener = (sensitivity: number) => void;

class HandTrackingService {
  private landmarks: HandLandmark[][] | null = null;
  private activeHandsCount: number = 0;
  private lastGesture: string = '';
  private lastConfidence: number = 0;
  private sensitivity: number = 50; // 0 (strict/high threshold) to 100 (ultra-responsive/low threshold)
  private landmarkListeners: Set<HandListener> = new Set();
  private gestureListeners: Set<GestureListener> = new Set();
  private sensitivityListeners: Set<SensitivityListener> = new Set();
  private fps: number = 60;
  private lastFrameTime: number = performance.now();

  public setSensitivity(val: number) {
    this.sensitivity = Math.max(0, Math.min(100, val));
    this.sensitivityListeners.forEach((listener) => {
      try {
        listener(this.sensitivity);
      } catch (e) {
        // ignore
      }
    });
  }

  public getSensitivity(): number {
    return this.sensitivity;
  }

  // Returns sensitivity multiplier: e.g. 0.5 (at 0) to 1.8 (at 100)
  public getSensitivityFactor(): number {
    return 0.5 + (this.sensitivity / 100) * 1.3;
  }

  // Returns motion threshold (deadzone): e.g. 0.0024 (at 0/strict) down to 0.0006 (at 100/hyper-responsive)
  public getMotionThreshold(): number {
    return 0.0024 - (this.sensitivity / 100) * 0.0018;
  }

  // Returns swipe velocity threshold: e.g. 2.6 (at 0/strict) down to 1.2 (at 100/fast)
  public getSwipeThreshold(): number {
    return 2.6 - (this.sensitivity / 100) * 1.4;
  }

  // Returns cooldown factor: higher sensitivity = snappier cooldowns (e.g. 0.7x to 1.3x)
  public getCooldownFactor(): number {
    return 1.3 - (this.sensitivity / 100) * 0.6;
  }

  public subscribeSensitivity(listener: SensitivityListener): () => void {
    this.sensitivityListeners.add(listener);
    listener(this.sensitivity);
    return () => {
      this.sensitivityListeners.delete(listener);
    };
  }

  public updateLandmarks(hands: HandLandmark[][] | null) {
    this.landmarks = hands;
    this.activeHandsCount = hands ? hands.length : 0;

    const now = performance.now();
    const dt = now - this.lastFrameTime;
    this.lastFrameTime = now;
    if (dt > 0) {
      this.fps = Math.round(1000 / dt);
    }

    // Direct listener dispatch without React useState pipeline
    this.landmarkListeners.forEach((listener) => {
      try {
        listener(this.landmarks);
      } catch (e) {
        // ignore
      }
    });
  }

  public getLandmarks(): HandLandmark[][] | null {
    return this.landmarks;
  }

  public getActiveHandsCount(): number {
    return this.activeHandsCount;
  }

  public getFps(): number {
    return this.fps;
  }

  public setGesture(gesture: string, confidence: number) {
    this.lastGesture = gesture;
    this.lastConfidence = confidence;
    this.gestureListeners.forEach((listener) => {
      try {
        listener(gesture, confidence);
      } catch (e) {
        // ignore
      }
    });
  }

  public getGesture(): { gesture: string; confidence: number } {
    return { gesture: this.lastGesture, confidence: this.lastConfidence };
  }

  public subscribeLandmarks(listener: HandListener): () => void {
    this.landmarkListeners.add(listener);
    return () => {
      this.landmarkListeners.delete(listener);
    };
  }

  public subscribeGesture(listener: GestureListener): () => void {
    this.gestureListeners.add(listener);
    return () => {
      this.gestureListeners.delete(listener);
    };
  }
}

export const handTrackingService = new HandTrackingService();
