# Capability Matrix

| Area | Target | Implementation boundary |
|---|---|---|
| Reasoning/research | Expert, source-aware | Model/API dependent |
| Programming | Multi-language | Toolchain dependent |
| Voice | Continuous + barge-in | Browser/device speech APIs |
| Vision | Object/scene/motion | Camera + model availability |
| Gestures | Low latency, two-hand | MediaPipe + device performance |
| Files | Organize/create/edit | User-authorized browser/native access |
| Device | Maximum practical authority | Android permissions/native bridge |
| Web | Research + authorized automation | Browser APIs/connectors |
| Productivity | Docs/sheets/slides/email | Authenticated service connectors |
| Security | Defensive analysis/recovery | Authorized environments |
| Location | Geolocation/maps | Permission + map provider |
| Weather | Dynamic meteorology | Live weather provider |
| Languages | 100+ target | Model/TTS/STT/provider coverage |
| Self-maintenance | Audited self-repair | Test + verify + rollback |
| Autonomy | Bounded task execution | Approval gates for consequential actions |
